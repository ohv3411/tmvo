"""
Генератор статического сайта «Торбеевские матрасы» (версия 4).

    python tools/build_site.py

Берёт data/catalog.json и создаёт «оболочки» страниц: шапка, подвал, заголовки, адреса.
Каталог, карточки, страницы товаров, акции и поиск рисует assets/js/site.js из data/catalog.js —
поэтому правки из админки видны сразу, без пересборки. Пересборка нужна только для новых адресов
(товар или раздел, созданный в админке, до пересборки открывается по адресу tovar/?id=… или katalog/?c=…).

Ссылки относительные и с явным index.html — сайт работает на GitHub Pages (в т.ч. в подпапке) и с диска.
"""
import html, json, os, shutil
from datetime import date

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CAT = json.load(open(os.path.join(ROOT, "data", "catalog.json"), encoding="utf-8"))
NOINDEX = True           # демо: не индексировать поисковиками
SITE_URL = "https://tmvo.ru/"

SHOP = dict(name="Торбеевские матрасы", phone="8 (495) 150-30-90", phone_href="+74951503090",
            mphone="+7 (985) 800-00-29", mphone_href="+79858000029", tg="https://t.me/+79858000029", max="",
            email="info@tmvo.ru", hours="Ежедневно с 10:00 до 20:00",
            address="Московская обл., Люберецкий р-н, пос. Торбеево, д. 48", address_short="пос. Торбеево, д. 48",
            seller="ИП Геворгян Р. А.", inn="342102450670", ogrnip="323508100652805", okpo="2027978788",
            bank="ПАО Сбербанк", bik="044525225", rs="40802810140000186299", ks="30101810400000000225")
MAP_Q = "Московская область, Люберецкий район, посёлок Торбеево, 48"

e = lambda s: html.escape(str(s if s is not None else ""), quote=True)
def rub(n): return f"{int(round(n)):,}".replace(",", " ") + " ₽"
P = [p for p in CAT["products"] if p.get("active", True)]
CATS = CAT["categories"]; GROUPS = CAT["groups"]
CBY = {c["id"]: c for c in CATS}
def full(p): return ((p.get("word") + " ") if p.get("word") and p["category"] != "detskie-namatrasniki" else "") + p["name"]

# ---------------------------------------------------------------- макет
class Page:
    def __init__(self, path):
        self.path = path.strip("/") + "/" if path.strip("/") else ""
        self.depth = self.path.count("/")
        self.root = "../" * self.depth
    def u(self, target):
        q = ""
        if "?" in target: target, q = target.split("?", 1); q = "?" + q
        target = target.strip("/") + "/" if target.strip("/") else ""
        return self.root + target + "index.html" + q
    def a(self, rel): return self.root + rel

ICON = {
    "search": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
    "cart": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 4h2l2.2 11h11l2-8H6.2"/><circle cx="9" cy="19.5" r="1.5"/><circle cx="17" cy="19.5" r="1.5"/></svg>',
    "heart": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20s-7-4.4-9.2-9A5 5 0 0112 5.6 5 5 0 0121.2 11C19 15.6 12 20 12 20z"/></svg>',
    "menu": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    "grid": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/></svg>',
    "truck": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h11v10H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="1.8"/><circle cx="17" cy="18" r="1.8"/></svg>',
    "shield": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg>',
    "factory": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 20V10l5 3V10l5 3V6h4v14z"/><path d="M3 20h18"/></svg>',
    "ruler": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="8" width="20" height="8" rx="1.5"/><path d="M6 8v3M10 8v4M14 8v3M18 8v4"/></svg>',
    "scale": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 4v16M5 8h14M5 8l-3 7h6zM19 8l-3 7h6z"/></svg>',
    "pin": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s-7-6.2-7-11.5A7 7 0 0119 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg>',
    "phone": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 3h4l2 5-2.5 1.5a11 11 0 005 5L15 12l5 2v4a2 2 0 01-2 2A16 16 0 013 5a2 2 0 012-2z"/></svg>',
    "tg": '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.4 4.3L2.9 11.4c-1.2.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.1.9.8.9.5 0 .7-.2 1-.5l2.3-2.2 4.8 3.5c.9.5 1.5.2 1.7-.8l3.1-14.7c.3-1.3-.5-1.9-1.5-1.4zM8.6 14.1l9.6-6.1c.5-.3.9-.1.5.2l-8.2 7.4-.3 3.4z"/></svg>',
    "max": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M4 18V6l8 8 8-8v12"/></svg>',
    "up": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 14l6-6 6 6"/></svg>',
    "pct": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 5L5 19"/><circle cx="7" cy="7" r="2.5"/><circle cx="17" cy="17" r="2.5"/></svg>',
}
INFO = [("Доставка и оплата", "dostavka-i-oplata/"), ("Гарантия", "garantiya/"), ("Отзывы", "otzyvy/"), ("Контакты", "kontakty/")]

def contacts_icons(cls="msg"):
    """Порядок: телефон → MAX → Telegram."""
    mx = SHOP["max"] or f'tel:{SHOP["mphone_href"]}'
    return (f'<span class="{cls}"><a href="tel:{SHOP["phone_href"]}" aria-label="Позвонить {e(SHOP["phone"])}" title="Позвонить">{ICON["phone"]}</a>'
            f'<a href="{mx}" aria-label="Написать в MAX" title="MAX">{ICON["max"]}</a>'
            f'<a href="{SHOP["tg"]}" target="_blank" rel="noopener" aria-label="Написать в Telegram" title="Telegram">{ICON["tg"]}</a></span>')

def layout(pg, *, title, desc, body, page_type="info", attrs="", crumbs=None, lead=True):
    links = lambda items: "".join(f'<a href="{pg.u(h)}">{e(t)}</a>' for t, h in items)
    crumbs_html = ""
    if crumbs:
        parts = [f'<a href="{pg.u("")}">Главная</a>'] + [f'<a href="{pg.u(h)}">{e(t)}</a>' if h else f'<span aria-current="page">{e(t)}</span>' for t, h in crumbs]
        crumbs_html = f'<nav class="crumbs wrap" id="crumbs" aria-label="Навигация">{" / ".join(parts)}</nav>'
    lead_html = f'''<section class="lead-sec"><div class="wrap lead-in"><div><h2>Остались вопросы — мы поможем</h2><p>Оставьте телефон, и мы перезвоним: подскажем модель, размер и сроки изготовления.</p></div>
      <form class="lead-form" novalidate><label class="sr" for="lp-{pg.depth}">Телефон</label><input class="inp" id="lp-{pg.depth}" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+7 (___) ___-__-__">
      <button class="btn" disabled>Проконсультироваться</button>
      <label class="cbx"><input type="checkbox" name="privacy"> <span>Соглашаюсь с <a href="{pg.u("politika-konfidentsialnosti/")}">политикой конфиденциальности</a></span></label>
      <label class="cbx"><input type="checkbox" name="personal_data"> <span>Даю <a href="{pg.u("soglasie-na-obrabotku/")}">согласие на обработку персональных данных</a></span></label>
      <input class="hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true"></form></div></section>''' if lead else ""
    group_links = "".join(f'<a href="{pg.u(g["url"])}" data-group="{g["id"]}">{e(g["name"])}</a>' for g in GROUPS)
    fcat = "".join(f'<a href="{pg.u(c["url"])}">{e(c["name"])}</a>' for c in CATS if c.get("menu", True))
    return f'''<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(title)}</title>
<meta name="description" content="{e(desc)}">
{'<meta name="robots" content="noindex, nofollow">' if NOINDEX else ''}
<link rel="icon" href="{pg.a("img/logo.svg")}" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Onest:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{pg.a("assets/css/style.css")}">
</head>
<body data-page="{page_type}"{attrs}>
<a class="skip" href="#main">К содержимому</a>
<div class="topbar"><div class="wrap topbar-in">
  <a href="{pg.u("kontakty/")}" class="tb-addr">{ICON["pin"]} {e(SHOP["address_short"])}</a><span class="tb-hours">{e(SHOP["hours"])}</span>
  <a class="tb-promo" id="tbPromo" href="{pg.u("akcii/")}" hidden></a>
  <span class="tb-msg"><span class="tb-mphone">{e(SHOP["mphone"])}</span>{contacts_icons()}</span>
</div></div>
<header class="hdr"><div class="wrap hdr-in">
  <button class="icon-btn burger" id="burger" aria-label="Открыть меню">{ICON["menu"]}</button>
  <button class="btn catbtn" id="catbtn" aria-expanded="false" aria-controls="megamenu">{ICON["grid"]} Каталог</button>
  <a class="logo" href="{pg.u("")}" aria-label="{e(SHOP["name"])} — на главную"><img src="{pg.a("img/logo.svg")}" alt="{e(SHOP["name"])}" width="132" height="46"></a>
  <form class="hsearch" action="{pg.u("poisk/")}" role="search" autocomplete="off">{ICON["search"]}<input name="q" type="search" placeholder="Матрас 160×200, кокос, кровать с подъёмником…" aria-label="Поиск по каталогу" enterkeyhint="search"><button class="hs-go" aria-label="Найти">Найти</button><div class="suggest" hidden></div></form>
  <div class="hdr-tel"><a href="tel:{SHOP["phone_href"]}">{e(SHOP["phone"])}</a><small><button class="link" data-callback>Заказать звонок</button></small></div>
  <a class="icon-btn hdr-call" href="tel:{SHOP["phone_href"]}" aria-label="Позвонить">{ICON["phone"]}</a>
  <a class="icon-btn" href="{pg.u("izbrannoe/")}" aria-label="Избранное">{ICON["heart"]}<span class="badge fav-count" hidden></span></a>
  <a class="icon-btn" href="{pg.u("korzina/")}" aria-label="Корзина">{ICON["cart"]}<span class="badge cart-count" hidden></span></a>
</div>
<nav class="nav2" aria-label="Разделы"><div class="wrap nav2-in">{group_links}<a href="{pg.u("akcii/")}" class="nav-promo">{ICON["pct"]} Акции<span class="nav-cnt" id="promoCnt" hidden></span></a><span class="nav-sep"></span>{links(INFO)}</div></nav>
<div class="megamenu" id="megamenu" hidden><div class="wrap" id="mmIn"></div></div></header>
<div class="drawer" id="drawer"><div class="shade" data-drawer-close></div><nav class="panel" aria-label="Меню">
  <div class="dhead"><img src="{pg.a("img/logo.svg")}" alt="" class="dlogo"><button class="x" data-drawer-close aria-label="Закрыть меню">×</button></div>
  <a href="{pg.u("akcii/")}" class="d-promo">{ICON["pct"]} Акции и скидки</a>
  <div id="drawerCat"></div><h4>Покупателям</h4>{links(INFO)}
  <div class="dfoot"><a href="tel:{SHOP["phone_href"]}" class="dtel">{e(SHOP["phone"])}</a><span class="muted">{e(SHOP["hours"])}</span>{contacts_icons("msg big")}</div>
</nav></div>
{crumbs_html}
<main id="main" tabindex="-1">
{body}
</main>
{lead_html}
<footer class="ftr"><div class="wrap"><div class="ftr-grid">
  <div><img src="{pg.a("img/logo.svg")}" alt="{e(SHOP["name"])}" class="flogo"><p>Фабрика матрасов в Подмосковье: матрасы, кровати, основания, топперы и наматрасники для взрослых и детей.</p></div>
  <div><h4>Каталог</h4><div id="ftrCat">{fcat}</div><a href="{pg.u("akcii/")}">Акции</a></div>
  <div><h4>Покупателям</h4>{links(INFO)}</div>
  <div><h4>Контакты</h4><a class="tel" href="tel:{SHOP["phone_href"]}">{e(SHOP["phone"])}</a><span>Бесплатный звонок по РФ</span>
    <a href="tel:{SHOP["mphone_href"]}">{e(SHOP["mphone"])}</a><span>MAX, Telegram</span><div class="fmsg">{contacts_icons()}</div>
    <a href="mailto:{SHOP["email"]}">{e(SHOP["email"])}</a><p class="faddr">{e(SHOP["address"])}<br>{e(SHOP["hours"])}</p><a href="{pg.u("kontakty/")}">Все контакты и реквизиты</a></div>
</div>
<div class="legal"><span>© {date.today().year} {e(SHOP["name"])}. {e(SHOP["seller"])}, ИНН {SHOP["inn"]}, ОГРНИП {SHOP["ogrnip"]}.</span>
  <span><a href="{pg.u("politika-konfidentsialnosti/")}">Политика конфиденциальности</a> · <a href="{pg.u("soglasie-na-obrabotku/")}">Согласие на обработку данных</a> · <a href="{pg.u("oferta/")}">Публичная оферта</a></span></div>
</div></footer>
<button class="totop" id="totop" aria-label="Наверх" hidden>{ICON["up"]}</button>
<div class="modal" id="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="shade" data-close></div><div class="dlg" id="dlg"></div></div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<script>window.TMVO_ROOT = "{pg.root}";</script>
<script src="{pg.a("assets/js/config.js")}"></script>
<script src="{pg.a("data/catalog.js")}"></script>
<script src="{pg.a("data/static.js")}"></script>
<script src="{pg.a("assets/js/data.js")}"></script>
<script src="{pg.a("assets/js/api.js")}"></script>
<script src="{pg.a("assets/js/search.js")}"></script>
<script src="{pg.a("assets/js/site.js")}"></script>
</body>
</html>
'''

PAGES = []
def write(pg, content):
    out = os.path.join(ROOT, pg.path, "index.html")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, "w", encoding="utf-8").write(content); PAGES.append(pg.path)

def sec(title, inner, sub="", link=None, cls="", attrs=""):
    return f'''<section class="sec {cls}"{attrs}><div class="wrap"><div class="sec-h"><div><h2>{title}</h2>{f'<p class="muted">{sub}</p>' if sub else ""}</div>{f'<a class="link" href="{link[1]}">{link[0]}</a>' if link else ""}</div>{inner}</div></section>'''
def aside_help(pg):
    return f'''<aside class="help-box"><h3>Нужна помощь с выбором?</h3><p>Позвоните или напишите — подскажем модель, размер и сроки.</p>
      <a class="tel" href="tel:{SHOP["phone_href"]}">{e(SHOP["phone"])}</a><p class="muted small">{e(SHOP["mphone"])} — MAX, Telegram<br>{e(SHOP["hours"])}</p>
      <button class="btn block" data-callback>Заказать звонок</button></aside>'''

# Отзывы с сайта. Даты хранятся, но на сайте не показываются (SHOW_REVIEW_DATES).
SHOW_REVIEW_DATES = False
REVIEWS = [
    ("Анна В.", "26.06.2026", "Только плюсы, порядка 10 лет покупаю у них, а ещё и дети стали покупать там же."),
    ("Ирина Александровна", "26.02.2026", "Заказывали матрас. Качество на уровне. Персонал компетентный, вежливый. Срок выполнения заказа выдерживается. Доставка в удобный заранее оговоренный день и час. Рекомендую!"),
    ("Екатерина", "18.07.2022", "Пользуемся 4 года, всё отлично, очень довольны качеством. Брали двусторонний матрас, в итоге спим на жёсткой стороне, спина не болит."),
    ("Евгений Матвеев", "07.07.2022", "Отличное качество. Купили себе, детям и соседям. Все очень довольны. Быстрая доставка. Радуют скидки. Большой выбор наполнения и обтяжной ткани матраца."),
    ("Юлия Волкова", "04.07.2022", "Отличные матрасы! Особенно император люкс. Очень нравится!!! Спасибо отдельное Борису, который занимается доставкой!"),
    ("Антон Тихонов", "26.04.2022", "Хорошее соотношение цены и качества, пользуюсь год, пока доволен."),
    ("Евгений", "23.03.2022", "Отличные матрасы! Отличный персонал! Доставили вовремя. Покупал матрас по совету знакомых и остался очень доволен! Советую выбирать данную компанию!"),
    ("Валерий П.", "25.02.2022", "Хочу поблагодарить производителей этой компании. Отличные матрасы выпускает эта фабрика. Купил у них с доставкой один матрас девять лет назад, он и сейчас как новенький. Купил дорогой зима-лето с кокосовой койрой. Очень тепло лежать на нём. Были матрасы других производителей (более дешёвые), но они через пару лет проминались очень сильно, даже форму не держали. Теперь только у них буду покупать."),
    ("Дарья Шишкина", "13.02.2022", "Хороший выбор матрасов, цены доступные, радуют сроки, так как своё производство, матрас делают за 2–3 дня, заказала, оформили быстро, доставили и занесли в дом, уже неделю сплю и радуюсь, очень удобно. Персонал вежливый и грамотный, ничего не навязывают."),
    ("Любовь С.", "02.02.2022", "Отличная работа, девушки-консультанты всё объяснили, посоветовали и помогли с выбором. Производство и доставка в срок. Для владельцев диванов «аккордеон» просто спасение: сменили наполнение — и диван как новый. Всё отлажено, чётко и в сроки, спасибо!"),
]
def review_cards(items):
    return '<div class="reviews">' + "".join(f'<figure class="review"><blockquote>{e(t)}</blockquote><figcaption><b>{e(n)}</b>{f"<span>{d}</span>" if SHOW_REVIEW_DATES else ""}</figcaption></figure>' for n, d, t in items) + "</div>"
WHY = [("factory", "Собственное производство", "Мы — производитель: не арендуем помещения и не нанимаем подрядчиков, поэтому вы не переплачиваете за логистику."),
       ("shield", "Гарантия на все товары", "Если товар не соответствует заявленным качествам, заменим его или вернём деньги."),
       ("ruler", "Матрасы на заказ", "Изготовим модель по вашим размерам и с нужными наполнителями."),
       ("scale", "Цена и качество", "Комбинируя материалы и технологии, мы добились выгодного соотношения цены и качества.")]
def why(): return '<div class="why">' + "".join(f'<div>{ICON[i]}<b>{t}</b><p>{d}</p></div>' for i, t, d in WHY) + "</div>"
HARD_OPTS = [("Мягкий", "Мягкие"), ("Средней жесткости", "Средней жёсткости"), ("Жесткий", "Жёсткие"), ("raz", "Разная жёсткость сторон")]
SKELETON = '<div class="grid sk">' + '<div class="card sk-card"></div>' * 4 + "</div>"

# ---------------------------------------------------------------- страницы
def build_home():
    pg = Page("")
    regular = [p for p in P if p["category"] != "sale"]
    bars = {"Мягкий": [1, 2], "Средней жесткости": [1, 2, 3], "Жесткий": [1, 2, 3, 4, 5], "raz": [1, 5]}
    hard_html = '<div class="hard-pick">' + "".join(
        f'<a href="{pg.u("matrasy/?hard=" + k)}"><b>{t}</b><div class="scale">{"".join(f"<i class={chr(34)}{"on" if i in bars[k] else ""}{chr(34)}></i>" for i in range(1, 6))}</div><span class="muted small" data-count-hard="{k}"></span></a>'
        for k, t in HARD_OPTS) + "</div>"
    body = f'''
<section class="hero2"><img src="{pg.a("img/site/hero.jpg")}" srcset="{pg.a("img/site/hero-m.jpg")} 1000w, {pg.a("img/site/hero.jpg")} 1920w" sizes="100vw" alt="Спальня с матрасом" class="hero2-img">
  <div class="wrap hero2-in"><div class="hero2-card">
    <p class="eyebrow">Производство фабрики «Торбеевские матрасы»</p><h1>Эргономичные матрасы и изделия для комфортного сна</h1>
    <p class="hero-sub">Матрасы, кровати, основания, топперы и наматрасники для взрослых и детей. Делаем сами в Подмосковье, доставляем по Москве, области и всей России.</p>
    <div class="hero-cta"><a class="btn" href="{pg.u("matrasy/")}">Выбрать матрас</a><a class="btn ghost" href="{pg.u("akcii/")}">Акции и скидки</a></div>
  </div></div></section>
<section class="facts-strip"><div class="wrap facts2"><div><b>{len(regular)}</b><span>моделей</span></div><div><b>18 месяцев</b><span>гарантия на матрасы</span></div><div><b>Любой размер</b><span>изготовим на заказ</span></div><div><b>Шоурум</b><span>пос. Торбеево, ежедневно 10–20</span></div></div></section>
<section class="sec promo-sec"><div class="wrap"><div class="sec-h"><div><h2>Акции</h2><p class="muted">Скидки уже в ценах на сайте. Распродажа, подарки и промокод — ниже.</p></div><a class="link" href="{pg.u("akcii/")}">Все акции</a></div><div id="promoArea" class="promo-area"></div></div></section>
{sec("Каталог", '<div id="homeCats"></div>', cls="tight")}
{sec("Товары со скидкой", '<div class="grid" data-list="promo" data-limit="8"></div>', link=("Все акции", pg.u("akcii/")), cls="tight", attrs=' data-hide-empty')}
{sec("Подобрать матрас по жёсткости", hard_html, cls="tight")}
{sec("Популярные модели", '<div class="grid" data-list="ids" data-ids="matras-imperator,matras-iris,matras-zevs,matras-lotos,matras-germes,matras-virtuoz,matras-afrodita,matras-sultan"></div>', link=("Все матрасы", pg.u("matrasy/")), cls="tight")}
{sec("Кровати", '<div class="grid" data-list="cat" data-cat="krovati" data-limit="4"></div>', sub="Новый раздел: кровати с мягким изголовьем и подъёмным механизмом.", link=("Все кровати", pg.u("krovati/")), cls="tight", attrs=' data-hide-empty')}
{sec("Почему выбирают нас", why(), cls="tight")}
<section class="sec made"><div class="wrap made-in">
  <div class="made-pic"><img src="{pg.a("img/site/fabric.jpg")}" alt="Стёганый жаккард с логотипом фабрики" loading="lazy"><img src="{pg.a("img/site/quilt.jpg")}" alt="Матрас в фирменном чехле" loading="lazy"></div>
  <div><h2>Делаем сами, в Подмосковье</h2><p class="muted big">Каждый матрас собираем на своём производстве в пос. Торбеево: независимые пружинные блоки, натуральный латекс, кокосовая койра, чехлы из хлопкового жаккарда и трикотажа.</p>
    <ul class="made-list"><li><b>Матрасы от мягких до жёстких</b><span>с пружинами и без</span></li>
    <li><b>Нестандартные размеры</b><span>изготовим по вашим меркам и с нужными наполнителями</span></li>
    <li><b>Шоурум в Торбеево</b><span>приезжайте полежать на матрасах — {e(SHOP["hours"].lower())}</span></li></ul></div></div></section>
{sec("Отзывы покупателей", review_cards(REVIEWS[:6]), link=("Все отзывы", pg.u("otzyvy/")), cls="tight")}
<section class="sec seo"><div class="wrap prose narrow"><h2>Анатомические матрасы</h2>
<p>Анатомическими называют матрасы, которые в той или иной степени повторяют физиологические изгибы лежащего на них человека. Основная цель — разгрузить позвоночник и расслабить мышцы всего тела, обеспечив полноценный отдых.</p>
<p>Анатомические матрасы не являются лечебным оборудованием, но их профилактический эффект для здоровья спины трудно переоценить. Пружинные матрасы выполняются на блоке независимых пружин. В качестве наполнителя, перераспределяющего нагрузку, используются кокосовая койра, латекс, пенополиуретан, холлофайбер.</p></div></section>'''
    write(pg, layout(pg, title="Торбеевские матрасы — производство матрасов и товаров для сна в Москве и МО",
                     desc="Фабрика «Торбеевские матрасы»: матрасы, кровати, основания, топперы, наматрасники, детские модели. Собственное производство в Подмосковье, доставка по России.",
                     body=body, page_type="home"))

def cat_shell(pg, c=None):
    if c:
        items = [p for p in P if p["category"] == c["id"]]
        fallback = f'<h1>{e(c.get("title") or c["name"])}</h1><p class="muted">{e(c.get("intro", ""))}</p><ul class="fallback">' + "".join(f'<li><a href="{pg.u(p["path"])}">{e(full(p))}</a> — от {rub(p["min_price"])}</li>' for p in items) + "</ul>"
    else:
        fallback = "<h1>Каталог</h1>"
    return f'<div class="wrap" id="catApp">{fallback}</div>'

def build_category(c):
    pg = Page(c["url"]); g = next((x for x in GROUPS if x["id"] == c.get("group")), None)
    crumbs = ([(g["name"], g["url"])] if g and g["url"] != c["url"] else []) + [(c["name"], None)]
    write(pg, layout(pg, title=f"{c.get('title') or c['name']} — купить в Москве | {SHOP['name']}", desc=c.get("intro", c["name"]), body=cat_shell(pg, c),
                     page_type="category", attrs=f' data-cat="{e(c["id"])}"', crumbs=crumbs))

def build_product(p):
    pg = Page(p["path"]); c = CBY.get(p["category"], {"name": "", "url": ""})
    img = (p.get("images") or [""])[0]
    fallback = f'''<div class="pp-fallback"><h1>{e(full(p))}</h1>{f'<img src="{pg.a(img)}" alt="{e(full(p))}" width="600">' if img else ""}<p>Цена от {rub(p["min_price"])}</p></div>'''
    write(pg, layout(pg, title=f"{full(p)} — купить, цена от {rub(p['min_price'])} | {SHOP['name']}",
                     desc=f"{full(p)}: характеристики, размеры и цены. Производство фабрики «Торбеевские матрасы».",
                     body=f'<div class="wrap" id="ppApp">{fallback}</div>', page_type="product", attrs=f' data-pid="{e(p["id"])}"',
                     crumbs=[(c["name"], c["url"]), (p["name"], None)]))

def build_dynamic():
    pg = Page("katalog/")
    write(pg, layout(pg, title=f"Каталог — {SHOP['name']}", desc="Каталог", body=cat_shell(pg), page_type="category", crumbs=[("Каталог", None)]))
    pg = Page("tovar/")
    write(pg, layout(pg, title=f"Товар — {SHOP['name']}", desc="Товар", body='<div class="wrap" id="ppApp"><p class="muted">Загружаем…</p></div>', page_type="product", crumbs=[("Товар", None)]))
    pg = Page("akcii/")
    write(pg, layout(pg, title=f"Акции и скидки — {SHOP['name']}", desc="Действующие акции фабрики «Торбеевские матрасы»: скидки, распродажа, подарки, промокод.",
                     body='<div class="wrap" id="promoApp"><h1 class="page-h1">Акции и скидки</h1></div>', page_type="promos", crumbs=[("Акции", None)]))

def build_simple(path, ptype, title, inner, crumbs, lead=False, desc=""):
    pg = Page(path); write(pg, layout(pg, title=f"{title} — {SHOP['name']}", desc=desc or title, body=inner(pg), page_type=ptype, crumbs=crumbs, lead=lead))

POLICY = """<p>Настоящая Политика обработки персональных данных (далее — Политика) разработана в соответствии с Федеральным законом РФ №152-ФЗ «О персональных данных» и определяет порядок обработки персональных данных и меры по обеспечению их безопасности.</p>
<h2>1. Оператор персональных данных</h2><p>Оператор: ИП Геворгян Рубен Андрикович<br>ИНН: 342102450670<br>ОГРНИП: 323508100652805<br>Адрес: Люберецкий р-н, пос. Торбеево, д.50, стр. 1<br>Email: <a href="mailto:info@tmvo.ru">info@tmvo.ru</a></p>
<h2>2. Персональные данные, которые обрабатываются</h2><ul><li>ФИО</li><li>Номер телефона</li><li>Email</li><li>IP-адрес</li><li>Данные файлов cookie</li><li>Иные данные, предоставленные пользователем</li></ul>
<h2>3. Цели обработки персональных данных</h2><ul><li>Обработка заявок и обратной связи</li><li>Заключение и исполнение договоров</li><li>Информирование пользователя</li><li>Маркетинговые и рекламные рассылки (при согласии)</li><li>Аналитика и улучшение работы сайта</li></ul>
<h2>4. Правовые основания обработки</h2><p>Обработка осуществляется на основании:</p><ul><li>согласия субъекта персональных данных</li><li>необходимости исполнения договора</li><li>требований законодательства РФ</li></ul>
<h2>5. Порядок обработки и хранения</h2><p>Персональные данные обрабатываются с использованием автоматизированных и неавтоматизированных средств. Срок хранения данных — до достижения целей обработки либо до отзыва согласия пользователем.</p>
<h2>6. Передача третьим лицам</h2><p>Персональные данные могут передаваться третьим лицам:</p><ul><li>хостинг-провайдерам</li><li>сервисам аналитики</li><li>CRM-системам</li><li>сервисам рассылок</li></ul>
<h2>7. Трансграничная передача</h2><p>В случае использования зарубежных сервисов персональные данные могут передаваться за пределы РФ в соответствии с законодательством.</p>
<h2>8. Права субъекта персональных данных</h2><p>Пользователь имеет право:</p><ul><li>получить информацию о своих данных</li><li>требовать их уточнения или удаления</li><li>отозвать согласие на обработку</li></ul>
<h2>9. Отзыв согласия</h2><p>Отзыв согласия осуществляется путем направления запроса на email: <a href="mailto:info@tmvo.ru">info@tmvo.ru</a></p>
<h2>10. Меры защиты</h2><p>Оператор принимает необходимые организационные и технические меры для защиты персональных данных.</p>
<h2>11. Заключительные положения</h2><p>Политика может быть изменена без предварительного уведомления. Актуальная версия размещена на сайте.</p>"""

def build_info_pages():
    def dost(pg): return f'''<p class="lead">Доставляем по Москве, Московской области и во все регионы России. Можно забрать заказ самостоятельно из шоурума фабрики.</p>
<h2>Доставка курьером</h2><ul><li>Москва и Московская область — нашим транспортом, в заранее согласованный день и время.</li><li>Регионы России — транспортными компаниями до терминала или до двери.</li><li>Подъём на этаж и занос в квартиру — по договорённости.</li></ul>
<p>Стоимость доставки зависит от адреса и размера заказа — её рассчитает менеджер при подтверждении заказа.</p>
<h2>Самовывоз</h2><p>Шоурум и склад: {e(SHOP["address"])}. {e(SHOP["hours"])}. Пожалуйста, предупредите о визите заранее — менеджер сообщит, когда заказ будет готов. <a href="{pg.u("kontakty/")}">Схема проезда</a>.</p>
<h2>Сроки изготовления</h2><p>Матрасы делаются на нашем производстве. Срок изготовления зависит от модели и размера — менеджер назовёт его при подтверждении заказа. Модели из раздела <a href="{pg.u("sale/")}">«Распродажа»</a> есть в наличии.</p>
<h2>Оплата</h2><ul><li><b>Наличными</b> — курьеру при получении или в шоуруме.</li><li><b>Банковской картой</b> — МИР, Visa, MasterCard при получении.</li><li><b>Для организаций</b> — по счёту, свяжитесь с менеджером.</li></ul>
<h2>Возврат и обмен</h2><p>Возврат и обмен — в соответствии с Законом РФ «О защите прав потребителей». Товар надлежащего качества, купленный дистанционно, можно вернуть в течение 7 дней после получения, если сохранены его товарный вид и потребительские свойства (ст. 26.1). Это правило не распространяется на матрасы, изготовленные по индивидуальным размерам покупателя.</p>
<p>Если обнаружен производственный дефект — позвоните нам: заменим товар или вернём деньги. Подробнее — на странице <a href="{pg.u("garantiya/")}">«Гарантия»</a>.</p>'''
    build_simple("dostavka-i-oplata/", "info", "Доставка и оплата", lambda pg: f'<div class="wrap page-grid"><article class="prose"><h1>Доставка и оплата</h1>{dost(pg)}</article>{aside_help(pg)}</div>', [("Доставка и оплата", None)], lead=True,
                 desc="Доставка матрасов по Москве, МО и России, самовывоз из шоурума в Торбеево, оплата наличными и картой при получении.")
    def gar(pg): return f'''<p class="lead">На матрасы и топперы — гарантия 18 месяцев, на наматрасники — 14 дней. Срок гарантии каждой модели указан в её характеристиках.</p>
<h2>Что входит в гарантию</h2><p>Производственные дефекты: нарушение целостности пружинного блока, расхождение швов, отслоение слоёв наполнителя, деформация, не связанная с неправильной эксплуатацией.</p>
<h2>Что не является гарантийным случаем</h2><ul><li>механические повреждения, порезы, прожоги, следы жидкостей;</li><li>деформация из-за неподходящего основания (например, ламели с большим расстоянием или прогнувшееся дно);</li><li>естественное уплотнение верхних мягких слоёв в первые месяцы использования;</li><li>использование не по назначению: прыжки, сгибание, сидение на краю.</li></ul>
<h2>Как сохранить матрас</h2><ul><li>Кладите матрас на ровное основание: сплошное или с ламелями, расстояние между ними — не больше ширины ламели.</li><li>Раз в 3 месяца поворачивайте матрас «голова — ноги», двусторонний — переворачивайте.</li><li>Используйте наматрасник и не сгибайте пружинные матрасы при перевозке.</li></ul>
<h2>Как обратиться</h2><p>Позвоните по телефону {e(SHOP["phone"])} или напишите на {e(SHOP["email"])}: опишите проблему, приложите фото и номер заказа. Мы ответим и, если дефект подтвердится, заменим товар или вернём деньги.</p>'''
    build_simple("garantiya/", "info", "Гарантия", lambda pg: f'<div class="wrap page-grid"><article class="prose"><h1>Гарантия</h1>{gar(pg)}</article>{aside_help(pg)}</div>', [("Гарантия", None)], lead=True,
                 desc="Гарантия 18 месяцев на матрасы фабрики «Торбеевские матрасы».")
    mx = SHOP["max"] or f'tel:{SHOP["mphone_href"]}'
    def contacts(pg): return f'''<div class="wrap"><h1 class="page-h1">Контакты</h1><div class="contacts">
<div class="box"><h3>Связаться с нами</h3><dl class="kv"><dt>Телефон</dt><dd><a href="tel:{SHOP["phone_href"]}">{e(SHOP["phone"])}</a><small>Бесплатный звонок по РФ</small></dd>
<dt>Мессенджеры</dt><dd><a href="tel:{SHOP["mphone_href"]}">{e(SHOP["mphone"])}</a><small>MAX, Telegram</small><span class="big-msg"><a href="tel:{SHOP["phone_href"]}">{ICON["phone"]} Позвонить</a><a href="{mx}">{ICON["max"]} MAX</a><a href="{SHOP["tg"]}" target="_blank" rel="noopener">{ICON["tg"]} Telegram</a></span></dd>
<dt>Отдел продаж</dt><dd><a href="mailto:{SHOP["email"]}">{e(SHOP["email"])}</a></dd><dt>Время работы</dt><dd>{e(SHOP["hours"])}<small>Принимаем заказы и консультируем без выходных</small></dd>
<dt>Адрес шоурума</dt><dd>{e(SHOP["address"])}</dd></dl><button class="btn" data-callback>Заказать звонок</button></div>
<div class="map"><iframe src="https://yandex.ru/map-widget/v1/?mode=search&amp;text={e(MAP_Q)}&amp;z=15" title="Шоурум на Яндекс Картах" loading="lazy" allowfullscreen></iframe>
<a class="link" href="https://yandex.ru/maps/?mode=search&amp;text={e(MAP_Q)}" target="_blank" rel="noopener">Открыть в Яндекс Картах ↗</a></div></div>
<div class="box req"><h3>Реквизиты</h3><dl class="kv"><dt>Продавец</dt><dd>{e(SHOP["seller"])}</dd><dt>ИНН</dt><dd>{SHOP["inn"]}</dd><dt>ОГРНИП</dt><dd>{SHOP["ogrnip"]}</dd><dt>ОКПО</dt><dd>{SHOP["okpo"]}</dd><dt>Банк</dt><dd>{e(SHOP["bank"])}</dd><dt>БИК</dt><dd>{SHOP["bik"]}</dd><dt>Р/с</dt><dd>{SHOP["rs"]}</dd><dt>Корр/с</dt><dd>{SHOP["ks"]}</dd></dl></div></div>'''
    build_simple("kontakty/", "contacts", "Контакты", contacts, [("Контакты", None)], lead=True, desc=f"Контакты фабрики «Торбеевские матрасы»: {SHOP['phone']}, {SHOP['address']}.")
    build_simple("otzyvy/", "info", "Отзывы", lambda pg: f'<div class="wrap"><h1 class="page-h1">Отзывы покупателей</h1>{review_cards(REVIEWS)}</div>', [("Отзывы", None)], lead=True)
    build_simple("politika-konfidentsialnosti/", "info", "Политика конфиденциальности", lambda pg: f'<div class="wrap page-grid"><article class="prose"><h1>Политика конфиденциальности</h1>{POLICY}</article></div>', [("Политика конфиденциальности", None)])
    for path, key, extra in [("soglasie-na-obrabotku/", "Согласие на обработку персональных данных", "Текст согласия: перечень данных, цели обработки, действия с данными, срок действия согласия и порядок его отзыва."),
                             ("oferta/", "Публичная оферта", "Условия продажи товаров дистанционным способом: оформление заказа, цены, доставка, оплата, возврат и обмен, гарантия, условия акций и промокодов.")]:
        build_simple(path, "info", key, lambda pg, key=key, extra=extra: f'''<div class="wrap page-grid"><article class="prose"><h1>{e(key)}</h1>
<p class="ph-note">Здесь будет утверждённый текст документа. При изменении текста увеличьте номер версии в assets/js/config.js — он сохраняется вместе с согласием покупателя.</p>
<p>{e(extra)}</p><p>Продавец: {e(SHOP["seller"])}, ИНН {SHOP["inn"]}, ОГРНИП {SHOP["ogrnip"]}. Контакты: {e(SHOP["email"])}, {e(SHOP["phone"])}.</p></article></div>''', [(key, None)])

def build_shop_pages():
    build_simple("korzina/", "cart", "Корзина", lambda pg: '<div class="wrap"><h1 class="page-h1">Корзина</h1><div id="cart"><p class="muted">Загружаем корзину…</p></div></div>', [("Корзина", None)])
    build_simple("oformlenie/", "checkout", "Оформление заказа", lambda pg: '<div class="wrap" id="co-wrap"><h1 class="page-h1">Оформление заказа</h1><div class="co"><div class="co-main" id="co"></div><aside class="summary" id="co-sum"></aside></div></div>', [("Корзина", "korzina/"), ("Оформление", None)])
    build_simple("zakaz/", "order", "Заказ", lambda pg: '<div class="wrap"><div class="order" id="ord"><p class="muted">Загружаем заказ…</p></div></div>', [("Заказ", None)])
    build_simple("poisk/", "search", "Поиск", lambda pg: '<div class="wrap" id="searchApp"><h1 class="page-h1" id="stitle">Поиск</h1></div>', [("Поиск", None)])
    build_simple("izbrannoe/", "favorites", "Избранное", lambda pg: '<div class="wrap"><h1 class="page-h1">Избранное</h1><div class="grid" id="fres"></div></div>', [("Избранное", None)])

def build_admin():
    pg = Page("admin/")
    page = f'''<!DOCTYPE html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Панель управления — {e(SHOP["name"])}</title><meta name="robots" content="noindex, nofollow">
<link rel="icon" href="{pg.a("img/logo.svg")}" type="image/svg+xml">
<link href="https://fonts.googleapis.com/css2?family=Onest:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{pg.a("assets/css/style.css")}"><link rel="stylesheet" href="{pg.a("assets/css/admin.css")}"></head>
<body data-page="admin"><div id="adm"></div>
<script>window.TMVO_ROOT = "{pg.root}";</script>
<script src="{pg.a("assets/js/config.js")}"></script><script src="{pg.a("data/catalog.js")}"></script><script src="{pg.a("data/static.js")}"></script>
<script src="{pg.a("assets/js/data.js")}"></script><script src="{pg.a("assets/js/api.js")}"></script><script src="{pg.a("assets/js/admin.js")}"></script></body></html>'''
    os.makedirs(os.path.join(ROOT, "admin"), exist_ok=True)
    open(os.path.join(ROOT, "admin", "index.html"), "w", encoding="utf-8").write(page)

def build_meta():
    nf = '''<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Страница не найдена — Торбеевские матрасы</title>
<style>body{margin:0;font-family:system-ui,sans-serif;background:#F4F5F7;color:#1D2330;display:grid;place-items:center;min-height:100vh;padding:16px;text-align:center}a{color:#A9532A;font-weight:600}</style></head>
<body><div><h1>Страница не найдена</h1><p>Возможно, ссылка устарела.</p><p><a id="home" href="./">На главную</a></p></div>
<script>(function(){var p=location.pathname.split("/");var root=location.hostname.endsWith("github.io")&&p[1]?"/"+p[1]+"/":"/";document.getElementById("home").href=root+"index.html";})();</script></body></html>'''
    open(os.path.join(ROOT, "404.html"), "w", encoding="utf-8").write(nf)
    open(os.path.join(ROOT, "robots.txt"), "w").write("User-agent: *\nDisallow: /\n" if NOINDEX else f"User-agent: *\nAllow: /\nDisallow: /admin/\nSitemap: {SITE_URL}sitemap.xml\n")
    urls = "".join(f"<url><loc>{SITE_URL}{p}</loc></url>" for p in PAGES)
    open(os.path.join(ROOT, "sitemap.xml"), "w").write(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{urls}</urlset>\n')
    open(os.path.join(ROOT, ".nojekyll"), "w").write("")
    # какие страницы существуют как файлы — сайт строит ссылки на них, остальное открывает через tovar/ и katalog/
    static = {"products": {p["id"]: p["path"] for p in P}, "categories": {c["id"]: c["url"] for c in CATS}}
    open(os.path.join(ROOT, "data", "static.js"), "w", encoding="utf-8").write("window.TMVO_STATIC=" + json.dumps(static, ensure_ascii=False, separators=(",", ":")) + ";\n")

MANIFEST = os.path.join(ROOT, "tools", ".generated.json")
def clean_old():
    """Удаляет страницы прошлой сборки (только те, что создал этот скрипт)."""
    if not os.path.exists(MANIFEST): return
    for rel in json.load(open(MANIFEST)):
        f = os.path.join(ROOT, rel, "index.html")
        if rel and os.path.exists(f):
            os.remove(f)
            d = os.path.dirname(f)
            while d != ROOT and os.path.isdir(d) and not os.listdir(d): os.rmdir(d); d = os.path.dirname(d)

if __name__ == "__main__":
    clean_old()
    build_home()
    for c in CATS: build_category(c)
    for p in P: build_product(p)
    build_dynamic(); build_info_pages(); build_shop_pages(); build_admin(); build_meta()
    json.dump(PAGES, open(MANIFEST, "w"), ensure_ascii=False)
    print("страниц:", len(PAGES) + 1, "(включая админку)")
