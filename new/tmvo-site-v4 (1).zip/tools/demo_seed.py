"""
Начальные данные v4, которых нет в Excel-каталоге:
  • Кровати — ПРИМЕРЫ (example: true): названия, цены и характеристики придуманы, чтобы показать раздел.
    Иллюстрации рисуются здесь же (SVG), с подписью «Иллюстрация».
  • Кроватные основания — НАСТОЯЩИЕ цены из Roznica_ceni.xlsx, лист «основания 100724» (цены с 10.07.2024).
  • Акции — ПРИМЕРЫ всех видов: скидка на товары, скидка на раздел, подарок, промокод, запланированная и завершённая.
Используется из build_data.py (--demo, --bases).
"""
import os, re

# ---------------------------------------------------------------- иллюстрации кроватей (SVG)
W, H = 1200, 800
NOTE = '<text x="28" y="778" font-family="Onest,Arial,sans-serif" font-size="22" fill="#000" fill-opacity=".38">Иллюстрация</text>'

def shade(hex_, k):
    h = hex_.lstrip("#"); r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    f = (lambda c: max(0, min(255, int(c * k)))) if k < 1 else (lambda c: max(0, min(255, int(c + (255 - c) * (k - 1)))))
    return "#%02x%02x%02x" % (f(r), f(g), f(b))

def headboard(style, x, y, w, h, c):
    d, l = shade(c, .82), shade(c, 1.12)
    out = []
    if style == "rounded":
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="70" fill="{c}"/><rect x="{x+22}" y="{y+22}" width="{w-44}" height="{h-30}" rx="52" fill="none" stroke="{d}" stroke-width="6"/>')
    elif style == "stitch":
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="18" fill="{c}"/>')
        for row in range(4):
            for col in range(9):
                cx = x + 50 + col * (w - 100) / 8 + (0 if row % 2 == 0 else (w - 100) / 16)
                cy = y + 45 + row * (h - 80) / 3.4
                if cx < x + w - 30:
                    out.append(f'<circle cx="{cx:.0f}" cy="{cy:.0f}" r="7" fill="{d}"/>')
        out.append(f'<path d="M{x+40} {y+h-20} L{x+w-40} {y+h-20}" stroke="{d}" stroke-width="3"/>')
    elif style == "panel":
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="{c}"/>')
        out.append(f'<rect x="{x+24}" y="{y+24}" width="{w-48}" height="{h/2-34}" rx="12" fill="{l}"/><rect x="{x+24}" y="{y+h/2+4}" width="{w-48}" height="{h/2-34}" rx="12" fill="{l}"/>')
    elif style == "channels":
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="30" fill="{d}"/>')
        n = 9; sw = (w - 30) / n
        for i in range(n):
            out.append(f'<rect x="{x+15+i*sw+4:.0f}" y="{y+14}" width="{sw-8:.0f}" height="{h-24}" rx="{(sw-8)/2:.0f}" fill="{c}"/>')
    elif style == "wood":
        out.append(f'<rect x="{x}" y="{y+30}" width="{w}" height="{h-30}" fill="{c}"/><rect x="{x-18}" y="{y}" width="40" height="{h+150}" fill="{d}"/><rect x="{x+w-22}" y="{y}" width="40" height="{h+150}" fill="{d}"/>')
        for i in range(1, 8):
            out.append(f'<rect x="{x+i*w/8-9:.0f}" y="{y+40}" width="18" height="{h-50}" fill="{l}"/>')
    elif style == "wings":
        out.append(f'<rect x="{x-60}" y="{y+40}" width="{w+120}" height="{h-40}" rx="26" fill="{d}"/><rect x="{x+40}" y="{y}" width="{w-80}" height="{h}" rx="26" fill="{c}"/>')
        out.append(f'<path d="M{x+80} {y+40} V{y+h-30} M{x+w-80} {y+40} V{y+h-30}" stroke="{d}" stroke-width="4"/>')
    return "".join(out)

def bed_room(m):
    c = m["color"]; frame = shade(c, .9) if m["style"] != "wood" else shade(c, .85)
    x, w = 240, 720
    hb = headboard(m["style"], x + 10, 200, w - 20, 300, c)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}"><defs><linearGradient id="wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F3EFE9"/><stop offset="1" stop-color="#E6DFD6"/></linearGradient></defs>
<rect width="{W}" height="{H}" fill="url(#wall)"/><rect y="640" width="{W}" height="160" fill="#CDBFAE"/><rect y="640" width="{W}" height="6" fill="#B9A994"/>
<rect x="80" y="120" width="120" height="170" rx="6" fill="#fff" stroke="#D8CEC1" stroke-width="6"/><path d="M95 260 l30 -50 l25 30 l20 -20 l25 45z" fill="#C9D3C0"/>
<rect x="1010" y="470" width="120" height="170" rx="8" fill="#BFA98F"/><rect x="1030" y="440" width="10" height="30" fill="#8E7B66"/><ellipse cx="1060" cy="430" rx="46" ry="26" fill="#F6E6C8"/>
{hb}
<rect x="{x}" y="500" width="{w}" height="120" rx="16" fill="{frame}"/>
<rect x="{x+16}" y="452" width="{w-32}" height="62" rx="14" fill="#FAF8F5" stroke="#E2DCD3" stroke-width="3"/>
<rect x="{x+60}" y="400" width="250" height="78" rx="34" fill="#FFFFFF" stroke="#E6E0D8" stroke-width="3"/><rect x="{x+w-310}" y="400" width="250" height="78" rx="34" fill="#FFFFFF" stroke="#E6E0D8" stroke-width="3"/>
<path d="M{x+10} 492 Q {x+w/2} 470 {x+w-10} 492 L{x+w-6} 560 Q {x+w/2} 580 {x+6} 560 Z" fill="{m['throw']}"/>
<rect x="{x+20}" y="620" width="26" height="22" fill="#5A4B3C"/><rect x="{x+w-46}" y="620" width="26" height="22" fill="#5A4B3C"/>
{NOTE}</svg>'''

def bed_lift(m):
    c = m["color"]; frame = shade(c, .9)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}"><rect width="{W}" height="{H}" fill="#F1EEEA"/><rect y="650" width="{W}" height="150" fill="#D9D1C6"/>
<rect x="150" y="190" width="70" height="460" rx="16" fill="{c}"/>
<rect x="220" y="520" width="830" height="130" rx="10" fill="{frame}"/><rect x="240" y="530" width="790" height="100" fill="#3B342D" fill-opacity=".85"/>
<rect x="270" y="560" width="220" height="50" rx="10" fill="#E9E2D6"/><rect x="510" y="566" width="180" height="44" rx="10" fill="#C9D6E3"/><rect x="710" y="560" width="200" height="50" rx="10" fill="#EFE0D0"/>
<g transform="rotate(-24 230 520)"><rect x="230" y="470" width="820" height="50" rx="8" fill="#B78F63"/>{"".join(f'<rect x="{250+i*66}" y="462" width="44" height="12" rx="4" fill="#D9B98C"/>' for i in range(12))}
<rect x="232" y="410" width="816" height="60" rx="14" fill="#FAF8F5" stroke="#E2DCD3" stroke-width="3"/></g>
<path d="M330 600 L520 420" stroke="#7D838C" stroke-width="10" stroke-linecap="round"/><path d="M880 600 L900 300" stroke="#7D838C" stroke-width="10" stroke-linecap="round"/>
<text x="640" y="720" text-anchor="middle" font-family="Onest,Arial,sans-serif" font-size="30" fill="#4A4F57">Подъёмный механизм на газлифтах · ящик для белья</text>{NOTE}</svg>'''

def bed_detail(m):
    c = m["color"]
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}"><defs><pattern id="tx" width="8" height="8" patternUnits="userSpaceOnUse"><path d="M0 8L8 0" stroke="#000" stroke-opacity=".06" stroke-width="2"/></pattern></defs>
<rect width="{W}" height="{H}" fill="{shade(c, .7)}"/>
<g transform="translate(-260 -120) scale(1.6)">{headboard(m["style"], 220, 150, 760, 420, c)}</g><rect width="{W}" height="{H}" fill="url(#tx)"/>
<rect x="40" y="640" width="560" height="110" rx="18" fill="#fff" fill-opacity=".92"/><text x="70" y="690" font-family="Onest,Arial,sans-serif" font-size="34" font-weight="700" fill="#1D2330">{"Обивка: " + m["fabric"] if m["fabric"] != "Без обивки" else "Каркас: " + m["frame"].lower()}</text>
<text x="70" y="730" font-family="Onest,Arial,sans-serif" font-size="26" fill="#4A4F57">Цвет: {m["color_name"]}</text>{NOTE.replace('fill="#000"', 'fill="#fff"')}</svg>'''

def bed_dims(m):
    hb, base = m["hb"], m["base_h"]
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Onest,Arial,sans-serif"><rect width="{W}" height="{H}" fill="#FFFFFF"/>
<g fill="none" stroke="#1D2330" stroke-width="5"><rect x="190" y="{620-hb*3.2:.0f}" width="60" height="{hb*3.2:.0f}" rx="10"/><rect x="250" y="{620-base*3.2:.0f}" width="760" height="{base*3.2:.0f}" rx="8"/>
<rect x="260" y="{620-base*3.2-60:.0f}" width="740" height="60" rx="12" stroke-dasharray="14 10" stroke="#9AA0A6"/></g>
<g stroke="#C56532" stroke-width="3" fill="#C56532"><path d="M190 690 H1010"/><path d="M190 675v30M1010 675v30"/><path d="M120 620 V{620-hb*3.2:.0f}"/><path d="M105 620h30M105 {620-hb*3.2:.0f}h30"/><path d="M1080 620 V{620-base*3.2:.0f}"/><path d="M1065 620h30M1065 {620-base*3.2:.0f}h30"/></g>
<g font-size="30" fill="#1D2330" font-weight="700"><text x="600" y="740" text-anchor="middle">{m["length_total"]} см</text><text x="60" y="{620-hb*1.6:.0f}" transform="rotate(-90 60 {620-hb*1.6:.0f})" text-anchor="middle">{hb} см</text>
<text x="1140" y="{620-base*1.6:.0f}" transform="rotate(-90 1140 {620-base*1.6:.0f})" text-anchor="middle">{base} см</text></g>
<text x="630" y="{620-base*3.2-80:.0f}" text-anchor="middle" font-size="24" fill="#9AA0A6">матрас</text>
<text x="600" y="90" text-anchor="middle" font-size="34" font-weight="700" fill="#1D2330">Размеры для спального места 160×200</text>{NOTE}</svg>'''

def bed_colors(m):
    sw = m["colors"]; n = len(sw); step = 1000 / n
    items = "".join(f'<circle cx="{100+step*i+step/2:.0f}" cy="380" r="{min(130, step/2-20):.0f}" fill="{hx}" stroke="#E2E5EA" stroke-width="4"/><text x="{100+step*i+step/2:.0f}" y="580" text-anchor="middle" font-size="32" fill="#1D2330">{nm}</text>' for i, (nm, hx) in enumerate(sw))
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Onest,Arial,sans-serif"><rect width="{W}" height="{H}" fill="#F8F9FA"/>
<text x="600" y="130" text-anchor="middle" font-size="40" font-weight="700" fill="#1D2330">{"Цвета обивки «" + m["fabric"] + "»" if m["fabric"] != "Без обивки" else "Варианты покрытия"}</text>{items}
<text x="600" y="690" text-anchor="middle" font-size="26" fill="#636B7A">Другие цвета — по каталогу тканей, уточните у менеджера</text>{NOTE}</svg>'''

def base_svg(kind, view):
    wide = "Л63" in kind; split = "Разборное" in kind
    if view == "top":
        slats = []
        n = 15 if wide else 22
        for i in range(n):
            y = 150 + i * (500 / n)
            if wide:
                slats.append(f'<rect x="230" y="{y:.0f}" width="740" height="{500/n*0.62:.0f}" rx="8" fill="#D9B98C" stroke="#B78F63" stroke-width="2"/>')
            else:
                for dx in (0, 380):
                    slats.append(f'<rect x="{235+dx}" y="{y:.0f}" width="350" height="{500/n*0.5:.0f}" rx="5" fill="#D9B98C" stroke="#B78F63" stroke-width="2"/>')
        mid = '<rect x="590" y="120" width="20" height="560" fill="#5C6470"/>' if (split or not wide) else ""
        cut = '<path d="M600 110 V690" stroke="#C56532" stroke-width="4" stroke-dasharray="16 10"/>' if split else ""
        return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Onest,Arial,sans-serif"><rect width="{W}" height="{H}" fill="#F4F5F7"/>
<rect x="200" y="110" width="800" height="580" rx="10" fill="none" stroke="#3B4350" stroke-width="22"/>{mid}{"".join(slats)}{cut}
<text x="600" y="760" text-anchor="middle" font-size="30" fill="#1D2330">{"Широкие ламели Л63" if wide else "Узкие двойные ламели Л35"}{" · разборная рама" if split else ""}</text>
<text x="28" y="40" font-size="22" fill="#000" fill-opacity=".38">Схема</text></svg>'''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Onest,Arial,sans-serif"><rect width="{W}" height="{H}" fill="#FFFFFF"/>
<rect x="160" y="360" width="880" height="70" rx="8" fill="#3B4350"/>{"".join(f'<path d="M{200+i*58} 360 q 29 -{30 if wide else 22} 58 0" fill="none" stroke="#D9B98C" stroke-width="{14 if wide else 8}"/>' for i in range(14))}
<rect x="190" y="430" width="34" height="140" fill="#5C6470"/><rect x="976" y="430" width="34" height="140" fill="#5C6470"/><rect x="583" y="430" width="34" height="140" fill="#5C6470"/>
<text x="600" y="660" text-anchor="middle" font-size="30" fill="#1D2330">Ламели с прогибом — пружинят под весом и проветривают матрас</text>
<text x="28" y="40" font-size="22" fill="#000" fill-opacity=".38">Схема</text></svg>'''

# ---------------------------------------------------------------- кровати (примеры)
BEDS = [
    dict(id="krovat-assol", name="Ассоль", style="rounded", color="#D9A9A0", color_name="пудровый", throw="#F2E4DC", fabric="Велюр",
         colors=[("пудровый", "#D9A9A0"), ("серый", "#9AA0A6"), ("графит", "#4A4F57"), ("молочный", "#EDE6DA")],
         sizes={(140, 200): 32990, (160, 200): 35990, (180, 200): 39990}, lift="Да", box="Да", frame="ЛДСП", base="Ортопедическое на ламелях", hb=110, base_h=34),
    dict(id="krovat-verona", name="Верона", style="stitch", color="#ECE8E1", color_name="белый жемчуг", throw="#D7CFC2", fabric="Экокожа",
         colors=[("белый", "#ECE8E1"), ("кофе", "#7A5C47"), ("чёрный", "#2A2C30")],
         sizes={(160, 200): 44990, (180, 200): 48990}, lift="Да", box="Да", frame="МДФ", base="Ортопедическое на ламелях", hb=120, base_h=36),
    dict(id="krovat-lira", name="Лира", style="panel", color="#9AA0A6", color_name="серый", throw="#E5E7EA", fabric="Рогожка",
         colors=[("серый", "#9AA0A6"), ("бежевый", "#CDBBA4"), ("синий", "#3E5170")],
         sizes={(90, 200): 18990, (120, 200): 21990, (140, 200): 23990, (160, 200): 25990, (140, 190): 23990, (160, 190): 25990}, lift="Нет", box="Нет", frame="ЛДСП", base="Ортопедическое на ламелях", hb=100, base_h=30),
    dict(id="krovat-medison", name="Мэдисон", style="channels", color="#2F6B5A", color_name="изумрудный", throw="#E9DCC6", fabric="Велюр",
         colors=[("изумрудный", "#2F6B5A"), ("горчичный", "#C49A3A"), ("терракота", "#B5654A"), ("графит", "#4A4F57")],
         sizes={(160, 200): 52990, (180, 200): 56990, (200, 200): 61990}, lift="Да", box="Да", frame="Массив сосны", base="Ортопедическое на ламелях", hb=125, base_h=35),
    dict(id="krovat-nordik", name="Нордик", style="wood", color="#D9B98C", color_name="натуральная сосна", throw="#E8EEF2", fabric="Без обивки",
         colors=[("натуральный", "#D9B98C"), ("белый", "#F1EEE8"), ("орех", "#8B6A4E")],
         sizes={(90, 200): 21990, (140, 200): 29990, (160, 200): 32990}, lift="Нет", box="Нет", frame="Массив сосны", base="Ортопедическое на ламелях", hb=95, base_h=32),
    dict(id="krovat-skandi", name="Сканди", style="wings", color="#CDBBA4", color_name="бежевый", throw="#F4EFE7", fabric="Шенилл",
         colors=[("бежевый", "#CDBBA4"), ("оливковый", "#7D8460"), ("серый", "#9AA0A6")],
         sizes={(140, 200): 27990, (160, 200): 30990}, lift="Нет", box="Да", frame="ЛДСП", base="Сплошное (ЛДСП)", hb=115, base_h=33),
]

def beds(img_dir):
    out = []
    for m in BEDS:
        m = dict(m); m["length_total"] = 214 if m["style"] != "wood" else 208
        views = [("room", bed_room), ("detail", bed_detail)] + ([("lift", bed_lift)] if m["lift"] == "Да" else []) + [("dims", bed_dims), ("colors", bed_colors)]
        imgs = []
        for i, (v, fn) in enumerate(views[:5], 1):
            fn_ = f"{m['id']}-{i}.svg"; open(os.path.join(img_dir, fn_), "w", encoding="utf-8").write(fn(m)); imgs.append("img/products/" + fn_)
        specs = {"Материал каркаса": m["frame"], "Обивка": m["fabric"], "Цвет": m["color_name"] + " (ещё: " + ", ".join(n for n, _ in m["colors"][1:]) + ")",
                 "Основание": m["base"], "Подъёмный механизм": m["lift"], "Ящик для белья": m["box"],
                 "Габариты (Д×Ш×В), см": f"{m['length_total']}×{176 if m['style'] != 'wings' else 196}×{m['hb']}", "Высота изголовья, см": str(m["hb"]),
                 "Высота до основания, см": str(m["base_h"]), "Нагрузка на спальное место, кг": "140" if m["frame"] != "Массив сосны" else "160",
                 "Матрас в комплекте": "Подберём отдельно", "Срок изготовления": "7–14 рабочих дней", "Гарантия": "1.5", "Страна производства": "Россия"}
        out.append({"id": m["id"], "name": m["name"], "category": "krovati", "word": "Кровать", "path": f"krovati/{m['id']}/",
                    "variants": [{"w": w, "l": l, "price": p} for (w, l), p in sorted(m["sizes"].items())], "specs": specs,
                    "images": imgs, "example": True})
    return out

# ---------------------------------------------------------------- основания (настоящий прайс)
def bases(xlsx, img_dir):
    import openpyxl
    ws = openpyxl.load_workbook(xlsx, read_only=True, data_only=True)["основания 100724"]
    rows = [[c for c in r] for r in ws.iter_rows(values_only=True)]
    hdr = None; out = []
    for r in rows:
        cells = [str(c).strip() if c is not None else "" for c in r]
        if any(re.fullmatch(r"\d{3,4}х\d{4}", c) for c in cells) and hdr is None:
            hdr = r; size_cols = [(i, c) for i, c in enumerate(cells) if re.fullmatch(r"\d{3,4}х\d{4}", c)]; continue
        if hdr is not None and cells and cells[0].startswith(("Основание", "Разборное")):
            name = cells[0]; variants = []
            prices = [c for c in r[1:] if c not in (None, "")]
            for (i, sz), price in zip(size_cols, prices):
                w, l = (int(x) // 10 for x in sz.split("х"))
                lens = [l] if w == 200 else [190, 200]
                for L in lens: variants.append({"w": w, "l": L, "price": int(float(price))})
            wide = "Л63" in name; split = name.startswith("Разборное")
            pid = "osnovanie-" + ("razbornoe-" if split else "") + ("l63" if wide else "l35")
            imgs = []
            for j, v in enumerate(("top", "side"), 1):
                fn = f"{pid}-{j}.svg"; open(os.path.join(img_dir, fn), "w", encoding="utf-8").write(base_svg(name, v)); imgs.append("img/products/" + fn)
            nice = ("Разборное основание" if split else "Основание") + (" с широкими ламелями Л63" if wide else " с узкими двойными ламелями Л35")
            out.append({"id": pid, "name": nice, "category": "osnovaniya", "word": "", "path": f"krovati/osnovaniya/{pid}/",
                        "variants": sorted(variants, key=lambda v: (v["w"], v["l"])), "images": imgs,
                        "specs": {"Ламели": "Широкие Л63" if wide else "Узкие Л35, двойные", "Разборное": "Да" if split else "Нет"},
                        "price_note": "Розничный прайс оснований от 10.07.2024"})
    return out

# ---------------------------------------------------------------- акции (примеры всех видов)
POPULAR = ["matras-imperator", "matras-iris", "matras-zevs", "matras-lotos", "matras-germes", "matras-virtuoz", "matras-afrodita", "matras-sultan"]
def promos(product_ids):
    pop = [i for i in POPULAR if i in product_ids]
    return [
        {"id": "osen-20", "type": "percent", "title": "Осенняя распродажа", "pct": 20, "products": pop, "categories": [],
         "from": "2026-10-01", "to": "2026-11-02", "home": True, "color": "red",
         "text": "−20% на 8 популярных моделей матрасов. Скидка уже в цене каждого размера."},
        {"id": "toppery-10", "type": "percent", "title": "Топперы −10%", "pct": 10, "products": [], "categories": ["toppery"],
         "from": "2026-10-15", "to": "2026-11-16", "home": True, "color": "blue",
         "text": "Скидка на весь раздел «Топперы» — выровняйте диван или старый матрас."},
        {"id": "krovati-15", "type": "percent", "title": "Новинка: кровати −15%", "pct": 15, "products": [], "categories": ["krovati"],
         "from": "2026-10-10", "to": "2026-12-01", "home": True, "color": "green",
         "text": "Открытие раздела кроватей — скидка 15% на все модели."},
        {"id": "podarok-namatrasnik", "type": "gift", "title": "Наматрасник в подарок", "products": [], "categories": ["matrasy"], "min_width": 160,
         "gift": "Наматрасник «Аква» в размер матраса", "from": "2026-10-01", "to": "2026-12-01", "home": True, "color": "violet",
         "text": "При покупке любого матраса шириной от 160 см — непромокаемый наматрасник в подарок. Менеджер добавит его к заказу."},
        {"id": "kod-torbeevo", "type": "code", "title": "Промокод ТОРБЕЕВО", "pct": 5, "code": "ТОРБЕЕВО", "products": [], "categories": [],
         "from": "2026-10-01", "to": "2027-01-01", "home": True, "color": "dark",
         "text": "Ещё −5% на товары без скидки. Введите промокод в корзине."},
        {"id": "black-friday", "type": "percent", "title": "Чёрная пятница −25%", "pct": 25, "products": [], "categories": ["matrasy"],
         "from": "2026-11-27", "to": "2026-12-01", "home": True, "color": "dark",
         "text": "Запланированная акция: включится сама 27 ноября и выключится 1 декабря."},
        {"id": "leto-2026", "type": "percent", "title": "Летние цены −12%", "pct": 12, "products": [], "categories": ["toppery", "namatrasniki"],
         "from": "2026-06-01", "to": "2026-09-01", "home": False, "color": "blue",
         "text": "Завершённая акция — пример: на сайте не показывается, хранится для истории."},
    ]
