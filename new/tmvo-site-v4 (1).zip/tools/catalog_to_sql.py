"""
Этап 2: превращает data/catalog.json (v4) в SQL для загрузки в базу (db/schema.sql).
    python tools/catalog_to_sql.py > db/catalog_data.sql
    psql -d tmvo -f db/schema.sql && psql -d tmvo -f db/catalog_data.sql
"""
import json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
C = json.load(open(os.path.join(ROOT, "data", "catalog.json"), encoding="utf-8"))
q = lambda v: "NULL" if v is None or v == "" else "'" + str(v).replace("'", "''") + "'"
js = lambda v: q(json.dumps(v, ensure_ascii=False)) + "::jsonb"
def num(v):
    try: return str(float(str(v).replace(",", ".")))
    except ValueError: return "NULL"
out = ["BEGIN;", "TRUNCATE product_images, product_variants, promotion_targets, promotions, products, categories, menu_groups CASCADE;"]
for i, g in enumerate(C.get("groups", [])):
    out.append(f"INSERT INTO menu_groups (id, name, url, sort) VALUES ({q(g['id'])}, {q(g['name'])}, {q(g.get('url'))}, {i});")
for i, c in enumerate(C["categories"]):
    out.append("INSERT INTO categories (id, group_id, name, title, intro, url, word, sort, in_menu, fields, filters) VALUES (" + ", ".join([
        q(c["id"]), q(c.get("group")), q(c["name"]), q(c.get("title")), q(c.get("intro")), q(c["url"]), q(c.get("word")), str(c.get("sort") or i),
        "false" if c.get("menu") is False else "true", js(c.get("fields", [])), js(c.get("filters", []))]) + ");")
for p in sorted(C["products"], key=lambda p: p.get("base_id") is not None):
    s = p.get("specs", {})
    out.append("INSERT INTO products (id, category_id, name, word, path, is_active, is_example, hardness_top, hardness_bottom, is_two_sided, has_springs, height_cm, specs, base_product_id, regular_price) VALUES (" + ", ".join([
        q(p["id"]), q(p["category"]), q(p["name"]), ("'" + str(p.get("word") or "").replace("'", "''") + "'"), q(p.get("path") or p["id"] + "/"), "false" if p.get("active") is False else "true", "true" if p.get("example") else "false",
        q(s.get("Жесткость верх")), q(s.get("Жесткость низ")),
        "true" if s.get("Категория: Двухсторонний") == "Да" else "false", "true" if s.get("Категория: Пружины") == "С пружинами" else "false",
        num(s.get("Высота матраса")) if s.get("Высота матраса") else "NULL", js(s),
        q(p.get("base_id")), str(p["regular_price"]) if p.get("regular_price") else "NULL"]) + ");")
    for v in p["variants"]:
        out.append(f"INSERT INTO product_variants (product_id, width_cm, length_cm, price, in_stock) VALUES ({q(p['id'])}, {v['w']}, {v['l']}, {v['price']}, {'1' if p['category'] == 'sale' else 'NULL'});")
    for k, f in enumerate(p.get("images") or ([p["image"]] if p.get("image") else [])):
        out.append(f"INSERT INTO product_images (product_id, file, is_main, sort) VALUES ({q(p['id'])}, {q(f)}, {'true' if k == 0 else 'false'}, {k});")
for x in C.get("promos", []):
    out.append("INSERT INTO promotions (id, type, title, text, percent, gift, min_width, code, starts_on, ends_on, is_active, show_banner, color) VALUES (" + ", ".join([
        q(x["id"]), q(x["type"]), q(x["title"]), q(x.get("text")), str(x["pct"]) if x.get("pct") else "NULL", q(x.get("gift")), str(x["min_width"]) if x.get("min_width") else "NULL",
        q(x.get("code")), q(x["from"]), q(x["to"]), "false" if x.get("active") is False else "true", "false" if x.get("home") is False else "true", q(x.get("color"))]) + ");")
    for pid in x.get("products", []): out.append(f"INSERT INTO promotion_targets (promotion_id, product_id) VALUES ({q(x['id'])}, {q(pid)});")
    for cid in x.get("categories", []): out.append(f"INSERT INTO promotion_targets (promotion_id, category_id) VALUES ({q(x['id'])}, {q(cid)});")
out.append("COMMIT;")
print("\n".join(out))
