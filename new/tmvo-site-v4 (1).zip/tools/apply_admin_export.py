"""
Применить каталог, скачанный из админки (Данные → «Скачать catalog.json»), к папке сайта.

    python tools/apply_admin_export.py ~/Downloads/catalog.json

1. Новые фото из черновика (data:…;base64) сохраняются в img/products/<id>-<n>.jpg, в каталоге — путь к файлу.
2. Пишутся data/catalog.json и data/catalog.js.
3. Пересобираются страницы (tools/build_site.py) — у новых товаров и разделов появляются свои адреса.
Дальше — закоммитить папку в репозиторий (GitHub Pages обновит сайт).
"""
import base64, json, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "data", "catalog.json")
C = json.load(open(src, encoding="utf-8"))
img_dir = os.path.join(ROOT, "img", "products"); os.makedirs(img_dir, exist_ok=True)
saved = 0
for p in C["products"]:
    out = []
    for k, s in enumerate(p.get("images") or []):
        m = re.match(r"^data:image/(\w+)(?:\+xml)?;base64,(.*)$", s, re.S)
        if m:
            ext = {"jpeg": "jpg", "svg": "svg"}.get(m.group(1), m.group(1))
            name = f"{p['id']}-{k + 1}.{ext}"; n = 1
            while os.path.exists(os.path.join(img_dir, name)): n += 1; name = f"{p['id']}-{k + 1}-{n}.{ext}"
            open(os.path.join(img_dir, name), "wb").write(base64.b64decode(m.group(2))); s = "img/products/" + name; saved += 1
        out.append(s)
    p["images"] = out; p.pop("image", None)
    if p.get("variants"): p["min_price"] = min(v["price"] for v in p["variants"])
C.setdefault("version", 4)
json.dump(C, open(os.path.join(ROOT, "data", "catalog.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
open(os.path.join(ROOT, "data", "catalog.js"), "w", encoding="utf-8").write("window.CATALOG=" + json.dumps(C, ensure_ascii=False, separators=(",", ":")) + ";\n")
print(f"товаров: {len(C['products'])}, разделов: {len(C['categories'])}, акций: {len(C.get('promos', []))}, новых фото сохранено: {saved}")
subprocess.run([sys.executable, os.path.join(ROOT, "tools", "build_site.py")], check=True)
