/*
 * Слой работы с сервером. Интерфейс одинаковый для режимов "mock" и "api".
 * Контракт запросов и ответов описан в TECH_SPEC.md, раздел 5.
 */
(function () {
  const CFG = window.TMVO_CONFIG;
  const LS_ORDERS = "tmvo_mock_orders";
  const LS_CALLBACKS = "tmvo_mock_callbacks";
  const LS_SEQ = "tmvo_mock_seq";

  function lsGet(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* хранилище недоступно — макет работает до перезагрузки */ } }
  const memory = { orders: null };
  function loadOrders() { if (memory.orders) return memory.orders; memory.orders = lsGet(LS_ORDERS, {}); return memory.orders; }
  function saveOrders() { lsSet(LS_ORDERS, memory.orders); }
  const delay = (ms) => new Promise((r) => setTimeout(r, ms));
  const token = () => Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
  const now = () => new Date().toISOString();

  /* ---------- общие проверки (сервер обязан делать то же самое) ---------- */
  function normPhone(p) {
    let d = String(p || "").replace(/\D/g, "");
    if (d.length === 11 && (d[0] === "7" || d[0] === "8")) d = d.slice(1);
    return d.length === 10 ? "+7" + d : null;
  }
  function checkConsents(c) {
    if (!c || c.privacy !== true || c.personal_data !== true) throw apiError("consent_required", "Нужно согласие на обработку персональных данных");
  }
  function apiError(code, message) { const e = new Error(message); e.code = code; return e; }

  /* ---------- цены и акции (одна логика для всего сайта; сервер обязан считать так же) ----------
     Акции — массив CATALOG.promos. Виды:
       percent — скидка % на товары (products) и/или разделы (categories); в цене сразу. Если подходят несколько — берётся наибольшая.
       gift    — подарок к товару (gift — текст), можно ограничить шириной от min_width. Цену не меняет.
       code    — промокод (code): ещё −pct% на товары без другой скидки; вводится в корзине.
     Период: from включительно, to НЕ включительно (YYYY-MM-DD). active:false — выключена вручную.
     Распродажа (раздел sale) — свои цены, акции % к ней не применяются. */
  function today() { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  const promos = () => (window.CATALOG && window.CATALOG.promos) || [];
  const isLive = (x, day) => x.active !== false && x.from <= (day || today()) && (day || today()) < x.to;
  const promoState = (x, day) => x.active === false ? "off" : (day || today()) < x.from ? "planned" : (day || today()) >= x.to ? "ended" : "live";
  const applies = (x, p) => !!p && p.category !== "sale" && (((x.products || []).includes(p.id)) || ((x.categories || []).includes(p.category)) || (x.type === "code" && !(x.products || []).length && !(x.categories || []).length));
  function livePromos(day) { return promos().filter((x) => isLive(x, day)); }
  function percentFor(p, day) { let best = null; livePromos(day).forEach((x) => { if (x.type === "percent" && applies(x, p) && (!best || x.pct > best.pct)) best = x; }); return best; }
  function giftsFor(p, w, day) { return livePromos(day).filter((x) => x.type === "gift" && applies(x, p) && (!x.min_width || (w ? w >= x.min_width : p.variants.some((v) => v.w >= x.min_width)))); }
  function untilOf(x) { const u = new Date(x.to + "T00:00:00"); u.setDate(u.getDate() - 1); return u; }
  function promoActive(p, day) { return !!percentFor(p, day); }
  function priceOf(p, base, day) {
    const x = percentFor(p, day);
    if (!x) return { price: base, old: null, pct: 0, until: null, promo: null };
    const r = CFG.promoRoundTo || 1;
    return { price: Math.ceil(base * (1 - x.pct / 100) / r) * r, old: base, pct: x.pct, until: untilOf(x), promo: x };
  }
  const TR = { а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "e", ж: "zh", з: "z", и: "i", й: "y", к: "k", л: "l", м: "m", н: "n", о: "o", п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f", х: "h", ц: "ts", ч: "ch", ш: "sh", щ: "sch", ъ: "", ы: "y", ь: "", э: "e", ю: "yu", я: "ya" };
  const codeKey = (s) => String(s || "").toLowerCase().replace(/\s+/g, "").split("").map((c) => (c in TR ? TR[c] : c)).join("");
  function codePromo(code, day) { const k = codeKey(code); return k ? livePromos(day).find((x) => x.type === "code" && codeKey(x.code) === k) || null : null; }
  window.TMVO_PRICE = { priceOf, promoActive, percentFor, giftsFor, codePromo, livePromos, promoState, applies, untilOf, today };

  // Цена всегда пересчитывается по каталогу — цене из браузера не доверяем.
  function priceItems(items, code) {
    const cat = window.CATALOG;
    if (!items || !items.length) throw apiError("empty_cart", "Корзина пуста");
    const out = items.map((it) => {
      const p = cat.products.find((x) => x.id === it.product_id);
      if (!p) throw apiError("bad_item", "Товар не найден");
      const v = p.variants.find((x) => x.w === +it.width && x.l === +it.length);
      if (!v) throw apiError("bad_item", "Размер не найден");
      const qty = Math.max(1, Math.min(20, parseInt(it.qty, 10) || 1));
      const pr = priceOf(p, v.price);
      const gifts = giftsFor(p, v.w).map((g) => g.gift);
      return { product_id: p.id, name: p.name, category: p.category, width: v.w, length: v.l, qty, price: pr.price, old_price: pr.old, discount_pct: pr.pct, promo_id: pr.promo ? pr.promo.id : null, sum: pr.price * qty, gifts };
    });
    const subtotal = out.reduce((s, x) => s + x.sum, 0);
    const cp = code ? codePromo(code) : null;
    let codeDiscount = 0;
    if (cp) out.forEach((x) => { const p = cat.products.find((y) => y.id === x.product_id); if (!x.discount_pct && applies(cp, p)) { const d = Math.round(x.sum * cp.pct / 100); x.code_discount = d; codeDiscount += d; } });
    if (code && !cp) throw apiError("bad_code", "Промокод не найден или срок его действия закончился");
    return { items: out, subtotal, promo_code: cp ? cp.code : null, code_discount: codeDiscount, total: subtotal - codeDiscount };
  }
  function publicOrder(o) { const c = JSON.parse(JSON.stringify(o)); delete c.history; return c; }
  function nextNumber() { const n = lsGet(LS_SEQ, 1000) + 1; lsSet(LS_SEQ, n); return n; }
  function newOrder(type, status, body) {
    const priced = priceItems(body.items, body.promo_code);
    const n = nextNumber();
    const o = {
      id: "o" + n, number: n, token: token(), type, status,
      created_at: now(), updated_at: now(),
      customer: { phone: normPhone(body.phone), name: (body.name || "").trim(), email: "", comment: "" },
      items: priced.items, subtotal: priced.subtotal, promo_code: priced.promo_code, code_discount: priced.code_discount, total: priced.total,
      delivery: null, payment: { method: null, status: "not_paid" },
      consents: { privacy: true, personal_data: true, versions: { privacy: CFG.documents.privacy.version, consent: CFG.documents.consent.version }, at: now(), form: body.source || type },
      offer_accepted: false, marketing: false,
      history: [{ at: now(), text: type === "quick" ? "Быстрый заказ с сайта" : "Начато оформление (есть телефон)" }]
    };
    return o;
  }
  function getOwned(id, tk) {
    const o = loadOrders()[id];
    if (!o || o.token !== tk) throw apiError("not_found", "Заказ не найден");
    return o;
  }

  const mock = {
    async getCatalog() { return window.CATALOG; },

    async quickOrder(body) {
      await delay(350);
      if (!normPhone(body.phone)) throw apiError("bad_phone", "Проверьте номер телефона");
      checkConsents(body.consents);
      const o = newOrder("quick", "new", body);
      loadOrders()[o.id] = o; saveOrders();
      return publicOrder(o);
    },

    async callback(body) {
      await delay(300);
      if (!normPhone(body.phone)) throw apiError("bad_phone", "Проверьте номер телефона");
      checkConsents(body.consents);
      const list = lsGet(LS_CALLBACKS, []);
      list.unshift({ id: "c" + Date.now(), phone: normPhone(body.phone), name: (body.name || "").trim(), topic: body.topic || "", status: "new", created_at: now(),
        consents: { privacy: true, personal_data: true, versions: (body.consents || {}).versions || {}, at: now() } });
      lsSet(LS_CALLBACKS, list.slice(0, 500));
      return { ok: true };
    },

    async createDraft(body) {
      await delay(300);
      if (!normPhone(body.phone)) throw apiError("bad_phone", "Проверьте номер телефона");
      checkConsents(body.consents);
      const o = newOrder("full", "draft", body);
      loadOrders()[o.id] = o; saveOrders();
      return publicOrder(o);
    },

    async updateOrder(id, tk, patch) {
      await delay(200);
      const o = getOwned(id, tk);
      if (o.status !== "draft") throw apiError("locked", "Заказ уже подтверждён");
      if (patch.phone !== undefined) { const p = normPhone(patch.phone); if (!p) throw apiError("bad_phone", "Проверьте номер телефона"); o.customer.phone = p; }
      ["name", "email", "comment"].forEach((k) => { if (patch[k] !== undefined) o.customer[k] = String(patch[k]).trim(); });
      if (patch.items) { const pr = priceItems(patch.items, patch.promo_code !== undefined ? patch.promo_code : o.promo_code); Object.assign(o, { items: pr.items, subtotal: pr.subtotal, promo_code: pr.promo_code, code_discount: pr.code_discount, total: pr.total }); }
      if (patch.delivery) {
        const m = CFG.delivery.find((d) => d.id === patch.delivery.method && d.enabled);
        if (!m) throw apiError("bad_delivery", "Способ получения недоступен");
        o.delivery = Object.assign({}, patch.delivery);
      }
      if (patch.payment_method) {
        const m = CFG.payment.find((p) => p.id === patch.payment_method && p.enabled);
        if (!m) throw apiError("bad_payment", "Способ оплаты недоступен");
        o.payment.method = m.id;
      }
      o.updated_at = now(); saveOrders();
      return publicOrder(o);
    },

    async confirmOrder(id, tk, body) {
      await delay(400);
      const o = getOwned(id, tk);
      if (o.status !== "draft") return publicOrder(o);
      if (!body || body.offer_accepted !== true) throw apiError("offer_required", "Нужно принять условия оферты");
      if (!o.customer.name) throw apiError("bad_name", "Укажите имя");
      if (!o.delivery) throw apiError("bad_delivery", "Укажите способ получения");
      if (!o.payment.method) throw apiError("bad_payment", "Выберите способ оплаты");
      const pm = CFG.payment.find((p) => p.id === o.payment.method);
      o.offer_accepted = true; o.marketing = !!body.marketing;
      o.status = pm && pm.online ? "awaiting_payment" : "new";
      o.history.push({ at: now(), text: "Заказ подтверждён покупателем" });
      o.updated_at = now(); saveOrders();
      return publicOrder(o);
    },

    async getOrder(id, tk) { await delay(150); return publicOrder(getOwned(id, tk)); },

    // Онлайн-оплата: в макете имитируется. Сервер должен создать платёж в ЮKassa и вернуть confirmation_url.
    async createPayment(id, tk) {
      await delay(400);
      const o = getOwned(id, tk);
      return { payment_id: "mock_" + o.number, confirmation_url: (window.TMVO_ROOT || "") + "zakaz/index.html?id=" + o.id + "&t=" + o.token };
    }
  };

  /* ---------- рабочий режим: запросы на сервер ---------- */
  async function req(method, path, body) {
    const r = await fetch(CFG.apiBase + path, {
      method, credentials: "same-origin",
      headers: body ? { "Content-Type": "application/json", "Accept": "application/json" } : { "Accept": "application/json" },
      body: body ? JSON.stringify(body) : undefined
    });
    let data = null; try { data = await r.json(); } catch (e) { /* пустой ответ */ }
    if (!r.ok) throw apiError((data && data.error) || "http_" + r.status, (data && data.message) || "Ошибка сервера, попробуйте ещё раз");
    return data;
  }
  const real = {
    getCatalog: () => window.CATALOG ? Promise.resolve(window.CATALOG) : req("GET", "/catalog"),
    quickOrder: (b) => req("POST", "/orders/quick", b),
    callback: (b) => req("POST", "/callback", b),
    createDraft: (b) => req("POST", "/orders", b),
    updateOrder: (id, tk, p) => req("PATCH", "/orders/" + encodeURIComponent(id) + "?token=" + encodeURIComponent(tk), p),
    confirmOrder: (id, tk, b) => req("POST", "/orders/" + encodeURIComponent(id) + "/confirm?token=" + encodeURIComponent(tk), b),
    getOrder: (id, tk) => req("GET", "/orders/" + encodeURIComponent(id) + "?token=" + encodeURIComponent(tk)),
    createPayment: (id, tk, b) => req("POST", "/orders/" + encodeURIComponent(id) + "/payment?token=" + encodeURIComponent(tk), b || {})
  };

  /* ---------- режим "lite": без базы. Всё работает как в демо (заказ хранится у покупателя),
     но каждое событие дополнительно отправляется на одну функцию-обработчик (server-lite/),
     которая пересылает его менеджерам в Telegram. См. ROADMAP.md, этап 1. ---------- */
  async function notify(event, payload) {
    if (!CFG.liteEndpoint) return;
    const r = await fetch(CFG.liteEndpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ event, site: location.origin, at: now() }, payload)) });
    if (!r.ok) throw apiError("notify_failed", "Не удалось отправить заявку. Позвоните нам: " + CFG.shop.phone);
  }
  const lite = Object.assign({}, mock, {
    async quickOrder(b) { const o = await mock.quickOrder(b); await notify("quick_order", { order: o, comment: b.name || "" }); return o; },
    async callback(b) { const r = await mock.callback(b); await notify("callback", { phone: normPhone(b.phone), name: b.name || "", topic: b.topic || "", consents: b.consents }); return r; },
    async createDraft(b) { const o = await mock.createDraft(b); notify("lead", { order: o }).catch(() => {}); return o; },
    async confirmOrder(id, tk, b) { const o = await mock.confirmOrder(id, tk, b); await notify("order", { order: o }); return o; }
  });

  window.TMVO_API = CFG.apiMode === "api" ? real : CFG.apiMode === "lite" ? lite : mock;
  window.TMVO_API.normPhone = normPhone;
  window.TMVO_API.priceItems = priceItems;
})();
