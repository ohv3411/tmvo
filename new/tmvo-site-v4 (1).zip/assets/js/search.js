/*
 * Умный поиск по каталогу (работает в браузере, без сервера).
 *  • опечатки: «матрос», «кокс», «жоский» — нечёткое сравнение слов;
 *  • раскладка и транслит: «vfnhfc» → «матрас», «zevs» → «зевс»;
 *  • размеры: «160х200», «160x200», «160*200», «160 на 200», просто «160» — ширина;
 *  • цена: «до 20000», «до 20 тыс», «дешевле 15000», «от 30 тыс»;
 *  • жёсткость и пружины: «жёсткий», «мягкий», «средний», «без пружин», «пружинный»;
 *  • слова-синонимы: «койра» = кокос, «непромокаемый» = аква, «двуспальный» = ширина от 140 и т.д.
 * TMVO_SEARCH.run(query, catalog) → { products:[{p,score}], filters:[…], cats:[…], fuzzy, fix }
 */
(function () {
  const norm = (s) => String(s || "").toLowerCase().replace(/ё/g, "е").replace(/[«»"“”„(),.;:!?\\/+|]+/g, " ").replace(/\s+/g, " ").trim();
  const EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,.`", RU = "йцукенгшщзхъфывапролджэячсмитьбюё";
  const layout = (w) => w.split("").map((c) => { const i = EN.indexOf(c); return i >= 0 ? RU[i] : c; }).join("");
  const LAT = [["shch", "щ"], ["sch", "щ"], ["yo", "е"], ["zh", "ж"], ["kh", "х"], ["ts", "ц"], ["ch", "ч"], ["sh", "ш"], ["yu", "ю"], ["ya", "я"], ["ye", "е"],
    ["a", "а"], ["b", "б"], ["v", "в"], ["g", "г"], ["d", "д"], ["e", "е"], ["z", "з"], ["i", "и"], ["y", "ы"], ["k", "к"], ["l", "л"], ["m", "м"], ["n", "н"], ["o", "о"],
    ["p", "п"], ["r", "р"], ["s", "с"], ["t", "т"], ["u", "у"], ["f", "ф"], ["h", "х"], ["c", "к"], ["w", "в"], ["x", "кс"], ["j", "дж"], ["q", "к"]];
  const translit = (w) => { let o = "", i = 0; while (i < w.length) { const m = LAT.find(([a]) => w.startsWith(a, i)); if (m) { o += m[1]; i += m[0].length; } else { o += w[i]; i++; } } return o; };
  const ENDINGS = ["иями", "ями", "ами", "ого", "его", "ему", "ому", "ыми", "ими", "ая", "яя", "ое", "ее", "ые", "ие", "ый", "ий", "ой", "ей", "ам", "ям", "ах", "ях", "ов", "ев", "ом", "ем", "ую", "юю", "ы", "и", "а", "я", "о", "е", "у", "ю", "ь"];
  const stem = (w) => { if (w.length < 5 || /\d/.test(w)) return w; for (const e of ENDINGS) if (w.endsWith(e) && w.length - e.length >= 4) return w.slice(0, -e.length); return w; };
  const SYN = { тверд: "жестк", жестк: "жестк", жоск: "жестк", жеск: "жестк", койр: "кокос", кокосов: "кокос", непромокаем: "аква", водонепроницаем: "аква", влагостойк: "аква",
    ребенк: "детск", ребенок: "детск", малыш: "детск", подростк: "детск", топпер: "тонк", кровать: "кроват", ламел: "ламел", ламелям: "ламел", подъемн: "подъемн", подъемник: "подъемн", газлифт: "подъемн",
    пружин: "пружин", пружинн: "пружин", ортопед: "анатомическ", ортопедическ: "анатомическ", наматрас: "наматрасник", чехл: "чехл", чехол: "чехл" };
  const syn = (w) => SYN[w] || w;
  const words = (s) => norm(s).split(" ").filter(Boolean);
  const DIGITS = /\d/;

  function lev(a, b, max) {
    if (Math.abs(a.length - b.length) > max) return max + 1;
    const prev = new Array(b.length + 1), cur = new Array(b.length + 1), pp = new Array(b.length + 1);
    for (let j = 0; j <= b.length; j++) prev[j] = j;
    for (let i = 1; i <= a.length; i++) {
      cur[0] = i; let best = cur[0];
      for (let j = 1; j <= b.length; j++) {
        const c = a[i - 1] === b[j - 1] ? 0 : 1;
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) cur[j] = Math.min(cur[j], pp[j - 2] + 1);
        if (cur[j] < best) best = cur[j];
      }
      if (best > max) return max + 1;
      for (let j = 0; j <= b.length; j++) { pp[j] = prev[j]; prev[j] = cur[j]; }
    }
    return prev[b.length];
  }

  /* ---------- индекс ---------- */
  let IDX = null, IDX_FOR = null;
  function index(cat) {
    if (IDX_FOR === cat) return IDX;
    const cats = Object.fromEntries(cat.categories.map((c) => [c.id, c]));
    const groups = Object.fromEntries((cat.groups || []).map((g) => [g.id, g]));
    const vocab = new Set(), orig = new Map();
    const docs = cat.products.filter((p) => p.active !== false).map((p) => {
      const c = cats[p.category] || {}; const g = groups[c.group] || {};
      const fields = (c.fields || []).filter((f) => f.page !== false || f.filter);
      const t = new Map();
      const add = (text, w) => words(text).forEach((x) => { const s0 = stem(x); new Set([s0, syn(s0)]).forEach((k) => { if (k.length < 2 && !DIGITS.test(k)) return; t.set(k, Math.max(t.get(k) || 0, w)); vocab.add(k); if (!orig.has(k)) orig.set(k, x); }); });
      add(p.name, 10); add(p.word, 5); add(c.name, 4); add(c.title, 3); add(g.name, 2);
      fields.forEach((f) => { const v = (p.specs || {})[f.k]; if (!v) return; if (f.type === "yesno") { if (v === "Да") add(f.label || f.k, 2); } else add(v, 2); });
      if (p.category === "sale") add("распродажа скидка", 3);
      if (window.TMVO_PRICE && window.TMVO_PRICE.promoActive(p)) add("скидка акция", 2);
      if (window.TMVO_PRICE && window.TMVO_PRICE.giftsFor(p).length) add("подарок акция", 2);
      return { p, t, c };
    });
    IDX = { orig, docs, vocab: [...vocab].filter((w) => w.length >= 3 && !DIGITS.test(w)), cats: cat.categories }; IDX_FOR = cat;
    return IDX;
  }

  /* ---------- разбор запроса: размеры, цена, жёсткость ---------- */
  const HARD = { мягк: "Мягкий", средн: "Средней жесткости", жестк: "Жесткий" };
  function parse(q) {
    let s = " " + norm(q).replace(/(\d)\s*(?:x|х|×|\*|на)\s*(\d)/g, "$1x$2") + " ";
    const f = {};
    const take = (re, fn) => { s = s.replace(re, (...m) => { fn(m); return " "; }); };
    const num = (n, k) => { n = +String(n).replace(/\s/g, ""); return k ? n * 1000 : n; };
    take(/\s(?:до|дешевле|не дороже|меньше)\s(\d[\d ]*?)\s?(тыс(?:яч)?|т|k|к)?(?:\s?(?:руб(?:лей)?|р|₽))?(?=\s)/, (m) => (f.pmax = num(m[1], m[2])));
    take(/\s(?:от|дороже)\s(\d[\d ]*?)\s?(тыс(?:яч)?|т|k|к)?(?:\s?(?:руб(?:лей)?|р|₽))?(?=\s)/, (m) => { const n = num(m[1], m[2]); if (n >= 1000) f.pmin = n; });
    take(/\s(\d{2,3})x(\d{3})(?=\s)/, (m) => { f.w = +m[1]; f.l = +m[2]; });
    take(/\s(\d{2,3})(?:\s?см)?(?=\s)/, (m) => { const n = +m[1]; if (n >= 60 && n <= 220 && !f.w) f.w = n; });
    take(/\s(\d{4,6})\s?(?:руб(?:лей)?|р|₽)(?=\s)/, (m) => (f.pmax = +m[1]));
    take(/\sбез\s?пружин\S*(?=\s)|\sбеспружин\S*(?=\s)/, () => (f.spring = "Без пружин"));
    take(/\sдвуспальн\S*(?=\s)/, () => (f.wmin = 140));
    take(/\sполутора?спальн\S*(?=\s)/, () => (f.wexact = 120));
    take(/\sодноспальн\S*(?=\s)/, () => (f.wmaxw = 90));
    take(/\sразн\S*\sжестк\S*(?=\s)/, () => (f.raz = true));
    const rest = [];
    words(s).forEach((w) => {
      const k = syn(stem(w));
      const h = Object.keys(HARD).find((x) => k.startsWith(x));
      if (h && !f.hard) { f.hard = HARD[h]; return; }
      if (k === "пружин" && !f.spring) { f.spring = "С пружинами"; return; }
      if (["купить", "цена", "цены", "недорого", "для", "с", "и", "в", "на", "по", "см", "руб", "р"].includes(w)) return;
      rest.push(w);
    });
    return { f, words: rest };
  }

  function matchWord(w, doc, vocab) {
    const cands = [w];
    if (/[a-z]/.test(w)) { cands.push(layout(w), translit(w)); }
    let best = 0, fix = null;
    for (const raw of cands) for (const k of new Set([stem(raw), syn(stem(raw))])) {
      for (const [dw, wt] of doc.t) {
        let m = 0;
        if (dw === k) m = 1;
        else if (k.length >= 2 && dw.startsWith(k)) m = 0.85;
        else if (k.length >= 4 && k.startsWith(dw) && dw.length >= 4) m = 0.75;
        else if (k.length >= 4 && !DIGITS.test(k)) { const d = lev(k, dw.slice(0, Math.max(k.length, Math.min(dw.length, k.length + 1))), k.length >= 7 ? 2 : 1); if (d <= (k.length >= 7 ? 2 : 1)) m = 0.6 - d * 0.1; }
        if (m * wt > best) { best = m * wt; fix = raw !== w || m < 0.8 ? dw : null; }
      }
    }
    return { score: best, fix };
  }
  function fitsFilters(p, f) {
    const sp = p.specs || {};
    if (f.w && !p.variants.some((v) => v.w === f.w && (!f.l || v.l === f.l))) return false;
    if (f.wmin && !p.variants.some((v) => v.w >= f.wmin)) return false;
    if (f.wexact && !p.variants.some((v) => v.w === f.wexact)) return false;
    if (f.wmaxw && !p.variants.some((v) => v.w <= f.wmaxw)) return false;
    const pr = minPrice(p, f);
    if (f.pmax && pr > f.pmax) return false;
    if (f.pmin && pr < f.pmin) return false;
    if (f.hard && !String(sp["Категория: Жёсткость"] || "").includes(f.hard)) return false;
    if (f.raz && sp["Категория: Разносторонний"] !== "Да") return false;
    if (f.spring && sp["Категория: Пружины"] !== f.spring) return false;
    return true;
  }
  function minPrice(p, f) {
    const vs = p.variants.filter((v) => (!f || !f.w || v.w === f.w) && (!f || !f.l || v.l === f.l));
    const P = window.TMVO_PRICE;
    return Math.min(...(vs.length ? vs : p.variants).map((v) => (P ? P.priceOf(p, v.price).price : v.price)));
  }
  function chips(f) {
    const r = (n) => Math.round(n).toLocaleString("ru-RU").replace(/,/g, " ") + " ₽";
    const out = [];
    if (f.w) out.push({ k: "size", t: f.l ? `Размер ${f.w}×${f.l}` : `Ширина ${f.w} см` });
    if (f.wmin) out.push({ k: "wmin", t: "Двуспальные (от 140 см)" });
    if (f.wexact) out.push({ k: "wexact", t: "Полутороспальные (120 см)" });
    if (f.wmaxw) out.push({ k: "wmaxw", t: "Односпальные (до 90 см)" });
    if (f.pmax) out.push({ k: "pmax", t: "до " + r(f.pmax) });
    if (f.pmin) out.push({ k: "pmin", t: "от " + r(f.pmin) });
    if (f.hard) out.push({ k: "hard", t: f.hard === "Жесткий" ? "Жёсткие" : f.hard === "Мягкий" ? "Мягкие" : "Средней жёсткости" });
    if (f.raz) out.push({ k: "raz", t: "Разная жёсткость сторон" });
    if (f.spring) out.push({ k: "spring", t: f.spring });
    return out;
  }

  function run(q, cat, opts) {
    const X = index(cat); const { f, words: ws } = parse(q);
    const anyFilter = Object.keys(f).length > 0;
    let res = [], fuzzy = false; const fixes = {};
    X.docs.forEach((d) => {
      if (!fitsFilters(d.p, f)) return;
      let total = 0, matched = 0;
      ws.forEach((w) => { const m = matchWord(w, d, X.vocab); if (m.score > 0) { matched++; total += m.score; if (m.fix) fixes[w] = fixes[w] || m.fix; } });
      if (ws.length && !matched) return;
      res.push({ p: d.p, score: total + (matched === ws.length ? 100 : 0) + (d.p.images && d.p.images.length ? 1 : 0), all: matched === ws.length });
    });
    if (!ws.length && !anyFilter) res = [];
    const strict = res.filter((x) => x.all);
    if (strict.length) res = strict; else fuzzy = res.length > 0;
    res.sort((a, b) => b.score - a.score || minPrice(a.p, f) - minPrice(b.p, f));
    // категории, подходящие под слова
    const cats = ws.length ? X.cats.filter((c) => c.menu !== false || c.id === "sale").filter((c) => ws.some((w) => { const k = syn(stem(/[a-z]/.test(w) ? translit(w) : w)); return words(c.name + " " + (c.title || "")).some((cw) => { const s = syn(stem(cw)); return s.startsWith(k) || (k.length >= 4 && lev(k, s, 1) <= 1); }); })) : [];
    let fix = null;
    const changed = ws.map((w) => fixes[w] && !fixes[w].startsWith(syn(stem(w))) ? (X.orig.get(fixes[w]) || fixes[w]) : w);
    if (changed.join(" ") !== ws.join(" ")) fix = changed.join(" ");
    return { products: res.slice(0, (opts && opts.limit) || 500), total: res.length, filters: chips(f), f, cats, fuzzy, fix, words: ws };
  }
  window.TMVO_SEARCH = { run, parse, norm, minPrice };
})();
