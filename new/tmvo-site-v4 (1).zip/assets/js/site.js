/*
 * Торбеевские матрасы — общий скрипт всех страниц (v4).
 * Каталог, карточки, страницы разделов и товаров, акции и поиск рисуются здесь из window.CATALOG
 * (data/catalog.js или черновик админки — см. data.js). HTML-страницы — только оболочки.
 * Страница сообщает о себе атрибутом <body data-page="..."> (+ data-cat / data-pid).
 */
(async function () {
  const CFG = window.TMVO_CONFIG, API = window.TMVO_API, SHOP = CFG.shop, P = window.TMVO_PRICE, S = window.TMVO_SEARCH;
  const CAT = await window.TMVO_DATA.ready;
  const ROOT = window.TMVO_ROOT || "";
  const STATIC = window.TMVO_STATIC || { products: {}, categories: {} };
  const PAGE = document.body.dataset.page || "home";
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const rub = (n) => Math.round(n).toLocaleString("ru-RU").replace(/ |,/g, " ") + " ₽";
  const url = (path) => ROOT + path + "index.html";
  const enc = encodeURIComponent;
  const ls = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* хранилище недоступно */ } }
  };
  const ss = {
    get(k, d) { try { const v = sessionStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* хранилище недоступно */ } },
    del(k) { try { sessionStorage.removeItem(k); } catch (e) { /* хранилище недоступно */ } }
  };
  const qs = new URLSearchParams(location.search);

  /* ================= каталог ================= */
  const active = () => CAT.products.filter((p) => p.active !== false);
  const byId = (id) => CAT.products.find((p) => p.id === id);
  const catById = (id) => CAT.categories.find((c) => c.id === id);
  const groups = () => CAT.groups || [];
  const sortCats = (a, b) => (a.sort || 99) - (b.sort || 99);
  const menuCats = (g) => CAT.categories.filter((c) => c.group === g.id && c.menu !== false).sort(sortCats);
  const inCat = (id) => active().filter((p) => p.category === id);
  const catUrl = (c) => (c && STATIC.categories[c.id] === c.url ? url(c.url) : url("katalog/") + "?c=" + enc(c ? c.id : ""));
  const groupUrl = (g) => { const c = menuCats(g)[0]; return g.url && Object.values(STATIC.categories).includes(g.url) ? url(g.url) : c ? catUrl(c) : url("katalog/"); };
  const prodUrl = (p) => (p.path && STATIC.products[p.id] === p.path ? url(p.path) : url("tovar/") + "?id=" + enc(p.id));
  const withQ = (u, q) => u + (u.includes("?") ? "&" : "?") + q;
  const imgs = (p) => (p.images && p.images.length ? p.images : p.image ? [p.image] : []);
  const src = (s) => (/^(data:|https?:|blob:)/.test(s) ? s : ROOT + s);
  const variant = (p, w, l) => p.variants.find((v) => v.w === +w && v.l === +l);
  const fullName = (p) => (p.word && p.category !== "detskie-namatrasniki" ? p.word + " " : "") + p.name;
  const fmtDate = (d) => d.toLocaleDateString("ru-RU", { day: "numeric", month: "long" });
  const formatPhone = (p) => { const d = String(p || "").replace(/\D/g, "").slice(-10); return d.length === 10 ? `+7 (${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6, 8)}-${d.slice(8)}` : p; };
  const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20) ? b : c; };
  const countLabel = (n) => `${n} ${plural(n, "товар", "товара", "товаров")}`;
  const sides = (p) => String((p.specs || {})["Категория: Жёсткость"] || "").split(";").map((x) => x.trim()).filter(Boolean);
  const SHORT = { "Мягкий": "Мягкий", "Средней жесткости": "Средний", "Жесткий": "Жёсткий" };
  const hardLabel = (p) => sides(p).map((x) => SHORT[x] || x).join(" / ");
  const hardMatch = (p, k) => (k === "raz" ? (p.specs || {})["Категория: Разносторонний"] === "Да" : sides(p).includes(k));
  const HARD_OPTS = [["Мягкий", "Мягкие"], ["Средней жесткости", "Средней жёсткости"], ["Жесткий", "Жёсткие"], ["raz", "Разная жёсткость сторон"]];
  const defSize = (p) => { const ws = [...new Set(p.variants.map((v) => v.w))]; const w = ws.includes(160) ? 160 : ws[Math.floor(ws.length / 2)]; const L = p.variants.filter((v) => v.w === w).map((v) => v.l); return { w, l: L.includes(200) ? 200 : L[L.length - 1] }; };
  const minPrice = (p, w) => Math.min(...p.variants.filter((v) => !w || v.w === w).map((v) => P.priceOf(p, v.price).price));
  const fieldsOf = (p) => (catById(p.category) || {}).fields || [];

  const I = {
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20s-7-4.4-9.2-9A5 5 0 0112 5.6 5 5 0 0121.2 11C19 15.6 12 20 12 20z"/></svg>',
    gift: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="8" width="18" height="13" rx="1.5"/><path d="M3 12h18M12 8v13M12 8S10.5 3 8 3.5 6.5 8 12 8zm0 0s1.5-5 4-4.5S17.5 8 12 8z"/></svg>',
    tag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.5"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
    pct: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 5L5 19"/><circle cx="7" cy="7" r="2.5"/><circle cx="17" cy="17" r="2.5"/></svg>',
    truck: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h11v10H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="1.8"/><circle cx="17" cy="18" r="1.8"/></svg>',
    wallet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M16 12.5h2M3 9h18"/></svg>',
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg>',
    ruler: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="8" width="20" height="8" rx="1.5"/><path d="M6 8v3M10 8v4M14 8v3M18 8v4"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 00-1-1H5a1 1 0 00-1 1v10a1 1 0 001 1h3"/></svg>'
  };

  /* ================= акции ================= */
  const live = () => P.livePromos();
  const promoProducts = (x) => active().filter((p) => (x.type === "gift" ? P.giftsFor(p).some((g) => g.id === x.id) : P.applies(x, p)) && (x.type !== "percent" || (P.percentFor(p) || {}).id === x.id));
  const saleItems = () => inCat("sale");
  const saleMaxPct = () => Math.max(0, ...saleItems().map((p) => (p.regular_price ? Math.round((1 - p.min_price / p.regular_price) * 100) : 0)));
  const untilText = (x) => "до " + fmtDate(P.untilOf(x)) + " включительно";
  function leftText(to) {
    const ms = new Date(to + "T00:00:00") - new Date(); if (ms <= 0) return "акция завершена";
    const d = Math.floor(ms / 864e5), h = Math.floor(ms / 36e5) % 24, m = Math.floor(ms / 6e4) % 60, s = Math.floor(ms / 1e3) % 60;
    const t = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    return d ? `${d} ${plural(d, "день", "дня", "дней")} ${t}` : t;
  }
  setInterval(() => $$("[data-left]").forEach((el) => (el.textContent = leftText(el.dataset.left))), 1000);
  const timer = (x) => `<span class="cd">${I.clock}<span>осталось <b data-left="${esc(x.to)}">${leftText(x.to)}</b></span></span>`;
  const TYPE_LABEL = { percent: "Скидка", gift: "Подарок", code: "Промокод", sale: "Распродажа" };
  function promoCard(x, big) {
    const n = x.type === "sale" ? saleItems().length : x.type === "code" ? 0 : promoProducts(x).length;
    const href = x.type === "sale" ? catUrl(catById("sale")) : url("akcii/") + "#" + enc(x.id);
    const head = x.type === "percent" || x.type === "code" ? `<span class="pc-big">−${x.pct}%</span>` : x.type === "sale" ? `<span class="pc-big">до −${x.pct}%</span>` : `<span class="pc-ico">${I.gift}</span>`;
    return `<a class="pcard pc-${esc(x.color || "red")} ${big ? "pc-hero" : ""}" href="${href}">
      <span class="pc-type">${TYPE_LABEL[x.type] || "Акция"}</span>${head}
      <b class="pc-title">${esc(x.title)}</b><span class="pc-text">${esc(x.text || "")}</span>
      ${x.type === "code" ? `<span class="pc-code"><code>${esc(x.code)}</code><button type="button" class="pc-copy" data-copy="${esc(x.code)}">${I.copy} Скопировать</button></span>` : ""}
      <span class="pc-foot">${x.to ? `<span>${untilText(x)}</span>` : "<span>пока есть в наличии</span>"}${x.to && big ? timer(x) : ""}${n ? `<span class="pc-n">${countLabel(n)} →</span>` : ""}</span></a>`;
  }
  const saleCard = () => (saleItems().length ? { id: "sale", type: "sale", title: "Распродажа", pct: saleMaxPct(), text: "Штучные матрасы со склада, один размер. Забирайте сразу — без ожидания производства.", color: "night" } : null);
  const homePromos = () => [...live().filter((x) => x.home !== false), saleCard()].filter(Boolean);

  /* ================= корзина и избранное ================= */
  const Cart = {
    items() { return ls.get("tmvo_cart", []).filter((x) => byId(x.product_id) && variant(byId(x.product_id), x.width, x.length)); },
    save(a) { ls.set("tmvo_cart", a); badges(); },
    add(pid, w, l, qty) {
      const a = Cart.items(); const f = a.find((x) => x.product_id === pid && x.width === w && x.length === l);
      if (f) f.qty = Math.min(20, f.qty + qty); else a.push({ product_id: pid, width: w, length: l, qty });
      Cart.save(a);
    },
    setQty(i, q) { const a = Cart.items(); if (!a[i]) return; a[i].qty = Math.max(1, Math.min(20, q)); Cart.save(a); },
    remove(i) { const a = Cart.items(); a.splice(i, 1); Cart.save(a); },
    clear() { Cart.save([]); ls.set("tmvo_code", ""); },
    count() { return Cart.items().reduce((s, x) => s + x.qty, 0); },
    code() { return ls.get("tmvo_code", ""); },
    priced() {
      const items = Cart.items(); if (!items.length) return null;
      let r; const code = Cart.code();
      try { r = API.priceItems(items, code || undefined); } catch (e) { ls.set("tmvo_code", ""); r = API.priceItems(items); }
      r.items.forEach((x) => { x.p = byId(x.product_id); x.oldSum = (x.old_price || x.price) * x.qty; x.old = x.old_price; });
      return r;
    }
  };
  const Fav = {
    all() { return ls.get("tmvo_fav", []).filter(byId); },
    has(id) { return Fav.all().includes(id); },
    toggle(id) { const a = Fav.all(); const i = a.indexOf(id); if (i >= 0) a.splice(i, 1); else a.push(id); ls.set("tmvo_fav", a); badges(); return i < 0; }
  };
  function badges() {
    $$(".cart-count").forEach((b) => { const n = Cart.count(); b.textContent = n; b.hidden = !n; });
    $$(".fav-count").forEach((b) => { const n = Fav.all().length; b.textContent = n; b.hidden = !n; });
    $$("[data-fav]").forEach((b) => { const on = Fav.has(b.dataset.fav); b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  }
  function toast(t) { const el = $("#toast"); el.textContent = t; el.classList.add("on"); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove("on"), 2400); }

  /* ================= карточка товара ================= */
  function priceHtml(p, w) {
    const vs = p.variants.filter((v) => !w || v.w === w); const base = Math.min(...vs.map((v) => v.price));
    const pr = P.priceOf(p, base); const single = p.variants.length === 1;
    const old = pr.old || (p.regular_price && p.regular_price > pr.price ? p.regular_price : null);
    return `<div class="price${old ? " hot" : ""}">${single ? "" : "<small>от</small> "}<b>${rub(pr.price)}</b>${old ? ` <s>${rub(old)}</s>` : ""}</div>${old ? `<div class="save">Выгода ${rub(old - pr.price)}</div>` : ""}`;
  }
  function tagsHtml(p) {
    const pr = P.priceOf(p, p.min_price); const g = P.giftsFor(p);
    const salePct = p.category === "sale" && p.regular_price ? Math.round((1 - p.min_price / p.regular_price) * 100) : 0;
    return `<span class="tags">${pr.pct ? `<span class="pct-badge">−${pr.pct}%</span>` : salePct ? `<span class="pct-badge">−${salePct}%</span>` : ""}${p.category === "sale" ? '<span class="sale-tag">Распродажа</span>' : ""}${g.length ? `<span class="gift-tag">${I.gift} Подарок</span>` : ""}${p.example ? '<span class="ex-tag">Пример</span>' : ""}</span>`;
  }
  function cardChips(p) {
    const out = []; const hl = hardLabel(p); if (hl) out.push(hl);
    fieldsOf(p).filter((f) => f.card).forEach((f) => { const v = (p.specs || {})[f.k]; if (!v) return; if (f.type === "yesno") { if (v === "Да") out.push(f.label || f.k); } else out.push(v + (f.unit ? " " + f.unit : "")); });
    return out.slice(0, 3).map((x) => `<span class="chip">${esc(x)}</span>`).join("");
  }
  function cardHtml(p) {
    const im = imgs(p)[0];
    const img = im ? `<img src="${src(im)}" alt="${esc(fullName(p))}" loading="lazy">` : `<span class="noimg">${esc(p.name)}</span>`;
    return `<article class="card" data-card="${esc(p.id)}"><a class="pic" href="${prodUrl(p)}">${tagsHtml(p)}${img}${imgs(p).length > 1 ? `<span class="pic-n">${imgs(p).length} фото</span>` : ""}</a>
      <button class="fav-btn" data-fav="${esc(p.id)}" aria-label="В избранное">${I.heart}</button>
      <div class="body"><a class="name" href="${prodUrl(p)}">${esc(fullName(p))}</a><div class="chips">${cardChips(p)}</div>
      ${priceHtml(p)}${p.variants.length === 1 ? `<div class="muted small">Размер ${p.variants[0].w}×${p.variants[0].l} см</div>` : ""}
      <button type="button" class="btn ghost sm quick-btn" data-quick="${esc(p.id)}">Быстрый заказ</button></div></article>`;
  }
  const gridHtml = (list) => list.map(cardHtml).join("");

  /* ================= шапка, меню, подвал ================= */
  function catThumb(c) { const p = inCat(c.id).find((x) => imgs(x).length); return p ? `<img src="${src(imgs(p)[0])}" alt="" loading="lazy">` : '<span class="mm-noimg"></span>'; }
  function renderChrome() {
    const lp = live(); const cnt = lp.length + (saleItems().length ? 1 : 0);
    const pc = $("#promoCnt"); if (pc) { pc.textContent = cnt; pc.hidden = !cnt; }
    const main = lp.filter((x) => x.type === "percent").sort((a, b) => b.pct - a.pct)[0];
    const tb = $("#tbPromo"); if (tb && main) { tb.innerHTML = `${I.pct}<b>${esc(main.title)} −${main.pct}%</b><span class="tbp-left">· осталось <span data-left="${esc(main.to)}">${leftText(main.to)}</span></span>`; tb.hidden = false; }
    const mm = $("#mmIn");
    if (mm) mm.innerHTML = `<div class="mm-cols">${groups().map((g) => `<div class="mm-col"><a class="mm-gh" href="${groupUrl(g)}">${esc(g.name)} <span>→</span></a><div class="mm-grid">${menuCats(g).map((c) => `<a class="mm-item" href="${catUrl(c)}">${catThumb(c)}<span><b>${esc(c.name)}</b><small>${countLabel(inCat(c.id).length)}</small></span></a>`).join("")}</div></div>`).join("")}
      <div class="mm-col mm-side"><a class="mm-gh" href="${url("akcii/")}">Акции <span>→</span></a><a class="mm-promo" href="${url("akcii/")}">${I.pct}<span><b>Все акции</b><small>${cnt ? cnt + " " + plural(cnt, "акция", "акции", "акций") : "скоро"}</small></span></a>
      ${saleItems().length ? `<a class="mm-promo sale" href="${catUrl(catById("sale"))}">${I.tag}<span><b>Распродажа</b><small>${countLabel(saleItems().length)} в наличии</small></span></a>` : ""}</div></div>`;
    const dc = $("#drawerCat");
    if (dc) dc.innerHTML = groups().map((g) => `<h4><a href="${groupUrl(g)}">${esc(g.name)}</a></h4>${menuCats(g).map((c) => `<a href="${catUrl(c)}">${esc(c.name)}<span>${inCat(c.id).length}</span></a>`).join("")}`).join("") +
      (saleItems().length ? `<a href="${catUrl(catById("sale"))}" class="d-sale">Распродажа<span>${saleItems().length}</span></a>` : "");
    const fc = $("#ftrCat"); if (fc) fc.innerHTML = groups().map((g) => menuCats(g).map((c) => `<a href="${catUrl(c)}">${esc(c.name)}</a>`).join("")).join("");
    $$(".nav2 [data-group]").forEach((a) => { const g = groups().find((x) => x.id === a.dataset.group); if (g) a.href = groupUrl(g); });
    if (CAT._draft) {
      const b = document.createElement("div"); b.className = "draft-bar";
      b.innerHTML = `<b>Черновик из админки</b><span>виден только в этом браузере</span><a href="${ROOT}admin/index.html">Админка</a><button type="button">Скрыть</button>`;
      b.querySelector("button").onclick = () => { window.TMVO_DATA.setDraftOn(false); location.reload(); };
      document.body.appendChild(b);
    }
  }

  /* ================= маска телефона, согласия ================= */
  function maskPhone(el) {
    const f = () => {
      let d = el.value.replace(/\D/g, ""); if (d[0] === "8" || d[0] === "7") d = d.slice(1); d = d.slice(0, 10);
      let o = d.length ? "+7 (" + d.slice(0, 3) : "";
      if (d.length > 3) o += ") " + d.slice(3, 6); if (d.length > 6) o += "-" + d.slice(6, 8); if (d.length > 8) o += "-" + d.slice(8, 10);
      el.value = o;
    };
    el.addEventListener("input", f); el.addEventListener("focus", () => { if (!el.value) el.value = "+7 ("; });
    el.addEventListener("blur", () => { if (el.value === "+7 (") el.value = ""; });
  }
  const consentsHtml = () => `
    <label class="cbx"><input type="checkbox" name="privacy"> <span>Соглашаюсь с <a href="${url("politika-konfidentsialnosti/")}" target="_blank">политикой обработки персональных данных</a></span></label>
    <label class="cbx"><input type="checkbox" name="personal_data"> <span>Даю <a href="${url("soglasie-na-obrabotku/")}" target="_blank">согласие на обработку персональных данных</a></span></label>
    <input class="hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">`;
  const consentsOf = (f) => ({ privacy: f.privacy.checked, personal_data: f.personal_data.checked, versions: { privacy: CFG.documents.privacy.version, consent: CFG.documents.consent.version } });
  function guard(form, btn, extra) {
    const upd = () => { btn.disabled = !(API.normPhone(form.phone.value) && form.privacy.checked && form.personal_data.checked && (!extra || extra())); };
    form.addEventListener("input", upd); form.addEventListener("change", upd); upd();
  }

  /* ================= модальные окна ================= */
  let lastFocus = null;
  function openModal(html, cls) {
    lastFocus = document.activeElement;
    $("#dlg").className = "dlg" + (cls ? " " + cls : "");
    $("#dlg").innerHTML = `<button class="x" data-close aria-label="Закрыть">×</button>` + html;
    $("#modal").classList.add("on"); document.body.style.overflow = "hidden";
    const f = $("#dlg input:not(.hp)"); if (f) setTimeout(() => f.focus(), 30);
  }
  function closeModal() { $("#modal").classList.remove("on"); document.body.style.overflow = ""; if (lastFocus && lastFocus.focus) lastFocus.focus(); }
  const done = (title, text) => `<button class="x" data-close aria-label="Закрыть">×</button><div class="done"><div class="okmark">${I.check}</div><h3 id="modal-title">${title}</h3><p class="muted">${text}</p><button class="btn block" data-close>Продолжить покупки</button></div>`;

  function quickPick(pid) {
    const p = byId(pid); if (!p) return;
    const ws = [...new Set(p.variants.map((v) => v.w))]; let { w, l } = defSize(p); let qty = 1;
    const lens = (x) => [...new Set(p.variants.filter((v) => v.w === x).map((v) => v.l))];
    openModal(`<h3 id="modal-title">Быстрый заказ</h3><div class="mini"><div class="pic">${imgs(p)[0] ? `<img src="${src(imgs(p)[0])}" alt="">` : ""}</div><div><b>${esc(fullName(p))}</b><div class="muted" id="qpPrice"></div></div></div>
      <div class="row2 qp-row"><div class="field"><label for="qpW">Ширина, см</label><select class="inp" id="qpW">${ws.map((x) => `<option ${x === w ? "selected" : ""}>${x}</option>`).join("")}</select></div>
      <div class="field"><label for="qpL">Длина, см</label><select class="inp" id="qpL"></select></div></div>
      <div class="qty-row"><span class="lbl">Количество</span><div class="qty"><button type="button" id="qpM" aria-label="Меньше">−</button><span id="qpQ">1</span><button type="button" id="qpP" aria-label="Больше">+</button></div></div>
      <div id="qpGift"></div>
      <button class="btn block" id="qpGo">Продолжить</button><p class="muted small center">Дальше — только телефон. Менеджер перезвонит и уточнит детали.</p>`);
    const draw = () => {
      const L = lens(w); if (!L.includes(l)) l = L.includes(200) ? 200 : L[L.length - 1];
      $("#qpL").innerHTML = L.map((x) => `<option ${x === l ? "selected" : ""}>${x}</option>`).join("");
      const pr = P.priceOf(p, variant(p, w, l).price);
      $("#qpPrice").innerHTML = `${w}×${l} см · <b>${rub(pr.price * qty)}</b>${pr.old ? ` <s>${rub(pr.old * qty)}</s> <span class="pct-inline">−${pr.pct}%</span>` : ""}`; $("#qpQ").textContent = qty;
      $("#qpGift").innerHTML = P.giftsFor(p, w).map((x) => `<p class="gift-line">${I.gift} ${esc(x.gift)} — в подарок</p>`).join("");
    };
    $("#qpW").onchange = (e) => { w = +e.target.value; draw(); }; $("#qpL").onchange = (e) => { l = +e.target.value; draw(); };
    $("#qpM").onclick = () => { qty = Math.max(1, qty - 1); draw(); }; $("#qpP").onclick = () => { qty = Math.min(20, qty + 1); draw(); };
    $("#qpGo").onclick = () => quickOrder([{ product_id: p.id, width: w, length: l, qty }], "list");
    draw();
  }

  function quickOrder(items, source) {
    const code = source === "cart" ? Cart.code() || undefined : undefined;
    let pr; try { pr = API.priceItems(items, code); } catch (e) { pr = API.priceItems(items); }
    openModal(`<h3 id="modal-title">Быстрый заказ</h3><p class="muted">Оставьте телефон — менеджер перезвонит, уточнит доставку и оплату.</p>
      ${pr.items.slice(0, 3).map((x) => { const p = byId(x.product_id); return `<div class="mini"><div class="pic">${imgs(p)[0] ? `<img src="${src(imgs(p)[0])}" alt="">` : ""}</div><div><b>${esc(fullName(p))}</b><div class="muted">${x.width}×${x.length} см, ${x.qty} шт</div><b>${rub(x.sum)}</b>${x.discount_pct ? ` <span class="pct-inline">−${x.discount_pct}%</span>` : ""}${x.gifts.length ? `<div class="gift-line">${I.gift} ${esc(x.gifts.join(", "))}</div>` : ""}</div></div>`; }).join("")}
      ${pr.items.length > 3 ? `<p class="muted">и ещё ${pr.items.length - 3} поз.</p>` : ""}${pr.code_discount ? `<p class="muted">Промокод ${esc(pr.promo_code)}: −${rub(pr.code_discount)}</p>` : ""}<p><b>Итого ${rub(pr.total)}</b></p>
      <form id="qform" novalidate>
        <div class="field"><label for="qphone">Телефон <span class="req">*</span></label><input class="inp" id="qphone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+7 (___) ___-__-__"></div>
        <div class="field"><label for="qname">Имя <span class="opt">— по желанию</span></label><input class="inp" id="qname" name="name" autocomplete="given-name"></div>
        ${consentsHtml()}<div class="err-msg" id="qerr" role="alert"></div>
        <button class="btn block" id="qbtn">Отправить заявку</button>
        <p class="muted small center">Перезвоним в рабочее время: ${esc(SHOP.workStart)}–${esc(SHOP.workEnd)}</p></form>`);
    const f = $("#qform"), b = $("#qbtn"); maskPhone(f.phone); guard(f, b);
    f.onsubmit = async (e) => {
      e.preventDefault(); if (f.website.value) return; b.disabled = true; b.textContent = "Отправляем…";
      try {
        const o = await API.quickOrder({ phone: f.phone.value, name: f.name.value, items, consents: consentsOf(f), source, promo_code: pr.promo_code || undefined });
        if (source === "cart") Cart.clear();
        $("#dlg").innerHTML = done(`Заявка № ${o.number} принята`, `Перезвоним на ${esc(formatPhone(o.customer.phone))} в рабочее время, ${esc(SHOP.workStart)}–${esc(SHOP.workEnd)}.`);
        if (source === "cart") setTimeout(() => (location.href = url("")), 2500);
      } catch (err) { $("#qerr").textContent = err.message; b.disabled = false; b.textContent = "Отправить заявку"; }
    };
  }
  function callbackModal(title) {
    openModal(`<h3 id="modal-title">${esc(title || "Заказать звонок")}</h3><p class="muted">Перезвоним, ответим на вопросы и поможем выбрать.</p>
      <form id="cform" novalidate>
        <div class="field"><label for="cphone">Телефон <span class="req">*</span></label><input class="inp" id="cphone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+7 (___) ___-__-__"></div>
        <div class="field"><label for="cname">Имя <span class="opt">— по желанию</span></label><input class="inp" id="cname" name="name" autocomplete="given-name"></div>
        ${consentsHtml()}<div class="err-msg" id="cerr" role="alert"></div>
        <button class="btn block" id="cbtn">Перезвоните мне</button></form>`);
    const f = $("#cform"), b = $("#cbtn"); maskPhone(f.phone); guard(f, b);
    f.onsubmit = async (e) => {
      e.preventDefault(); if (f.website.value) return; b.disabled = true;
      try { await API.callback({ phone: f.phone.value, name: f.name.value, topic: title || "Заказать звонок", consents: consentsOf(f) }); $("#dlg").innerHTML = done("Спасибо! Перезвоним", `В рабочее время, ${esc(SHOP.workStart)}–${esc(SHOP.workEnd)}.`); }
      catch (err) { $("#cerr").textContent = err.message; b.disabled = false; }
    };
  }
  function inlineLead(form) {
    const b = $("button", form); maskPhone(form.phone); guard(form, b);
    form.onsubmit = async (e) => {
      e.preventDefault(); if (form.website.value) return; b.disabled = true;
      try { await API.callback({ phone: form.phone.value, name: "", topic: "Остались вопросы", consents: consentsOf(form) }); form.innerHTML = `<p class="lead-ok">${I.check} Спасибо! Перезвоним в рабочее время.</p>`; }
      catch (err) { b.disabled = false; toast(err.message); }
    };
  }

  /* ================= главная ================= */
  function initHome() {
    const pa = $("#promoArea");
    if (pa) { const list = homePromos(); const first = list.find((x) => x.type === "percent"); const rest = list.filter((x) => x !== first);
      pa.innerHTML = (first ? promoCard(first, true) : "") + rest.slice(0, 5).map((x) => promoCard(x)).join(""); pa.closest("section").hidden = !list.length; }
    const hc = $("#homeCats");
    if (hc) hc.innerHTML = groups().map((g) => `<div class="hc-group"><h3><a href="${groupUrl(g)}">${esc(g.name)}</a></h3><div class="cats">${menuCats(g).map((c) => { const items = inCat(c.id);
      return `<a class="cat" href="${catUrl(c)}"><div class="pic">${catThumb(c)}</div><b>${esc(c.name)}</b><span class="muted">${countLabel(items.length)}${items.length ? `, <span class="nowrap">от ${rub(Math.min(...items.map((x) => minPrice(x))))}</span>` : ""}</span></a>`; }).join("")}</div></div>`).join("");
    $$("[data-count-hard]").forEach((el) => { const n = inCat("matrasy").filter((p) => hardMatch(p, el.dataset.countHard)).length; el.textContent = `${n} ${plural(n, "модель", "модели", "моделей")}`; });
  }
  function fillLists() {
    $$("[data-list]").forEach((el) => {
      const lim = +el.dataset.limit || 0; let list = [];
      if (el.dataset.list === "ids") list = el.dataset.ids.split(",").map(byId).filter((p) => p && p.active !== false);
      if (el.dataset.list === "promo") list = active().filter((p) => P.promoActive(p)).sort((a, b) => (imgs(b).length ? 1 : 0) - (imgs(a).length ? 1 : 0) || P.priceOf(b, b.min_price).pct - P.priceOf(a, a.min_price).pct);
      if (el.dataset.list === "cat") list = inCat(el.dataset.cat);
      if (el.dataset.list === "sale") list = saleItems();
      if (lim) list = list.slice(0, lim);
      el.innerHTML = gridHtml(list);
      const s = el.closest("[data-hide-empty]"); if (s) s.hidden = !list.length;
    });
  }

  /* ================= раздел каталога ================= */
  function catPromoStrip(c) {
    const ps = live().filter((x) => x.type !== "code" && ((x.categories || []).includes(c.id) || (x.products || []).some((id) => (byId(id) || {}).category === c.id)));
    if (!ps.length) return "";
    return `<div class="cat-promos">${ps.map((x) => `<a class="cp-chip pc-${esc(x.color || "red")}" href="${url("akcii/")}#${enc(x.id)}">${x.type === "gift" ? I.gift : `<b>−${x.pct}%</b>`} ${esc(x.title)} · ${untilText(x)}</a>`).join("")}</div>`;
  }
  function initCategory() {
    const app = $("#catApp"); const cid = document.body.dataset.cat || qs.get("c");
    const c = catById(cid);
    if (!c) {
      app.innerHTML = `<h1 class="page-h1">Каталог</h1>` + groups().map((g) => `<h2 class="cat-gh">${esc(g.name)}</h2><div class="cats">${menuCats(g).map((x) => `<a class="cat" href="${catUrl(x)}"><div class="pic">${catThumb(x)}</div><b>${esc(x.name)}</b><span class="muted">${countLabel(inCat(x.id).length)}</span></a>`).join("")}</div>`).join("");
      return;
    }
    const g = groups().find((x) => x.id === c.group);
    document.title = `${c.title || c.name} — ${SHOP.name}`;
    const cr = $("#crumbs"); if (cr) cr.innerHTML = `<a href="${url("")}">Главная</a> / ${g && menuCats(g)[0] !== c ? `<a href="${groupUrl(g)}">${esc(g.name)}</a> / ` : ""}<span aria-current="page">${esc(c.name)}</span>`;
    const items = inCat(c.id);
    const fl = c.filters || [];
    const cnt = (fn) => items.filter(fn).length;
    const fdef = (k) => (c.fields || []).find((f) => f.k === k);
    const generic = fl.filter((k) => k !== "hard").map((k) => { const f = fdef(k) || { k, label: k }; const vals = [...new Set(items.map((p) => (p.specs || {})[k]).filter(Boolean))].sort(); return { f, vals }; })
      .filter((x) => (x.f.type === "yesno" ? x.vals.includes("Да") && x.vals.length > 1 : x.vals.length > 1));
    const hasPromo = items.some((p) => P.promoActive(p) || P.giftsFor(p).length);
    const widths = [...new Set(items.flatMap((p) => p.variants.map((v) => v.w)))].sort((a, b) => a - b);
    const st = { hard: qs.get("hard") ? qs.get("hard").split(",") : [], w: +qs.get("w") || 0, pmin: "", pmax: "", sort: "pop", promo: !!qs.get("promo"), f: {} };
    const siblings = g ? menuCats(g) : [c]; if (!siblings.includes(c)) siblings.push(c);
    app.innerHTML = `<div class="cat-head"><h1>${esc(c.title || c.name)}</h1>${c.intro ? `<p class="muted">${esc(c.intro)}</p>` : ""}
      <div class="sublinks">${siblings.map((x) => `<a href="${catUrl(x)}"${x.id === c.id ? ' aria-current="page"' : ""}>${esc(x.name)}</a>`).join("")}${saleItems().length && c.group === "matrasy" && c.id !== "sale" ? `<a href="${catUrl(catById("sale"))}" class="sl-sale">Распродажа</a>` : ""}</div>
      ${catPromoStrip(c)}</div>
      <div class="cat-layout"><aside class="filters" id="filters" aria-label="Фильтры"><div class="f-head"><h3>Фильтры</h3><button class="link" id="fclose">Готово</button></div>
        ${hasPromo ? `<label class="fopt hot"><input type="checkbox" id="fpromo"> Со скидкой или подарком<span class="n">${cnt((p) => P.promoActive(p) || P.giftsFor(p).length)}</span></label>` : ""}
        ${fl.includes("hard") ? `<h4>Жёсткость</h4>${HARD_OPTS.filter(([k]) => cnt((p) => hardMatch(p, k))).map(([k, t]) => `<label class="fopt"><input type="checkbox" data-hard value="${k}">${t}<span class="n">${cnt((p) => hardMatch(p, k))}</span></label>`).join("")}` : ""}
        ${generic.map(({ f, vals }) => `<h4>${esc(f.label || f.k)}</h4>${(f.type === "yesno" ? ["Да"] : vals).map((v) => `<label class="fopt"><input type="checkbox" data-fk="${esc(f.k)}" value="${esc(v)}">${esc(f.type === "yesno" ? "Есть" : v)}<span class="n">${cnt((p) => (p.specs || {})[f.k] === v)}</span></label>`).join("")}`).join("")}
        ${widths.length > 1 ? `<h4>Ширина, см</h4><div class="wbtns">${widths.map((w) => `<button type="button" data-w="${w}">${w}</button>`).join("")}</div>` : ""}
        <h4>Цена, ₽</h4><div class="prange"><input type="number" inputmode="numeric" placeholder="от" id="pmin" aria-label="Цена от"><input type="number" inputmode="numeric" placeholder="до" id="pmax" aria-label="Цена до"></div>
        <button class="link freset">Сбросить фильтры</button></aside>
      <div class="cat-main"><div class="toolbar"><span class="muted" id="fcount"></span>
        <div class="tb-right"><button class="btn ghost sm f-open" id="fopen">Фильтры</button><label class="sr" for="sort">Сортировка</label>
        <select id="sort"><option value="pop">Сначала популярные</option><option value="disc">Сначала со скидкой</option><option value="asc">Сначала дешевле</option><option value="desc">Сначала дороже</option><option value="name">По названию</option></select></div></div>
        <div class="grid" id="plist"></div><div class="empty" id="fempty" hidden>Ничего не найдено. <button class="link freset">Сбросить фильтры</button></div></div></div><div class="f-shade" id="fshade"></div>`;
    $$("[data-hard]").forEach((i) => (i.checked = st.hard.includes(i.value)));
    $$(".wbtns button").forEach((b) => b.classList.toggle("on", +b.dataset.w === st.w));
    if ($("#fpromo")) $("#fpromo").checked = st.promo;
    const disc = (p) => P.priceOf(p, p.min_price).pct || (p.regular_price ? Math.round((1 - p.min_price / p.regular_price) * 100) : 0);
    const apply = () => {
      let list = items.filter((p) => {
        const s = p.specs || {};
        if (st.hard.length && !st.hard.some((k) => hardMatch(p, k))) return false;
        for (const k in st.f) if (st.f[k].length && !st.f[k].includes(s[k])) return false;
        if (st.w && !p.variants.some((v) => v.w === st.w)) return false;
        if (st.promo && !P.promoActive(p) && !P.giftsFor(p).length) return false;
        const pr = minPrice(p, st.w);
        if (st.pmin !== "" && pr < st.pmin) return false;
        if (st.pmax !== "" && pr > st.pmax) return false;
        return true;
      });
      const key = { asc: (p) => minPrice(p, st.w), desc: (p) => -minPrice(p, st.w), name: (p) => p.name, disc: (p) => -disc(p), pop: (p) => (imgs(p).length ? 0 : 1) + (disc(p) ? -0.5 : 0) }[st.sort];
      list = list.slice().sort((a, b) => { const x = key(a), y = key(b); return x < y ? -1 : x > y ? 1 : a.name.localeCompare(b.name, "ru"); });
      $("#plist").innerHTML = gridHtml(list);
      if (st.w) $$("#plist a").forEach((a) => (a.href = withQ(a.href, "w=" + st.w)));
      $("#fcount").textContent = countLabel(list.length); $("#fempty").hidden = !!list.length; badges();
    };
    const reset = () => { st.hard = []; st.f = {}; st.w = 0; st.pmin = ""; st.pmax = ""; st.promo = false; $$("#filters input[type=checkbox]").forEach((i) => (i.checked = false)); $$(".wbtns button").forEach((b) => b.classList.remove("on")); $("#pmin").value = ""; $("#pmax").value = ""; apply(); };
    $$("[data-hard]").forEach((i) => (i.onchange = () => { st.hard = $$("[data-hard]:checked").map((x) => x.value); apply(); }));
    $$("[data-fk]").forEach((i) => (i.onchange = () => { const k = i.dataset.fk; st.f[k] = $$("[data-fk]:checked").filter((x) => x.dataset.fk === k).map((x) => x.value); apply(); }));
    if ($("#fpromo")) $("#fpromo").onchange = (e) => { st.promo = e.target.checked; apply(); };
    $$(".wbtns button").forEach((b) => (b.onclick = () => { st.w = st.w === +b.dataset.w ? 0 : +b.dataset.w; $$(".wbtns button").forEach((x) => x.classList.toggle("on", +x.dataset.w === st.w)); apply(); }));
    $("#pmin").oninput = (e) => { st.pmin = e.target.value === "" ? "" : +e.target.value; apply(); };
    $("#pmax").oninput = (e) => { st.pmax = e.target.value === "" ? "" : +e.target.value; apply(); };
    $("#sort").onchange = (e) => { st.sort = e.target.value; apply(); };
    $$(".freset").forEach((b) => (b.onclick = reset));
    const fo = (on) => { $("#filters").classList.toggle("on", on); $("#fshade").classList.toggle("on", on); };
    $("#fopen").onclick = () => fo(true); $("#fclose").onclick = () => fo(false); $("#fshade").onclick = () => fo(false);
    apply();
  }

  /* ================= страница товара ================= */
  function yearsText(v) { if (!/^\d+([.,]\d+)?$/.test(String(v))) return v; const n = parseFloat(String(v).replace(",", ".")); if (!Number.isInteger(n)) return String(n).replace(".", ",") + " года"; return n + " " + plural(n, "год", "года", "лет"); }
  function specVal(f, p) {
    const s = p.specs || {}; let v = String(s[f.k] == null ? "" : s[f.k]);
    if (!v || (v === "Без пружин" && f.k !== "Пружинный блок")) return "";
    if (f.type === "hard") {
      const n = Math.round(parseFloat(s[f.k + " шкала 1-10"]) || 0);
      return `<span class="hardbar"><span>${esc(v.replace("Жесткий", "Жёсткий"))}</span>${n ? `<span class="scale" aria-label="${n} из 10">${Array.from({ length: 10 }, (_, i) => `<i class="${i < n ? "on" : ""}"></i>`).join("")}</span>` : ""}</span>`;
    }
    if (f.k === "Состав слоев матраса / наполнители") v = v.replace(/Жеский|Жесткий/g, "Жёсткий");
    if (f.k === "Допустимая разница в весе") return esc(v.replace("плюс", "до")) + " кг";
    if (f.k === "Упаковка" && v.includes("ПЭТ")) return "В ПЭТ-плёнке";
    if (f.type === "years") return esc(yearsText(v));
    return esc((f.prefix || "") + v + (f.unit ? " " + f.unit : ""));
  }
  function specsHtml(p) {
    const fs = fieldsOf(p).filter((f) => f.page !== false);
    const order = [...new Set(fs.map((f) => f.group || "Характеристики"))];
    const known = new Set(fieldsOf(p).flatMap((f) => [f.k, f.k + " шкала 1-10"]));
    const extra = Object.keys(p.specs || {}).filter((k) => !known.has(k) && !k.startsWith("Категория:") && p.specs[k]);
    const blocks = order.map((g) => [g, fs.filter((f) => (f.group || "Характеристики") === g).map((f) => [f.label || f.k, specVal(f, p)]).filter((r) => r[1])]).filter((b) => b[1].length);
    if (extra.length) blocks.push(["Другое", extra.map((k) => [k, esc(p.specs[k])])]);
    const sizes = [...new Set(p.variants.map((v) => v.w + "×" + v.l))];
    blocks.unshift(["В наличии", [["Размеры", esc(sizes.length > 6 ? sizes.slice(0, 6).join(", ") + ` и ещё ${sizes.length - 6}` : sizes.join(", "))]]]);
    return `<section class="specs"><h2>Характеристики</h2><div class="spec-grid">${blocks.map(([g, rows]) => `<div class="spec-blk"><h3>${esc(g)}</h3>${rows.map(([l, v]) => `<div class="spec-row"><span>${esc(l)}</span><span>${v}</span></div>`).join("")}</div>`).join("")}</div></section>`;
  }
  function galleryHtml(p) {
    const im = imgs(p);
    if (!im.length) return `<div class="gal"><div class="gal-main">${tagsHtml(p)}<div class="noimg big">${esc(p.name)}<small>Фото скоро появится</small></div></div></div>`;
    return `<div class="gal" id="gal"><div class="gal-main">${tagsHtml(p)}<div class="gal-track" id="galTrack" tabindex="0" aria-label="Фотографии товара">${im.map((s, i) => `<figure class="gal-slide"><img src="${src(s)}" alt="${esc(fullName(p))}, фото ${i + 1}"${i ? ' loading="lazy"' : ""} data-zoom="${i}"></figure>`).join("")}</div>
      ${im.length > 1 ? `<button class="gal-nav prev" data-gal="-1" aria-label="Предыдущее фото">‹</button><button class="gal-nav next" data-gal="1" aria-label="Следующее фото">›</button><span class="gal-count" id="galCount">1 / ${im.length}</span>` : ""}</div>
      ${im.length > 1 ? `<div class="gal-thumbs">${im.map((s, i) => `<button type="button" class="${i ? "" : "on"}" data-thumb="${i}" aria-label="Фото ${i + 1}"><img src="${src(s)}" alt="" loading="lazy"></button>`).join("")}</div>` : ""}</div>`;
  }
  function initGallery(p) {
    const tr = $("#galTrack"); if (!tr) return; const im = imgs(p); let cur = 0;
    const mark = () => { $$("[data-thumb]").forEach((b) => b.classList.toggle("on", +b.dataset.thumb === cur)); const c = $("#galCount"); if (c) c.textContent = `${cur + 1} / ${im.length}`; };
    const go = (i) => { cur = (i + im.length) % im.length; tr.scrollTo({ left: cur * tr.clientWidth, behavior: "smooth" }); mark(); };
    let st = null; tr.addEventListener("scroll", () => { clearTimeout(st); st = setTimeout(() => { const i = Math.round(tr.scrollLeft / tr.clientWidth); if (i !== cur) { cur = i; mark(); } }, 60); }, { passive: true });
    $$("[data-gal]").forEach((b) => (b.onclick = () => go(cur + +b.dataset.gal)));
    $$("[data-thumb]").forEach((b) => (b.onclick = () => go(+b.dataset.thumb)));
    tr.onkeydown = (e) => { if (e.key === "ArrowRight") go(cur + 1); if (e.key === "ArrowLeft") go(cur - 1); };
    $$("[data-zoom]").forEach((img) => (img.onclick = () => zoom(p, +img.dataset.zoom)));
  }
  function zoom(p, i) {
    const im = imgs(p); let cur = i;
    openModal(`<div class="zoom-wrap"><img src="${src(im[cur])}" alt="${esc(fullName(p))}" class="zoom" id="zimg">${im.length > 1 ? `<button class="gal-nav prev" id="zp" aria-label="Предыдущее">‹</button><button class="gal-nav next" id="zn" aria-label="Следующее">›</button><span class="gal-count" id="zc">${cur + 1} / ${im.length}</span>` : ""}</div>`, "wide");
    const show = () => { $("#zimg").src = src(im[cur]); const c = $("#zc"); if (c) c.textContent = `${cur + 1} / ${im.length}`; };
    if (im.length > 1) { $("#zp").onclick = () => { cur = (cur - 1 + im.length) % im.length; show(); }; $("#zn").onclick = () => { cur = (cur + 1) % im.length; show(); }; }
  }
  function initProduct() {
    const app = $("#ppApp"); const p = byId(document.body.dataset.pid || qs.get("id"));
    if (!p) { app.innerHTML = `<div class="empty"><h2>Товар не найден</h2><p>Возможно, он снят с продажи. <a class="link" href="${url("katalog/")}">Перейти в каталог</a></p></div>`; return; }
    const c = catById(p.category) || {}; const g = groups().find((x) => x.id === c.group);
    document.title = `${fullName(p)} — ${SHOP.name}`;
    const cr = $("#crumbs"); if (cr) cr.innerHTML = `<a href="${url("")}">Главная</a> / ${g && menuCats(g)[0] !== c ? `<a href="${groupUrl(g)}">${esc(g.name)}</a> / ` : ""}${c.id ? `<a href="${catUrl(c)}">${esc(c.name)}</a> / ` : ""}<span aria-current="page">${esc(p.name)}</span>`;
    const ws = [...new Set(p.variants.map((v) => v.w))];
    const lens = (w) => [...new Set(p.variants.filter((v) => v.w === w).map((v) => v.l))];
    let w = ws.includes(+qs.get("w")) ? +qs.get("w") : defSize(p).w;
    let l = lens(w).includes(+qs.get("l")) ? +qs.get("l") : lens(w).includes(200) ? 200 : lens(w).slice(-1)[0];
    let qty = 1;
    const sp = p.specs || {};
    const chips = [hardLabel(p), sp["Категория: Пружины"], ...fieldsOf(p).filter((f) => f.card && f.k !== "Высота матраса").map((f) => { const v = sp[f.k]; return !v ? "" : f.type === "yesno" ? (v === "Да" ? f.label || f.k : "") : v; }),
      sp["Высота матраса"] ? `Высота ${sp["Высота матраса"]} см` : "", sp["Категория: Двухсторонний"] === "Да" && !/namatras/.test(p.category) ? "Двусторонний" : ""].filter(Boolean);
    const warranty = String(sp["Гарантия"] || "");
    const code = !P.promoActive(p) && p.category !== "sale" ? live().find((x) => x.type === "code" && P.applies(x, p)) : null;
    const related = active().filter((x) => x.category === p.category && x.id !== p.id).sort((a, b) => (imgs(a).length ? 0 : 1) - (imgs(b).length ? 0 : 1) || Math.abs(a.min_price - p.min_price) - Math.abs(b.min_price - p.min_price)).slice(0, 4);
    const sizesUi = ws.length > 1 || lens(ws[0]).length > 1;
    app.innerHTML = `${p.example ? `<div class="ex-note"><b>Пример товара.</b> Название, цены, характеристики и иллюстрации придуманы, чтобы показать, как будет работать раздел. Всё редактируется в админке.</div>` : ""}
      <div class="pp"><div>${galleryHtml(p)}</div>
      <div class="pp-info"><h1>${esc(fullName(p))}</h1>
        <div class="chips">${chips.map((x) => `<span class="chip">${esc(x)}</span>`).join("")}</div>
        ${sizesUi ? `<span class="lbl" id="lw">Ширина, см</span><div class="sizes" id="ws" role="group" aria-labelledby="lw"></div><span class="lbl" id="ll">Длина, см</span><div class="sizes" id="lsz" role="group" aria-labelledby="ll"></div>` : ""}
        <div class="pp-price" id="price"></div><div id="promoBox"></div><div class="muted" id="sizeTxt"></div>
        ${p.category === "sale" ? `<p class="sale-note">Штучная позиция со склада, только размер ${p.variants[0].w}×${p.variants[0].l} см. Наличие подтвердит менеджер.</p>` : ""}
        <div class="qty-row"><span class="lbl">Количество</span><div class="qty"><button type="button" id="qm" aria-label="Меньше">−</button><span id="qv">1</span><button type="button" id="qp" aria-label="Больше">+</button></div>
          <button class="fav-btn inline" data-fav="${esc(p.id)}" aria-label="В избранное">${I.heart}</button></div>
        <div class="pp-actions"><button class="btn" id="add">В корзину</button><button class="btn ghost" id="quick">Быстрый заказ</button></div>
        <p class="muted small">Быстрый заказ — оставьте только телефон, менеджер перезвонит.</p>
        ${code ? `<div class="code-hint">${I.tag}<span>Ещё <b>−${code.pct}%</b> по промокоду <code>${esc(code.code)}</code> — на товары без скидки, вводится в корзине.</span></div>` : ""}
        <div class="perks"><div class="perk">${I.truck}<div><b>Доставка по Москве, МО и России</b>Стоимость и время согласует менеджер. Самовывоз из шоурума в Торбеево.</div></div>
          <div class="perk">${I.wallet}<div><b>Оплата при получении</b>Наличными или картой.</div></div>
          ${warranty && warranty !== "0" ? `<div class="perk">${I.shield}<div><b>Гарантия ${esc(yearsText(warranty))}</b>${sp["Срок службы"] ? "Срок службы " + esc(sp["Срок службы"]) : ""}</div></div>` : ""}
          <div class="perk">${I.ruler}<div><b>Нужен другой размер?</b>Изготовим по вашим меркам — <button class="link" data-callback="Нестандартный размер">оставьте заявку</button>.</div></div></div>
      </div></div>
      ${specsHtml(p)}
      ${related.length ? `<section class="sec tight"><div class="sec-h"><h2>Похожие товары</h2></div><div class="grid">${gridHtml(related)}</div></section>` : ""}`;
    initGallery(p);
    const draw = () => {
      if (sizesUi) {
        $("#ws").innerHTML = ws.map((x) => `<button type="button" class="${x === w ? "on" : ""}" data-w="${x}" aria-pressed="${x === w}">${x}</button>`).join("");
        const L = lens(w); if (!L.includes(l)) l = L.includes(200) ? 200 : L.slice(-1)[0];
        $("#lsz").innerHTML = L.map((x) => `<button type="button" class="${x === l ? "on" : ""}" data-l="${x}" aria-pressed="${x === l}">${x}</button>`).join("");
        $$("#ws button").forEach((b) => (b.onclick = () => { w = +b.dataset.w; draw(); }));
        $$("#lsz button").forEach((b) => (b.onclick = () => { l = +b.dataset.l; draw(); }));
      }
      const v = variant(p, w, l); const pr = P.priceOf(p, v.price);
      const old = pr.old || (p.regular_price && p.regular_price > pr.price ? p.regular_price : null);
      $("#price").innerHTML = `<b class="${old ? "hot" : ""}">${rub(pr.price * qty)}</b>${old ? ` <s>${rub(old * qty)}</s>` : ""}${pr.pct ? `<span class="pct-badge lg">−${pr.pct}%</span>` : old ? `<span class="pct-badge lg">−${Math.round((1 - pr.price / old) * 100)}%</span>` : ""}`;
      const gifts = P.giftsFor(p, w);
      $("#promoBox").innerHTML = (pr.pct ? `<div class="promo-box pc-${esc(pr.promo.color || "red")}"><div class="pb-top"><b>${esc(pr.promo.title)}</b><span>${untilText(pr.promo)}</span></div><div class="pb-row"><span>Выгода <b>${rub((pr.old - pr.price) * qty)}</b></span>${timer(pr.promo)}</div></div>` : "") +
        (old && !pr.pct ? `<div class="promo-box pc-night"><div class="pb-top"><b>Распродажа</b><span>Выгода ${rub((old - pr.price) * qty)}</span></div></div>` : "") +
        gifts.map((x) => `<div class="promo-box gift pc-${esc(x.color || "violet")}">${I.gift}<div><b>${esc(x.gift)} — в подарок</b><span>${esc(x.title)} · ${untilText(x)}</span></div></div>`).join("") +
        (!gifts.length ? live().filter((x) => x.type === "gift" && P.applies(x, p) && x.min_width && w < x.min_width && p.variants.some((y) => y.w >= x.min_width)).map((x) => `<p class="gift-hint">${I.gift} Выберите ширину от ${x.min_width} см — ${esc(x.gift.charAt(0).toLowerCase() + x.gift.slice(1))} в подарок.</p>`).join("") : "");
      $("#sizeTxt").textContent = `Размер ${w}×${l} см${qty > 1 ? `, ${qty} шт по ${rub(pr.price)}` : ""}`;
      $("#qv").textContent = qty;
      try { history.replaceState(null, "", (qs.get("id") ? "?id=" + enc(p.id) + "&" : "?") + "w=" + w + "&l=" + l); } catch (e) { /* file:// */ }
    };
    $("#qm").onclick = () => { qty = Math.max(1, qty - 1); draw(); };
    $("#qp").onclick = () => { qty = Math.min(20, qty + 1); draw(); };
    $("#add").onclick = () => { Cart.add(p.id, w, l, qty); toast(`Добавлено в корзину: ${p.name} ${w}×${l}`); $("#add").textContent = "Добавлено ✓"; setTimeout(() => ($("#add").textContent = "В корзину"), 1600); };
    $("#quick").onclick = () => quickOrder([{ product_id: p.id, width: w, length: l, qty }], "product");
    draw(); badges();
  }

  /* ================= акции ================= */
  function initPromos() {
    const app = $("#promoApp"); const lp = live(); const sc = saleCard();
    const planned = (CAT.promos || []).filter((x) => P.promoState(x) === "planned" && x.home !== false);
    const all = [...lp, sc].filter(Boolean);
    const section = (x) => {
      const list = x.type === "sale" ? saleItems() : x.type === "code" ? [] : promoProducts(x);
      const how = { percent: `Скидка ${x.pct}% уже в цене каждого размера, старая цена зачёркнута.`, gift: `${esc(x.gift)} — менеджер добавит подарок к заказу${x.min_width ? `, если ширина товара от ${x.min_width} см` : ""}.`, code: `Введите промокод <code>${esc(x.code)}</code> в корзине — ещё −${x.pct}% на товары, у которых нет другой скидки.`, sale: "Штучные модели со склада: один размер, цена ниже обычной. Количество ограничено." }[x.type];
      return `<section class="promo-sec2" id="${esc(x.id)}"><div class="ps-head pc-${esc(x.color || "red")}"><div><span class="pc-type">${TYPE_LABEL[x.type]}</span><h2>${esc(x.title)}</h2><p>${how}</p></div>
        <div class="ps-side">${x.type === "percent" || x.type === "code" ? `<span class="pc-big">−${x.pct}%</span>` : x.type === "sale" ? `<span class="pc-big">до −${x.pct}%</span>` : `<span class="pc-ico">${I.gift}</span>`}${x.to ? `<span>${untilText(x)}</span>${timer(x)}` : ""}</div></div>
        ${x.type === "code" ? `<div class="code-big"><code>${esc(x.code)}</code><button type="button" class="btn sm" data-copy="${esc(x.code)}">${I.copy} Скопировать</button><a class="btn ghost sm" href="${url("korzina/")}">Перейти в корзину</a></div>` : ""}
        ${list.length ? `<div class="grid">${gridHtml(list.slice(0, 12))}</div>${list.length > 12 ? `<p class="muted">и ещё ${list.length - 12} — смотрите в разделе каталога с фильтром «Со скидкой».</p>` : ""}` : ""}</section>`;
    };
    app.innerHTML = `<h1 class="page-h1">Акции и скидки</h1>
      <div class="how-promo"><div>${I.pct}<b>Скидка в цене</b><span>Цена на сайте уже со скидкой, старая — зачёркнута. Действует до даты окончания.</span></div>
        <div>${I.gift}<b>Подарок</b><span>Подарок добавляется к заказу автоматически — вы увидите его в корзине.</span></div>
        <div>${I.tag}<b>Промокод</b><span>Вводится в корзине и действует на товары без другой скидки.</span></div>
        <div>${I.clock}<b>Сроки</b><span>Акции включаются и выключаются сами по датам. Скидки не суммируются — действует бо́льшая.</span></div></div>
      ${all.length ? `<div class="promo-area">${all.map((x, i) => promoCard(x, i === 0)).join("")}</div>${all.map(section).join("")}` : `<div class="empty">Сейчас акций нет. Загляните позже или <button class="link" data-callback="Узнать о скидках">оставьте телефон</button> — сообщим.</div>`}
      ${planned.length ? `<h2 class="promo-h">Скоро</h2><div class="promo-area soon">${planned.map((x) => `<div class="pcard pc-${esc(x.color || "dark")} soon"><span class="pc-type">Скоро · с ${fmtDate(new Date(x.from + "T00:00:00"))}</span>${x.pct ? `<span class="pc-big">−${x.pct}%</span>` : ""}<b class="pc-title">${esc(x.title)}</b><span class="pc-text">${esc(x.text || "")}</span></div>`).join("")}</div>` : ""}`;
    badges();
    if (location.hash) { const t = document.getElementById(decodeURIComponent(location.hash.slice(1))); if (t) setTimeout(() => t.scrollIntoView(), 50); }
  }

  /* ================= корзина ================= */
  function initCart() {
    const box = $("#cart");
    const render = () => {
      const r = Cart.priced();
      if (!r) { box.innerHTML = `<div class="empty">Корзина пуста. <a class="link" href="${url("katalog/")}">Перейти в каталог</a></div>`; return; }
      const items = r.items; const oldTotal = items.reduce((s, x) => s + x.oldSum, 0); const disc = oldTotal - r.subtotal;
      const gifts = items.flatMap((x) => x.gifts);
      const codeAvail = live().some((x) => x.type === "code");
      box.innerHTML = `<div class="cart"><div>${items.map((x, i) => `<div class="citem"><a class="pic" href="${withQ(prodUrl(x.p), "w=" + x.width + "&l=" + x.length)}">${imgs(x.p)[0] ? `<img src="${src(imgs(x.p)[0])}" alt="">` : `<span class="noimg">${esc(x.p.name)}</span>`}</a>
          <div><a class="name" href="${withQ(prodUrl(x.p), "w=" + x.width + "&l=" + x.length)}">${esc(fullName(x.p))}</a><div class="muted">${x.width}×${x.length} см · ${rub(x.price)}${x.old ? ` <s>${rub(x.old)}</s> <span class="pct-inline">−${x.discount_pct}%</span>` : ""}</div>
          ${x.gifts.length ? `<div class="gift-line">${I.gift} Подарок: ${esc(x.gifts.join(", "))}</div>` : ""}${x.code_discount ? `<div class="muted small">Промокод: −${rub(x.code_discount)}</div>` : ""}</div>
          <div class="r"><div class="qty"><button data-qm="${i}" aria-label="Меньше">−</button><span>${x.qty}</span><button data-qp="${i}" aria-label="Больше">+</button></div><b>${rub(x.sum)}</b><button class="del" data-del="${i}">Удалить</button></div></div>`).join("")}</div>
        <aside class="summary"><div class="sum-row"><span>Товары, ${Cart.count()} шт</span><span>${rub(oldTotal)}</span></div>
          ${disc > 0 ? `<div class="sum-row good"><span>Скидка по акциям</span><span>−${rub(disc)}</span></div>` : ""}
          ${r.code_discount ? `<div class="sum-row good"><span>Промокод ${esc(r.promo_code)}</span><span>−${rub(r.code_discount)}</span></div>` : ""}
          ${gifts.length ? `<div class="sum-row good"><span>Подарки</span><span>${gifts.length} шт</span></div>` : ""}
          <div class="sum-row"><span>Доставка</span><span class="muted">рассчитает менеджер</span></div>
          <div class="sum-row t"><span>Итого</span><span>${rub(r.total)}</span></div>
          ${codeAvail || r.promo_code ? `<form class="code-form" id="codeForm"><input class="inp" id="codeIn" placeholder="Промокод" value="${esc(r.promo_code || "")}" aria-label="Промокод" autocapitalize="characters"${r.promo_code ? " readonly" : ""}><button class="btn ghost sm">${r.promo_code ? "Убрать" : "Применить"}</button></form><div class="err-msg" id="codeErr" role="alert"></div>` : ""}
          <p class="how">Как оформить?</p>
          <label class="choice"><input type="radio" name="how" value="quick"><b>Быстро</b><small>Только телефон. Менеджер перезвонит и всё уточнит.</small></label>
          <label class="choice"><input type="radio" name="how" value="full" checked><b>Полностью</b><small>Сами укажете адрес и способ оплаты. Около 2 минут.</small></label>
          <button class="btn block" id="go">Оформить заказ</button></aside></div>`;
      $$("[data-qm]").forEach((b) => (b.onclick = () => { const i = +b.dataset.qm; Cart.setQty(i, Cart.items()[i].qty - 1); render(); }));
      $$("[data-qp]").forEach((b) => (b.onclick = () => { const i = +b.dataset.qp; Cart.setQty(i, Cart.items()[i].qty + 1); render(); }));
      $$("[data-del]").forEach((b) => (b.onclick = () => { Cart.remove(+b.dataset.del); render(); }));
      const cf = $("#codeForm"); if (cf) cf.onsubmit = (e) => {
        e.preventDefault(); if (r.promo_code) { ls.set("tmvo_code", ""); render(); return; }
        const v = $("#codeIn").value.trim(); if (!v) return;
        try { const t = API.priceItems(Cart.items(), v); ls.set("tmvo_code", t.promo_code); toast(t.code_discount ? `Промокод применён: −${rub(t.code_discount)}` : "Промокод принят, но все товары уже со скидкой"); render(); }
        catch (err) { $("#codeErr").textContent = err.message; }
      };
      $("#go").onclick = () => { if ($("input[name=how]:checked").value === "quick") quickOrder(Cart.items(), "cart"); else location.href = url("oformlenie/"); };
    };
    render();
  }

  /* ================= оформление заказа ================= */
  const CO_KEY = "tmvo_checkout";
  const STEPS = ["Контакты", "Получатель", "Получение", "Оплата", "Проверка"];
  function initCheckout() {
    const main = $("#co"), side = $("#co-sum");
    const r = Cart.priced();
    if (!r) { $("#co-wrap").innerHTML = `<div class="empty">Корзина пуста. <a class="link" href="${url("katalog/")}">Перейти в каталог</a></div>`; return; }
    const S = ss.get(CO_KEY, { step: 0, id: null, token: null, d: {} });
    const D = Object.assign({ phone: "", name: "", email: "", comment: "", delivery: (CFG.delivery.find((x) => x.enabled) || {}).id, city: "Москва", street: "", floor: "", flat: "", lift: false, payment: (CFG.payment.find((x) => x.enabled) || {}).id }, S.d);
    const save = () => { S.d = D; ss.set(CO_KEY, S); };
    side.innerHTML = r.items.map((x) => `<div class="sum-row small"><span>${esc(fullName(x.p))}, ${x.width}×${x.length}${x.qty > 1 ? " × " + x.qty : ""}${x.discount_pct ? ` <span class="pct-inline">−${x.discount_pct}%</span>` : ""}${x.gifts.length ? `<br><span class="gift-line">${I.gift} ${esc(x.gifts.join(", "))}</span>` : ""}</span><span class="nowrap">${rub(x.sum)}</span></div>`).join("") +
      (r.code_discount ? `<div class="sum-row small good"><span>Промокод ${esc(r.promo_code)}</span><span>−${rub(r.code_discount)}</span></div>` : "") +
      `<div class="sum-row small"><span>Доставка</span><span class="muted">рассчитает менеджер</span></div><div class="sum-row t"><span>Итого</span><span>${rub(r.total)}</span></div><a class="link small" href="${url("korzina/")}">Изменить корзину</a>`;
    const head = (i) => `<div class="co-steps">${STEPS.map((_, k) => `<i class="${k <= i ? "on" : ""}"></i>`).join("")}</div><div class="co-lbl">Шаг ${i + 1} из ${STEPS.length}: ${STEPS[i].toLowerCase()}</div>`;
    const nav = (back) => `<div class="err-msg" id="coerr" role="alert"></div><div class="co-nav">${back !== undefined ? `<button type="button" class="link" data-step="${back}">← Назад</button>` : "<span></span>"}<button class="btn" id="next">Продолжить</button></div>`;
    const patch = (body) => API.updateOrder(S.id, S.token, Object.assign({ items: Cart.items(), promo_code: r.promo_code || undefined }, body));
    const fail = (err) => { const e = $("#coerr"); if (e) e.textContent = err.message || "Ошибка, попробуйте ещё раз"; $$("#co button.btn").forEach((b) => (b.disabled = false)); };
    function draw() {
      const i = S.step;
      if (i === 0) {
        main.innerHTML = `${head(0)}<form id="f" novalidate><h2>Контактный телефон</h2><p class="muted">Без регистрации и SMS-кода. По этому номеру менеджер подтвердит заказ.</p>
          <div class="field"><label for="phone">Телефон <span class="req">*</span></label><input class="inp" id="phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+7 (___) ___-__-__" value="${esc(D.phone)}"></div>
          ${consentsHtml()}${nav()}</form>`;
        const f = $("#f"); maskPhone(f.phone); if (S.id) { f.privacy.checked = true; f.personal_data.checked = true; } guard(f, $("#next"));
        f.onsubmit = async (e) => { e.preventDefault(); if (f.website.value) return; $("#next").disabled = true; D.phone = f.phone.value;
          try { if (!S.id) { const o = await API.createDraft({ phone: D.phone, items: Cart.items(), consents: consentsOf(f), source: "checkout", promo_code: r.promo_code || undefined }); S.id = o.id; S.token = o.token; } else await patch({ phone: D.phone }); S.step = 1; save(); draw(); } catch (err) { fail(err); } };
      }
      if (i === 1) {
        main.innerHTML = `${head(1)}<form id="f" novalidate><h2>Получатель</h2>
          <div class="field"><label>Телефон</label><div class="row-inline"><input class="inp" value="${esc(D.phone)}" readonly aria-label="Телефон"><button type="button" class="link" data-step="0">Изменить</button></div></div>
          <div class="field"><label for="name">Имя <span class="req">*</span></label><input class="inp" id="name" name="name" autocomplete="given-name" value="${esc(D.name)}"></div>
          <div class="field"><label for="email">E-mail <span class="opt">— по желанию, пришлём копию заказа</span></label><input class="inp" id="email" name="email" type="email" autocomplete="email" value="${esc(D.email)}"></div>
          <div class="field"><label for="comment">Комментарий <span class="opt">— по желанию</span></label><textarea class="inp" id="comment" name="comment" placeholder="Например: позвоните после 18:00">${esc(D.comment)}</textarea></div>${nav(0)}</form>`;
        const f = $("#f"), b = $("#next"); const upd = () => { const em = f.email.value.trim(); b.disabled = f.name.value.trim().length < 2 || (em && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)); }; f.oninput = upd; upd();
        f.onsubmit = async (e) => { e.preventDefault(); b.disabled = true; D.name = f.name.value.trim(); D.email = f.email.value.trim(); D.comment = f.comment.value.trim();
          try { await patch({ name: D.name, email: D.email, comment: D.comment }); S.step = 2; save(); draw(); } catch (err) { fail(err); } };
      }
      if (i === 2) {
        const ms = CFG.delivery.filter((x) => x.enabled);
        main.innerHTML = `${head(2)}<form id="f" novalidate><h2>Получение</h2>${ms.map((m) => `<label class="opt-card"><input type="radio" name="dm" value="${m.id}" ${D.delivery === m.id ? "checked" : ""}><span><b>${esc(m.title)}</b><small>${esc(m.note)}</small></span></label>`).join("")}<div id="addr"></div>${nav(1)}</form>`;
        const f = $("#f"), b = $("#next");
        const upd = () => { b.disabled = D.delivery === "courier" && (!f.city || f.city.value.trim().length < 2 || f.street.value.trim().length < 5); };
        const drawAddr = () => {
          $("#addr").innerHTML = D.delivery === "courier" ? `<div class="field"><label for="city">Город или населённый пункт <span class="req">*</span></label><input class="inp" id="city" name="city" autocomplete="address-level2" value="${esc(D.city)}"></div>
            <div class="field"><label for="street">Улица и дом <span class="req">*</span></label><input class="inp" id="street" name="street" autocomplete="street-address" placeholder="Например: Ленинский проспект, д 45" value="${esc(D.street)}"></div>
            <div class="row2"><div class="field"><label for="floor">Этаж</label><input class="inp" id="floor" name="floor" inputmode="numeric" value="${esc(D.floor)}"></div><div class="field"><label for="flat">Квартира / офис</label><input class="inp" id="flat" name="flat" value="${esc(D.flat)}"></div></div>
            <label class="cbx"><input type="checkbox" name="lift" ${D.lift ? "checked" : ""}> <span>В доме есть грузовой лифт</span></label>` : `<p class="muted">Шоурум: ${esc(SHOP.address)}. Менеджер согласует время, когда заказ будет готов.</p>`;
          upd();
        };
        $$("input[name=dm]", f).forEach((x) => (x.onchange = () => { D.delivery = x.value; drawAddr(); })); f.oninput = upd; drawAddr();
        f.onsubmit = async (e) => { e.preventDefault(); b.disabled = true;
          if (D.delivery === "courier") { D.city = f.city.value.trim(); D.street = f.street.value.trim(); D.floor = f.floor.value.trim(); D.flat = f.flat.value.trim(); D.lift = f.lift.checked; }
          try { await patch({ delivery: D.delivery === "courier" ? { method: "courier", city: D.city, street: D.street, floor: D.floor, flat: D.flat, lift: D.lift } : { method: D.delivery } }); S.step = 3; save(); draw(); } catch (err) { fail(err); } };
      }
      if (i === 3) {
        const pm = CFG.payment.filter((x) => x.enabled); const gs = [...new Set(pm.map((x) => x.group))];
        if (!pm.find((x) => x.id === D.payment)) D.payment = pm[0] && pm[0].id;
        main.innerHTML = `${head(3)}<form id="f" novalidate><h2>Способ оплаты</h2>${gs.map((g) => `<div class="grp-l">${esc(g)}</div>${pm.filter((x) => x.group === g).map((m) => `<label class="opt-card"><input type="radio" name="pm" value="${m.id}" ${D.payment === m.id ? "checked" : ""}><span><b>${esc(m.title)}</b><small>${esc(m.note)}</small></span></label>`).join("")}`).join("")}${nav(2)}</form>`;
        const f = $("#f"); f.onsubmit = async (e) => { e.preventDefault(); $("#next").disabled = true; D.payment = f.pm.value; try { await patch({ payment_method: D.payment }); S.step = 4; save(); draw(); } catch (err) { fail(err); } };
      }
      if (i === 4) {
        const m = CFG.payment.find((x) => x.id === D.payment) || {}; const dm = CFG.delivery.find((x) => x.id === D.delivery) || {};
        const addr = D.delivery === "courier" ? `${D.city}, ${D.street}${D.flat ? ", кв./офис " + D.flat : ""}${D.floor ? ", этаж " + D.floor : ""}${D.lift ? ", есть грузовой лифт" : ""}` : SHOP.address;
        const rv = (h, v, s) => `<div class="rv"><div class="h"><span>${h}</span><button type="button" class="link" data-step="${s}">Изменить</button></div><div class="v">${v}</div></div>`;
        main.innerHTML = `${head(4)}<form id="f" novalidate><h2>Проверьте заказ</h2>
          ${rv("Телефон", esc(D.phone), 0)}${rv("Получатель", esc(D.name) + (D.email ? `<br><span class="muted">${esc(D.email)}</span>` : "") + (D.comment ? `<br><span class="muted">${esc(D.comment)}</span>` : ""), 1)}
          ${rv(esc(dm.title || "Получение"), esc(addr), 2)}${rv("Оплата", esc(m.title || ""), 3)}
          <label class="cbx"><input type="checkbox" name="offer"> <span>Принимаю условия <a href="${url("oferta/")}" target="_blank">публичной оферты</a></span></label>
          <label class="cbx"><input type="checkbox" name="marketing"> <span>Хочу получать новости и скидки <span class="muted">(по желанию)</span></span></label>
          <div class="err-msg" id="coerr" role="alert"></div>
          <div class="co-nav"><button type="button" class="link" data-step="3">← Назад</button><button class="btn" id="next" disabled>${m.online ? "Подтвердить и перейти к оплате" : "Подтвердить заказ"}</button></div></form>`;
        const f = $("#f"), b = $("#next"); f.onchange = () => (b.disabled = !f.offer.checked);
        f.onsubmit = async (e) => { e.preventDefault(); b.disabled = true; b.textContent = "Отправляем…";
          try {
            const o = await API.confirmOrder(S.id, S.token, { offer_accepted: true, marketing: f.marketing.checked });
            Cart.clear(); ss.del(CO_KEY);
            if (m.online) { const pay = await API.createPayment(o.id, o.token, { method: m.id }); location.href = pay.confirmation_url; return; }
            location.href = url("zakaz/") + "?id=" + enc(o.id) + "&t=" + enc(o.token) + "&new=1";
          } catch (err) { fail(err); b.textContent = m.online ? "Подтвердить и перейти к оплате" : "Подтвердить заказ"; }
        };
      }
      $$("#co [data-step]").forEach((x) => (x.onclick = () => { S.step = +x.dataset.step; save(); draw(); }));
      const h = $("#co h2"); if (h && draw.started) { h.setAttribute("tabindex", "-1"); h.focus({ preventScroll: true }); main.scrollIntoView({ block: "nearest" }); }
      draw.started = true;
    }
    draw();
  }

  /* ================= страница заказа ================= */
  const STATUS = { draft: "Оформление не завершено", new: "Принят", in_work: "В работе", awaiting_payment: "Ожидает оплаты", paid: "Оплачен", delivery: "В доставке", done: "Выполнен", canceled: "Отменён" };
  async function initOrder() {
    const el = $("#ord");
    try {
      const o = await API.getOrder(qs.get("id"), qs.get("t"));
      const pm = CFG.payment.find((x) => x.id === o.payment.method) || {}; const d = o.delivery || {};
      const addr = d.method === "courier" ? `${d.city}, ${d.street}${d.flat ? ", кв./офис " + d.flat : ""}${d.floor ? ", этаж " + d.floor : ""}` : d.method === "pickup" ? "Самовывоз: " + SHOP.address : "Уточнит менеджер";
      el.innerHTML = `${qs.get("new") ? `<div class="okmark">${I.check}</div><h1>Спасибо! Заказ № ${o.number} принят</h1><p class="muted lead">Менеджер позвонит на ${esc(formatPhone(o.customer.phone))}, чтобы подтвердить заказ и согласовать ${d.method === "pickup" ? "самовывоз" : "доставку"}. Рабочее время: ${esc(SHOP.workStart)}–${esc(SHOP.workEnd)}.</p>` : `<h1>Заказ № ${o.number}</h1>`}
        <p><span class="status st-${o.status}">${STATUS[o.status] || o.status}</span></p>
        <div class="box"><h3>Состав заказа</h3>${o.items.map((x) => { const p = byId(x.product_id); return `<div class="sum-row"><span>${esc(p ? fullName(p) : x.name)}, ${x.width}×${x.length} × ${x.qty}${(x.gifts || []).length ? `<br><span class="gift-line">${I.gift} ${esc(x.gifts.join(", "))}</span>` : ""}</span><span>${rub(x.sum)}</span></div>`; }).join("")}
          ${o.code_discount ? `<div class="sum-row good"><span>Промокод ${esc(o.promo_code)}</span><span>−${rub(o.code_discount)}</span></div>` : ""}<div class="sum-row t"><span>Итого</span><span>${rub(o.total)}</span></div></div>
        <div class="box"><h3>Получение</h3><p>${esc(addr)}</p></div>
        <div class="box"><h3>Оплата</h3><p>${esc(pm.title || "Уточнит менеджер")} — ${o.payment.status === "paid" ? "оплачено" : pm.online ? "не оплачено" : "при получении"}</p>
          ${pm.online && o.payment.status !== "paid" && o.status === "awaiting_payment" ? `<button class="btn" id="pay">Оплатить ${rub(o.total)}</button>` : ""}</div>
        <p class="muted">Сохраните ссылку на эту страницу, чтобы следить за статусом. Вопросы: ${esc(SHOP.phone)}.</p><a class="btn ghost" href="${url("")}">На главную</a>`;
      const pb = $("#pay"); if (pb) pb.onclick = async () => { pb.disabled = true; const r = await API.createPayment(o.id, qs.get("t"), { method: o.payment.method }); location.href = r.confirmation_url; };
    } catch (err) { el.innerHTML = `<h1>Заказ не найден</h1><p class="muted">Проверьте ссылку или позвоните нам: ${esc(SHOP.phone)}.</p>`; }
  }

  /* ================= поиск ================= */
  const POPULAR = ["160×200", "жёсткий", "кокос", "без пружин", "кровать с подъёмником", "до 20 000", "детский", "непромокаемый"];
  const sUrl = (q) => url("poisk/") + "?q=" + enc(q);
  function suggestHtml(q) {
    if (!q.trim()) return `<div class="sg-h">Популярные запросы</div><div class="sg-pop">${POPULAR.map((x) => `<a href="${sUrl(x)}" class="sg-item chip">${esc(x)}</a>`).join("")}</div>`;
    const r = S.run(q, CAT, { limit: 6 });
    const head = r.filters.length ? `<div class="sg-chips"><span>Понял так:</span>${r.filters.map((x) => `<span class="chip on">${esc(x.t)}</span>`).join("")}</div>` : "";
    const fix = r.fix ? `<a class="sg-fix sg-item" href="${sUrl(r.fix)}">Возможно, вы искали: <b>${esc(r.fix)}</b></a>` : "";
    const cats = r.cats.slice(0, 3).map((c) => `<a class="sg-cat sg-item" href="${catUrl(c)}">${I.search}<span>Раздел <b>${esc(c.name)}</b></span><small>${countLabel(inCat(c.id).length)}</small></a>`).join("");
    const sz = r.f.w ? "w=" + r.f.w + (r.f.l ? "&l=" + r.f.l : "") : "";
    const prods = r.products.map(({ p }) => { const pr = P.priceOf(p, S.minPrice(p, r.f)); const im = imgs(p)[0];
      return `<a class="sg-prod sg-item" href="${sz ? withQ(prodUrl(p), sz) : prodUrl(p)}"><span class="sg-pic">${im ? `<img src="${src(im)}" alt="" loading="lazy">` : ""}</span><span class="sg-name">${esc(fullName(p))}<small>${esc((catById(p.category) || {}).name || "")}${hardLabel(p) ? " · " + esc(hardLabel(p)) : ""}</small></span><span class="sg-price">${p.variants.length > 1 && !r.f.l ? "от " : ""}${rub(pr.price)}${pr.pct ? `<span class="pct-inline">−${pr.pct}%</span>` : ""}</span></a>`; }).join("");
    if (!r.total && !cats) return head + fix + `<div class="sg-empty">Ничего не нашлось по «${esc(q)}». Попробуйте: ${POPULAR.slice(0, 4).map((x) => `<a href="${sUrl(x)}">${esc(x)}</a>`).join(", ")}</div>`;
    return head + fix + cats + prods + (r.total ? `<a class="sg-all sg-item" href="${sUrl(q)}">Все результаты: ${countLabel(r.total)} →</a>` : "");
  }
  function initSuggest(form) {
    const inp = $("input", form), box = $(".suggest", form); if (!inp || !box) return; let t = null, sel = -1;
    const show = () => { box.innerHTML = suggestHtml(inp.value); box.hidden = false; sel = -1; form.classList.add("open"); };
    const hide = () => { box.hidden = true; form.classList.remove("open"); };
    inp.addEventListener("input", () => { clearTimeout(t); t = setTimeout(show, 60); });
    inp.addEventListener("focus", show);
    inp.addEventListener("keydown", (e) => {
      const items = $$(".sg-item", box);
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); if (box.hidden) show(); sel = Math.max(-1, Math.min(items.length - 1, sel + (e.key === "ArrowDown" ? 1 : -1))); items.forEach((x, i) => x.classList.toggle("on", i === sel)); if (items[sel]) items[sel].scrollIntoView({ block: "nearest" }); }
      if (e.key === "Enter" && sel >= 0 && items[sel]) { e.preventDefault(); location.href = items[sel].href; }
      if (e.key === "Escape") { hide(); inp.blur(); }
    });
    document.addEventListener("click", (e) => { if (!form.contains(e.target)) hide(); });
    form.addEventListener("submit", (e) => { if (!inp.value.trim()) { e.preventDefault(); inp.focus(); } });
    if (PAGE === "search") inp.value = qs.get("q") || "";
  }
  function initSearch() {
    const app = $("#searchApp"); const q = (qs.get("q") || "").trim();
    let sort = "rel";
    const draw = () => {
      const r = S.run(q, CAT);
      const list = r.products.map((x) => x.p);
      if (sort === "asc") list.sort((a, b) => S.minPrice(a, r.f) - S.minPrice(b, r.f)); if (sort === "desc") list.sort((a, b) => S.minPrice(b, r.f) - S.minPrice(a, r.f));
      if (sort === "disc") list.sort((a, b) => P.priceOf(b, b.min_price).pct - P.priceOf(a, a.min_price).pct);
      app.innerHTML = `<h1 class="page-h1">${q ? `Поиск: «${esc(q)}»` : "Поиск"}</h1>
        ${r.filters.length ? `<div class="s-chips"><span class="muted">Понял запрос так:</span>${r.filters.map((x) => `<span class="chip on">${esc(x.t)}</span>`).join("")}${r.words.length ? `<span class="chip">+ «${esc(r.words.join(" "))}»</span>` : ""}</div>` : ""}
        ${r.fix ? `<p class="s-fix">Возможно, вы искали: <a class="link" href="${sUrl(r.fix)}">${esc(r.fix)}</a></p>` : ""}
        ${r.fuzzy ? `<p class="muted">Точных совпадений нет — показываем похожие.</p>` : ""}
        ${r.cats.length ? `<div class="sublinks">${r.cats.map((c) => `<a href="${catUrl(c)}">${esc(c.name)} <span class="muted">${inCat(c.id).length}</span></a>`).join("")}</div>` : ""}
        ${q && r.total ? `<div class="toolbar"><span class="muted">Найдено: ${countLabel(r.total)}</span>${r.total > 1 ? `<select id="ssort" aria-label="Сортировка"><option value="rel">По совпадению</option><option value="asc">Сначала дешевле</option><option value="desc">Сначала дороже</option><option value="disc">Сначала со скидкой</option></select>` : ""}</div>` : ""}
        <div class="grid">${list.length ? gridHtml(list) : `<div class="empty wide">${q ? `По запросу «${esc(q)}» ничего не нашлось. Попробуйте другие слова:` : "Введите в строку поиска вверху название модели, наполнитель, размер или жёсткость. Например:"}<div class="sg-pop center">${POPULAR.map((x) => `<a href="${sUrl(x)}" class="chip">${esc(x)}</a>`).join("")}</div></div>`}</div>`;
      const ssEl = $("#ssort"); if (ssEl) { ssEl.value = sort; ssEl.onchange = (e) => { sort = e.target.value; draw(); }; }
      if (r.f.w) $$(".grid .card a").forEach((a) => (a.href = withQ(a.href, "w=" + r.f.w + (r.f.l ? "&l=" + r.f.l : ""))));
      badges();
    };
    draw();
  }
  function initFav() {
    const list = Fav.all().map(byId);
    $("#fres").innerHTML = list.length ? gridHtml(list) : `<div class="empty wide">В избранном пока ничего нет. Нажмите ♡ на карточке товара, чтобы сохранить его здесь.</div>`;
    badges();
  }

  /* ================= общие обработчики ================= */
  document.addEventListener("click", (e) => {
    const t = e.target;
    if (t.closest("[data-close]")) { closeModal(); return; }
    const cp = t.closest("[data-copy]"); if (cp) { e.preventDefault(); e.stopPropagation(); try { navigator.clipboard.writeText(cp.dataset.copy); } catch (er) { /* нет доступа */ } toast(`Промокод ${cp.dataset.copy} скопирован`); return; }
    const qb = t.closest("[data-quick]"); if (qb) { e.preventDefault(); quickPick(qb.dataset.quick); return; }
    if (t.closest("#totop")) { window.scrollTo({ top: 0, behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" }); return; }
    const cb = t.closest("[data-callback]"); if (cb) { e.preventDefault(); callbackModal(cb.dataset.callback); return; }
    const fv = t.closest("[data-fav]"); if (fv) { e.preventDefault(); const on = Fav.toggle(fv.dataset.fav); toast(on ? "Добавлено в избранное" : "Убрано из избранного"); if (PAGE === "favorites") initFav(); return; }
    if (t.closest("#burger")) { $("#drawer").classList.add("on"); return; }
    if (t.closest("[data-drawer-close]")) $("#drawer").classList.remove("on");
    const cat = t.closest("#catbtn"); if (cat) { const m = $("#megamenu"); const on = m.hidden; m.hidden = !on; cat.setAttribute("aria-expanded", on); cat.classList.toggle("on", on); return; }
    if (!t.closest("#megamenu")) { const m = $("#megamenu"); if (m && !m.hidden) { m.hidden = true; $("#catbtn").setAttribute("aria-expanded", "false"); $("#catbtn").classList.remove("on"); } }
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeModal(); $("#drawer").classList.remove("on"); const m = $("#megamenu"); if (m) m.hidden = true; } });
  window.addEventListener("storage", (e) => { if (e.key === "tmvo_cart" || e.key === "tmvo_fav") badges(); });

  const top = $("#totop"); if (top) { const f = () => (top.hidden = window.scrollY < 600); window.addEventListener("scroll", f, { passive: true }); f(); }
  if (!ls.get("tmvo_cookie_ok", false)) {
    const c = document.createElement("div"); c.className = "cookie";
    c.innerHTML = `<span>Сайт использует файлы cookie для работы корзины и статистики. <a href="${url("politika-konfidentsialnosti/")}">Подробнее</a></span><button class="btn sm">Понятно</button>`;
    c.querySelector("button").onclick = () => { ls.set("tmvo_cookie_ok", true); c.remove(); };
    document.body.appendChild(c);
  }
  renderChrome();
  $$("form.hsearch").forEach(initSuggest);
  $$("form.lead-form").forEach(inlineLead);
  ({ home: initHome, category: initCategory, product: initProduct, promos: initPromos, cart: initCart, checkout: initCheckout, order: initOrder, search: initSearch, favorites: initFav }[PAGE] || (() => {}))();
  fillLists();
  badges();
})();
