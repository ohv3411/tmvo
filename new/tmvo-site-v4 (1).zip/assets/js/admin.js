/*
 * Панель управления: заказы, заявки, товары, разделы, акции, данные.
 *
 * mock / lite — заказы из localStorage этого браузера; каталог — JSON-база data/catalog.json.
 *   Правки каталога сохраняются в черновик (IndexedDB этого браузера) и сразу видны на сайте в этом браузере.
 *   Публикация: «Скачать catalog.json» (положить в репозиторий) или «Опубликовать на GitHub» (коммит через GitHub API).
 *   Вход test / test из config.js — это не защита.
 * api — всё через сервер: /api/admin/* (TECH_SPEC.md, раздел 10).
 */
(async function () {
  const CFG = window.TMVO_CONFIG, ROOT = window.TMVO_ROOT || "", DATA = window.TMVO_DATA, PR = window.TMVO_PRICE;
  const STATIC = window.TMVO_STATIC || { products: {}, categories: {} };
  const $ = (s, r) => (r || document).querySelector(s), $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const rub = (n) => Math.round(n || 0).toLocaleString("ru-RU").replace(/ |,/g, " ") + " ₽";
  const dt = (s) => { try { return new Date(s).toLocaleString("ru-RU", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" }); } catch (e) { return s; } };
  const dd = (s) => { try { return new Date(s + "T00:00:00").toLocaleDateString("ru-RU", { day: "numeric", month: "short", year: "numeric" }); } catch (e) { return s; } };
  const phone = (p) => { const d = String(p || "").replace(/\D/g, "").slice(-10); return d.length === 10 ? `+7 (${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6, 8)}-${d.slice(8)}` : (p || "—"); };
  const ls = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* недоступно */ } } };
  const ss = { get(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { sessionStorage.setItem(k, v); } catch (e) { /* недоступно */ } }, del(k) { try { sessionStorage.removeItem(k); } catch (e) { /* недоступно */ } } };
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const TR = { а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "e", ж: "zh", з: "z", и: "i", й: "y", к: "k", л: "l", м: "m", н: "n", о: "o", п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f", х: "h", ц: "ts", ч: "ch", ш: "sh", щ: "sch", ъ: "", ы: "y", ь: "", э: "e", ю: "yu", я: "ya" };
  const slug = (s) => String(s || "").toLowerCase().split("").map((c) => (c in TR ? TR[c] : c)).join("").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const addDays = (iso, n) => { const d = new Date(iso + "T00:00:00"); d.setDate(d.getDate() + n); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
  const site = (path) => ROOT + path + "index.html";

  const STATUS = [["draft", "Незавершённое оформление"], ["new", "Новый"], ["in_work", "В работе"], ["awaiting_payment", "Ожидает оплаты"], ["paid", "Оплачен"], ["delivery", "В доставке"], ["done", "Выполнен"], ["canceled", "Отменён"]];
  const SNAME = Object.fromEntries(STATUS);
  const PAY = Object.fromEntries(CFG.payment.map((p) => [p.id, p.title]));
  const DEL = Object.fromEntries(CFG.delivery.map((p) => [p.id, p.title]));
  const API_MODE = CFG.apiMode === "api";
  const MAX_IMG = 5;

  /* ---------- каталог: рабочая копия ---------- */
  await DATA.ready;
  // если опубликованный каталог уже совпадает с черновиком (после публикации) — черновик больше не нужен
  if (window.CATALOG._draft && DATA.base && DATA.base.updated && DATA.base.updated === window.CATALOG.updated) { await DATA.dropDraft(); window.CATALOG = DATA.base; }
  let C = clone(window.CATALOG); delete C._draft;
  C.promos = C.promos || []; C.groups = C.groups || [];
  const isDraft = () => DATA.hasDraft();
  const byId = (id) => C.products.find((p) => p.id === id);
  const catById = (id) => C.categories.find((c) => c.id === id);
  const fullName = (p) => (p.word && p.category !== "detskie-namatrasniki" ? p.word + " " : "") + p.name;
  const imgs = (p) => (p.images && p.images.length ? p.images : p.image ? [p.image] : []);
  const src = (s) => (/^(data:|https?:|blob:)/.test(s) ? s : ROOT + s);
  const prodUrl = (p) => (p.path && STATIC.products[p.id] === p.path ? site(p.path) : ROOT + "tovar/index.html?id=" + encodeURIComponent(p.id));
  const catUrl = (c) => (STATIC.categories[c.id] === c.url ? site(c.url) : ROOT + "katalog/index.html?c=" + encodeURIComponent(c.id));
  function withCatalog(fn) { const prev = window.CATALOG; window.CATALOG = C; try { return fn(); } finally { window.CATALOG = prev; } }
  async function saveCatalog(msg) {
    C.products.forEach((p) => { p.variants.sort((a, b) => a.w - b.w || a.l - b.l); p.min_price = Math.min(...p.variants.map((v) => v.price)); p.image = undefined; });
    if (API_MODE) { await req("PUT", "/catalog", C); } else { C = clone(await DATA.saveDraft(C)); DATA.setDraftOn(true); }
    toast(msg || "Сохранено");
  }

  /* ---------- заказы: источник данных ---------- */
  const local = {
    async login(l, p) { if (l === CFG.adminDemo.login && p === CFG.adminDemo.password) return { token: "demo" }; throw new Error("Неверный логин или пароль"); },
    async orders() { return Object.values(ls.get("tmvo_mock_orders", {})).sort((a, b) => (b.created_at > a.created_at ? 1 : -1)); },
    async saveOrder(o) { const all = ls.get("tmvo_mock_orders", {}); all[o.id] = o; ls.set("tmvo_mock_orders", all); return o; },
    async callbacks() { return ls.get("tmvo_mock_callbacks", []); },
    async saveCallback(c) { const all = ls.get("tmvo_mock_callbacks", []); const i = all.findIndex((x) => x.id === c.id); if (i >= 0) all[i] = c; ls.set("tmvo_mock_callbacks", all); return c; }
  };
  async function req(method, path, body) {
    const r = await fetch(CFG.apiBase + "/admin" + path, { method, credentials: "same-origin", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + (ss.get("tmvo_admin") || "") }, body: body ? JSON.stringify(body) : undefined });
    const d = await r.json().catch(() => null); if (!r.ok) throw new Error((d && d.message) || "Ошибка сервера"); return d;
  }
  const remote = {
    login: (l, p) => req("POST", "/login", { login: l, password: p }),
    orders: () => req("GET", "/orders"), saveOrder: (o) => req("PATCH", "/orders/" + encodeURIComponent(o.id), { status: o.status, manager_comment: o.manager_comment }),
    callbacks: () => req("GET", "/callbacks"), saveCallback: (c) => req("PATCH", "/callbacks/" + encodeURIComponent(c.id), { status: c.status })
  };
  const DS = API_MODE ? remote : local;

  /* ---------- общие элементы ---------- */
  const app = $("#adm");
  function toast(t) { let el = $("#atoast"); if (!el) { el = document.createElement("div"); el.id = "atoast"; el.className = "toast"; document.body.appendChild(el); } el.textContent = t; el.classList.add("on"); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove("on"), 2200); }
  function confirmBox(text) { return window.confirm(text); }

  function loginView(err) {
    app.innerHTML = `<div class="adm-login"><form id="lf" class="box" novalidate><img src="${ROOT}img/logo.svg" alt="Торбеевские матрасы" class="adm-logo"><h1>Вход в панель управления</h1>
      <div class="field"><label for="lg">Логин</label><input class="inp" id="lg" autocomplete="username" required></div>
      <div class="field"><label for="pw">Пароль</label><input class="inp" id="pw" type="password" autocomplete="current-password" required></div>
      <div class="err-msg" role="alert">${esc(err || "")}</div><button class="btn block">Войти</button>
      ${API_MODE ? "" : `<p class="muted small">Демо-доступ: <b>${esc(CFG.adminDemo.login)}</b> / <b>${esc(CFG.adminDemo.password)}</b>. Заказы — из этого браузера, каталог — из data/catalog.json и черновика правок.</p>`}
      <a class="link small" href="${ROOT}index.html">← На сайт</a></form></div>`;
    $("#lg").focus();
    $("#lf").onsubmit = async (e) => { e.preventDefault(); try { const r = await DS.login($("#lg").value.trim(), $("#pw").value); ss.set("tmvo_admin", r.token); main(); } catch (er) { loginView(er.message); } };
  }

  const st = { tab: ss.get("tmvo_admin_tab") || "orders", status: "all", q: "", open: null, edit: null, pq: "", pcat: "", pf: "" };
  let ORDERS = [], CALLS = [];
  async function load() { [ORDERS, CALLS] = await Promise.all([DS.orders(), DS.callbacks()]); }
  async function main() { try { await load(); } catch (e) { ss.del("tmvo_admin"); return loginView(e.message); } render(); }
  const TABS = [["orders", "Заказы"], ["calls", "Заявки"], ["products", "Товары"], ["cats", "Разделы"], ["promos", "Акции"], ["data", "Данные"]];
  function shell(inner) {
    const newCalls = CALLS.filter((c) => c.status === "new").length;
    const badge = { orders: `<span>${ORDERS.length}</span>`, calls: newCalls ? `<span class="hot">${newCalls}</span>` : `<span>${CALLS.length}</span>`, products: `<span>${C.products.length}</span>`, cats: `<span>${C.categories.length}</span>`, promos: `<span>${withCatalog(() => PR.livePromos().length)}</span>`, data: isDraft() ? `<span class="hot">черновик</span>` : "" };
    return `<header class="adm-top"><div class="adm-top-in"><a href="${ROOT}index.html" class="adm-home" title="Открыть сайт"><img src="${ROOT}img/logo.svg" alt="" class="adm-logo-s"></a><nav>
      ${TABS.map(([k, t]) => `<button class="${st.tab === k ? "on" : ""}" data-tab="${k}">${t} ${badge[k] || ""}</button>`).join("")}</nav>
      <span class="adm-mode">${API_MODE ? "Рабочий режим" : "Демо: данные этого браузера"}</span>
      <a class="link" href="${ROOT}index.html" target="_blank" rel="noopener">Открыть сайт ↗</a><button class="link" id="refresh">Обновить</button><button class="link" id="logout">Выйти</button></div></header><main class="adm-main">${inner}</main>`;
  }
  function render() {
    ss.set("tmvo_admin_tab", st.tab);
    const views = { orders: ordersView, calls: callsView, products: productsView, cats: catsView, promos: promosView, data: dataView };
    app.innerHTML = shell(views[st.tab]());
    $$("[data-tab]").forEach((b) => (b.onclick = () => { st.tab = b.dataset.tab; st.open = null; st.edit = null; render(); window.scrollTo(0, 0); }));
    $("#logout").onclick = () => { ss.del("tmvo_admin"); loginView(); };
    $("#refresh").onclick = async () => { await load(); render(); };
    ({ orders: bindOrders, calls: bindCalls, products: bindProducts, cats: bindCats, promos: bindPromos, data: bindData })[st.tab]();
  }

  /* =============================== ЗАКАЗЫ =============================== */
  function ordersView() {
    const q = st.q.replace(/\D/g, "") || st.q.toLowerCase();
    const list = ORDERS.filter((o) => (st.status === "all" || o.status === st.status) &&
      (!st.q || String(o.number).includes(st.q) || String(o.customer.phone).replace(/\D/g, "").includes(q) || (o.customer.name || "").toLowerCase().includes(st.q.toLowerCase())));
    const cnt = (s) => ORDERS.filter((o) => o.status === s).length;
    const tabs = `<div class="adm-tabs"><button data-st="all" class="${st.status === "all" ? "on" : ""}">Все <span>${ORDERS.length}</span></button>${STATUS.map(([k, t]) => `<button data-st="${k}" class="${st.status === k ? "on" : ""}">${t} <span>${cnt(k)}</span></button>`).join("")}</div>`;
    if (!ORDERS.length) return `<div class="adm-empty"><h2>Заказов пока нет</h2><p>Оформите заказ на сайте в этом же браузере — быстрый или полный — и он появится здесь.</p>
      <p><a class="btn" href="${ROOT}katalog/index.html" target="_blank">Открыть каталог</a> <button class="btn ghost" id="demoFill">Добавить 3 примера заказов</button></p></div>`;
    return `<div class="adm-head"><h1>Заказы</h1><input class="inp adm-search" id="q" type="search" placeholder="Номер, телефон или имя" value="${esc(st.q)}" aria-label="Поиск заказа"></div>${tabs}
      <div class="adm-split ${st.open ? "has-open" : ""}"><div class="adm-table-wrap"><table class="adm-table"><thead><tr><th>№</th><th>Тип</th><th>Создан</th><th>Клиент</th><th>Товары</th><th class="r">Сумма</th><th>Статус</th></tr></thead><tbody>
      ${list.map((o) => `<tr data-open="${o.id}" class="${st.open === o.id ? "sel" : ""} ${o.status === "new" ? "is-new" : ""}" tabindex="0"><td><b>${o.number}</b>${o.example ? ' <span class="ex">пример</span>' : ""}</td><td><span class="typ ${o.type}">${o.type === "quick" ? "Быстрый" : "Полный"}</span></td><td>${dt(o.created_at)}</td>
        <td>${esc(o.customer.name || "—")}<br><span class="muted">${phone(o.customer.phone)}</span></td><td>${esc(o.items[0] ? o.items[0].name + " " + o.items[0].width + "×" + o.items[0].length : "")}${o.items.length > 1 ? ` <span class="muted">+${o.items.length - 1}</span>` : ""}${o.promo_code ? ` <span class="ex">${esc(o.promo_code)}</span>` : ""}</td>
        <td class="r">${rub(o.total)}</td><td><span class="sb s-${o.status}">${SNAME[o.status] || o.status}</span></td></tr>`).join("") || `<tr><td colspan="7" class="muted">Ничего не найдено</td></tr>`}
      </tbody></table></div>${st.open ? orderCard(ORDERS.find((o) => o.id === st.open)) : ""}</div>`;
  }
  function orderCard(o) {
    if (!o) return "";
    const d = o.delivery || {};
    const addr = d.method === "courier" ? `${d.city || ""}, ${d.street || ""}${d.flat ? ", кв./офис " + d.flat : ""}${d.floor ? ", этаж " + d.floor : ""}${d.lift ? ", есть грузовой лифт" : ""}` : d.method ? DEL[d.method] : "не указано — уточнить по телефону";
    const c = o.consents || {};
    return `<aside class="adm-card" aria-label="Заказ ${o.number}"><div class="adm-card-h"><h2>Заказ № ${o.number}</h2><button class="link" id="close">Закрыть</button></div>
      <div class="adm-sec"><h4>Клиент</h4><p class="big"><a href="tel:${esc(o.customer.phone)}">${phone(o.customer.phone)}</a></p><p>${esc(o.customer.name || "Имя не указано")}${o.customer.email ? `<br>${esc(o.customer.email)}` : ""}</p>${o.customer.comment ? `<p class="note">${esc(o.customer.comment)}</p>` : ""}</div>
      <div class="adm-sec"><h4>Товары</h4>${o.items.map((x) => { const p = byId(x.product_id); return `<div class="row"><span>${esc(p ? fullName(p) : x.name)}, ${x.width}×${x.length} × ${x.qty}${x.discount_pct ? ` <span class="ex">−${x.discount_pct}%</span>` : ""}${(x.gifts || []).length ? `<br><span class="gift-line">Подарок: ${esc(x.gifts.join(", "))}</span>` : ""}</span><b>${rub(x.sum)}</b></div>`; }).join("")}
        ${o.code_discount ? `<div class="row"><span>Промокод ${esc(o.promo_code)}</span><b>−${rub(o.code_discount)}</b></div>` : ""}<div class="row t"><span>Итого</span><b>${rub(o.total)}</b></div></div>
      <div class="adm-sec"><h4>Получение и оплата</h4><p>${esc(addr)}</p><p>${esc(PAY[(o.payment || {}).method] || "Способ оплаты не выбран")} — ${(o.payment || {}).status === "paid" ? "оплачено" : "не оплачено"}</p></div>
      <div class="adm-sec"><h4>Обработка</h4><label class="lbl" for="ost">Статус</label><select class="inp" id="ost">${STATUS.map(([k, t]) => `<option value="${k}" ${o.status === k ? "selected" : ""}>${t}</option>`).join("")}</select>
        <label class="lbl" for="ocm">Комментарий менеджера</label><textarea class="inp" id="ocm" rows="3" placeholder="Например: доставка в субботу после 12:00">${esc(o.manager_comment || "")}</textarea>
        <button class="btn" id="osave">Сохранить</button> <span class="muted small" id="osaved"></span></div>
      <div class="adm-sec"><h4>Согласия</h4><p class="small">Политика ПДн: ${c.privacy ? "да" : "нет"}, согласие на обработку: ${c.personal_data ? "да" : "нет"}${c.versions ? ` (версии ${esc(c.versions.privacy || "—")} / ${esc(c.versions.consent || "—")})` : ""}<br>Форма: ${esc(c.form || o.type)}, ${dt(c.at || o.created_at)}${o.offer_accepted ? "<br>Оферта принята" : ""}${o.marketing ? ", согласие на рассылку" : ""}</p></div>
      <div class="adm-sec"><h4>История</h4>${(o.history || []).slice().reverse().map((h) => `<div class="hist"><span>${dt(h.at)}</span>${esc(h.text)}</div>`).join("")}</div></aside>`;
  }
  function bindOrders() {
    const q = $("#q"); if (q) q.oninput = (e) => { st.q = e.target.value; const pos = e.target.selectionStart; render(); const n = $("#q"); n.focus(); n.setSelectionRange(pos, pos); };
    $$("[data-st]").forEach((b) => (b.onclick = () => { st.status = b.dataset.st; render(); }));
    $$("[data-open]").forEach((r) => { r.onclick = () => { st.open = r.dataset.open; render(); }; r.onkeydown = (e) => { if (e.key === "Enter") { st.open = r.dataset.open; render(); } }; });
    const cl = $("#close"); if (cl) cl.onclick = () => { st.open = null; render(); };
    const sv = $("#osave"); if (sv) sv.onclick = async () => {
      const o = ORDERS.find((x) => x.id === st.open); const ns = $("#ost").value, cm = $("#ocm").value.trim();
      o.history = o.history || [];
      if (ns !== o.status) o.history.push({ at: new Date().toISOString(), text: `Статус: ${SNAME[o.status]} → ${SNAME[ns]} (менеджер)` });
      if (cm !== (o.manager_comment || "")) o.history.push({ at: new Date().toISOString(), text: "Комментарий менеджера изменён" });
      o.status = ns; o.manager_comment = cm; o.updated_at = new Date().toISOString();
      await DS.saveOrder(o); render(); const m = $("#osaved"); if (m) m.textContent = "Сохранено";
    };
    const df = $("#demoFill"); if (df) df.onclick = async () => { await demoFill(); await load(); render(); };
  }
  function callsView() {
    if (!CALLS.length) return `<div class="adm-empty"><h2>Заявок на звонок пока нет</h2><p>Отправьте форму «Заказать звонок» или «Остались вопросы» на сайте в этом же браузере.</p></div>`;
    return `<div class="adm-head"><h1>Заявки на звонок</h1></div><div class="adm-table-wrap"><table class="adm-table"><thead><tr><th>Создана</th><th>Телефон</th><th>Имя</th><th>Тема</th><th>Статус</th></tr></thead><tbody>
      ${CALLS.map((c) => `<tr class="${c.status === "new" ? "is-new" : ""}"><td>${dt(c.created_at)}</td><td><a href="tel:${esc(c.phone)}">${phone(c.phone)}</a></td><td>${esc(c.name || "—")}</td><td>${esc(c.topic || "Звонок")}</td>
        <td><label class="cbx"><input type="checkbox" data-done="${c.id}" ${c.status === "done" ? "checked" : ""}> Обработана</label></td></tr>`).join("")}</tbody></table></div>`;
  }
  function bindCalls() { $$("[data-done]").forEach((i) => (i.onchange = async () => { const c = CALLS.find((x) => x.id === i.dataset.done); c.status = i.checked ? "done" : "new"; await DS.saveCallback(c); render(); })); }
  async function demoFill() {
    const pick = (id, w, l, q) => { const p = byId(id) || C.products[0]; const v = p.variants.find((x) => x.w === w && x.l === l) || p.variants[0]; return { product_id: p.id, name: p.name, category: p.category, width: v.w, length: v.l, qty: q, price: v.price, sum: v.price * q, gifts: [] }; };
    const mk = (n, type, status, name, ph, items, delivery, pay, minsAgo) => {
      const at = new Date(Date.now() - minsAgo * 60000).toISOString(); const total = items.reduce((s, x) => s + x.sum, 0);
      return { id: "ex" + n, number: n, token: "example", type, status, example: true, created_at: at, updated_at: at, customer: { phone: ph, name, email: "", comment: "" }, items, total,
        delivery, payment: { method: pay, status: "not_paid" }, consents: { privacy: true, personal_data: true, versions: { privacy: "1.0", consent: "1.0" }, at, form: type }, offer_accepted: type === "full", marketing: false,
        history: [{ at, text: type === "quick" ? "Быстрый заказ с сайта (пример)" : "Заказ подтверждён покупателем (пример)" }] };
    };
    const all = ls.get("tmvo_mock_orders", {});
    [mk(901, "quick", "new", "", "+79001234567", [pick("matras-germes", 160, 200, 1)], null, null, 12),
     mk(902, "full", "new", "Ольга", "+79265551234", [pick("matras-briz", 140, 200, 1), pick("krovat-lira", 140, 200, 1)], { method: "courier", city: "Москва", street: "Ленинский проспект, д 45", floor: "5", flat: "42", lift: true }, "cash", 55),
     mk(903, "full", "draft", "", "+79157002020", [pick("matras-zevs", 180, 200, 1)], null, null, 130)].forEach((o) => (all[o.id] = o));
    ls.set("tmvo_mock_orders", all);
  }

  /* =============================== ТОВАРЫ =============================== */
  function productsView() {
    if (st.edit) return productEditor();
    const q = st.pq.toLowerCase();
    const list = C.products.filter((p) => (!st.pcat || p.category === st.pcat) && (!q || (fullName(p) + " " + p.id).toLowerCase().includes(q)) &&
      (!st.pf || (st.pf === "noimg" ? !imgs(p).length : st.pf === "img" ? imgs(p).length : st.pf === "ex" ? p.example : st.pf === "off" ? p.active === false : st.pf === "promo" ? withCatalog(() => PR.promoActive(p) || PR.giftsFor(p).length) : true)));
    return `<div class="adm-head"><h1>Товары</h1><button class="btn" id="pnew">+ Добавить товар</button></div>
      <div class="adm-filters"><input class="inp adm-search" id="pq" type="search" placeholder="Название или адрес" value="${esc(st.pq)}">
        <select class="inp" id="pcat"><option value="">Все разделы</option>${C.categories.map((c) => `<option value="${c.id}" ${st.pcat === c.id ? "selected" : ""}>${esc(c.name)} (${C.products.filter((p) => p.category === c.id).length})</option>`).join("")}</select>
        <select class="inp" id="pf">${[["", "Все товары"], ["img", "С фото"], ["noimg", "Без фото"], ["promo", "Со скидкой или подарком"], ["ex", "Примеры"], ["off", "Скрытые"]].map(([k, t]) => `<option value="${k}" ${st.pf === k ? "selected" : ""}>${t}</option>`).join("")}</select>
        <span class="muted">${list.length} из ${C.products.length}</span></div>
      <div class="adm-table-wrap"><table class="adm-table"><thead><tr><th></th><th>Название</th><th>Раздел</th><th class="r">Цена от</th><th>Размеров</th><th>Фото</th><th>Акция</th><th>На сайте</th></tr></thead><tbody>
      ${list.map((p) => { const pr = withCatalog(() => PR.priceOf(p, p.min_price)); const g = withCatalog(() => PR.giftsFor(p)); const c = catById(p.category);
        return `<tr data-pedit="${esc(p.id)}" tabindex="0" class="${p.active === false ? "off" : ""}"><td class="th">${imgs(p)[0] ? `<img src="${src(imgs(p)[0])}" alt="">` : '<span class="noimg-s"></span>'}</td>
        <td><b>${esc(fullName(p))}</b>${p.example ? ' <span class="ex">пример</span>' : ""}<br><span class="muted small">${esc(p.id)}</span></td><td>${esc(c ? c.name : p.category)}</td>
        <td class="r">${rub(p.min_price)}${pr.pct ? `<br><span class="pct-s">−${pr.pct}% → ${rub(pr.price)}</span>` : ""}</td><td>${p.variants.length}</td><td>${imgs(p).length}/${MAX_IMG}</td>
        <td>${pr.pct ? `<span class="pct-s">−${pr.pct}%</span> ` : ""}${g.length ? '<span class="gift-s">подарок</span>' : ""}</td><td>${p.active === false ? '<span class="sb s-canceled">скрыт</span>' : '<span class="sb s-done">да</span>'}</td></tr>`; }).join("") || `<tr><td colspan="8" class="muted">Ничего не найдено</td></tr>`}
      </tbody></table></div>`;
  }
  function bindProducts() {
    if (st.edit) return bindProductEditor();
    const pq = $("#pq"); pq.oninput = (e) => { st.pq = e.target.value; const pos = e.target.selectionStart; render(); const n = $("#pq"); n.focus(); n.setSelectionRange(pos, pos); };
    $("#pcat").onchange = (e) => { st.pcat = e.target.value; render(); };
    $("#pf").onchange = (e) => { st.pf = e.target.value; render(); };
    $("#pnew").onclick = () => { st.edit = { isNew: true, p: { id: "", name: "", category: st.pcat || C.categories[0].id, word: (catById(st.pcat || C.categories[0].id) || {}).word || "", variants: [{ w: 160, l: 200, price: 10000 }], specs: {}, images: [], active: true, source: "admin" } }; render(); };
    $$("[data-pedit]").forEach((r) => { const open = () => { st.edit = { isNew: false, p: clone(byId(r.dataset.pedit)) }; render(); window.scrollTo(0, 0); }; r.onclick = open; r.onkeydown = (e) => { if (e.key === "Enter") open(); }; });
  }
  function fieldInput(f, v, i) {
    const id = "sp" + i, val = v == null ? "" : v;
    if (f.type === "yesno") return `<select class="inp" id="${id}" data-spec="${esc(f.k)}"><option value="">—</option>${["Да", "Нет"].map((o) => `<option ${val === o ? "selected" : ""}>${o}</option>`).join("")}</select>`;
    if (f.type === "select" || f.type === "hard") return `<input class="inp" id="${id}" data-spec="${esc(f.k)}" list="dl${i}" value="${esc(val)}"><datalist id="dl${i}">${(f.options || []).map((o) => `<option value="${esc(o)}">`).join("")}</datalist>`;
    return `<input class="inp" id="${id}" data-spec="${esc(f.k)}" value="${esc(val)}"${f.type === "number" || f.type === "years" ? ' inputmode="decimal"' : ""}>`;
  }
  function productEditor() {
    const { p, isNew } = st.edit; const c = catById(p.category) || { fields: [] };
    const fields = c.fields || []; const known = new Set(fields.map((f) => f.k));
    const extra = Object.keys(p.specs || {}).filter((k) => !known.has(k));
    const groups = [...new Set(fields.map((f) => f.group || "Характеристики"))];
    const promos = withCatalog(() => C.promos.filter((x) => PR.applies(x, p) || (x.type === "gift" && PR.giftsFor(p).some((g) => g.id === x.id))));
    let i = 0;
    return `<div class="adm-head"><div><button class="link" id="pback">← Все товары</button><h1>${isNew ? "Новый товар" : esc(fullName(p))}</h1></div>
      <div class="adm-actions">${isNew ? "" : `<a class="btn ghost sm" href="${prodUrl(p)}" target="_blank">Открыть на сайте ↗</a><button class="btn ghost sm" id="pdup">Дублировать</button><button class="btn ghost sm danger" id="pdel">Удалить</button>`}<button class="btn" id="psave">Сохранить</button></div></div>
      <div class="err-msg" id="perr" role="alert"></div>
      <div class="ed-grid"><div class="ed-main">
        <section class="ed-box"><h3>Основное</h3><div class="ed-row3">
          <div class="field"><label for="pname">Название <span class="req">*</span></label><input class="inp" id="pname" value="${esc(p.name)}" placeholder="Например: Зевс"></div>
          <div class="field"><label for="pword">Слово перед названием</label><input class="inp" id="pword" value="${esc(p.word || "")}" placeholder="Матрас, Кровать…"></div>
          <div class="field"><label for="pcat2">Раздел</label><select class="inp" id="pcat2">${C.categories.map((x) => `<option value="${x.id}" ${x.id === p.category ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select></div></div>
          <div class="ed-row3"><div class="field"><label for="pid">Адрес страницы (латиница)</label><input class="inp" id="pid" value="${esc(p.id)}" ${isNew ? "" : "readonly"} placeholder="заполнится по названию"><small class="muted">${isNew ? "Создаётся по названию. После сохранения не меняется." : "Не меняется, чтобы не ломать ссылки."}</small></div>
          ${p.category === "sale" ? `<div class="field"><label for="preg">Обычная цена (зачёркнутая)</label><input class="inp" id="preg" inputmode="numeric" value="${esc(p.regular_price || "")}"></div>` : "<div></div>"}
          <div class="field ed-checks"><label class="cbx"><input type="checkbox" id="pact" ${p.active !== false ? "checked" : ""}> Показывать на сайте</label><label class="cbx"><input type="checkbox" id="pex" ${p.example ? "checked" : ""}> Пример (тестовый товар)</label></div></div></section>
        <section class="ed-box"><h3>Фото <span class="muted">${imgs(p).length} из ${MAX_IMG}</span></h3><p class="muted small">Первое фото — главное (в карточке). Стрелками меняйте порядок. Фото уменьшаются до 1400 px и сохраняются в черновик; при публикации загружаются в img/products/.</p>
          <div class="ed-imgs" id="pimgs">${imgs(p).map((s, k) => `<figure class="${k ? "" : "main"}"><img src="${src(s)}" alt=""><figcaption>${k ? k + 1 : "Главное"}</figcaption><div class="ed-img-act"><button type="button" data-imv="${k}" data-d="-1" aria-label="Левее" ${k ? "" : "disabled"}>←</button><button type="button" data-imv="${k}" data-d="1" aria-label="Правее" ${k < imgs(p).length - 1 ? "" : "disabled"}>→</button><button type="button" data-imdel="${k}" aria-label="Удалить">✕</button></div></figure>`).join("")}
          ${imgs(p).length < MAX_IMG ? `<label class="ed-add"><input type="file" id="pfile" accept="image/*" multiple hidden><span>+ Добавить фото</span><small>JPG, PNG, WebP, SVG</small></label>` : ""}</div>
          ${imgs(p).length < MAX_IMG ? `<div class="ed-url"><input class="inp" id="purl" placeholder="или ссылка / путь: img/products/имя.jpg"><button class="btn ghost sm" id="purlAdd" type="button">Добавить</button></div>` : ""}</section>
        <section class="ed-box"><h3>Размеры и цены <span class="muted">${p.variants.length}</span></h3>
          <table class="ed-var"><thead><tr><th>Ширина, см</th><th>Длина, см</th><th>Цена, ₽</th><th></th></tr></thead><tbody id="pvars">${p.variants.map((v, k) => `<tr><td><input class="inp" data-v="w" data-k="${k}" inputmode="numeric" value="${v.w}"></td><td><input class="inp" data-v="l" data-k="${k}" inputmode="numeric" value="${v.l}"></td><td><input class="inp" data-v="price" data-k="${k}" inputmode="numeric" value="${v.price}"></td><td><button type="button" class="link" data-vdel="${k}">удалить</button></td></tr>`).join("")}</tbody></table>
          <div class="ed-var-act"><button type="button" class="btn ghost sm" id="vadd">+ Размер</button><span class="muted small">Изменить все цены на</span><input class="inp sm" id="vpct" inputmode="numeric" placeholder="%"><button type="button" class="btn ghost sm" id="vpctGo">Применить</button><span class="muted small">например 5 или −10</span></div></section>
        <section class="ed-box"><h3>Характеристики раздела «${esc(c.name || "")}»</h3><p class="muted small">Набор полей задаётся в «Разделы» → ${esc(c.name || "")}. Пустые поля на сайте не показываются. Подсказки — варианты из настроек поля.</p>
          ${groups.map((g) => `<h4 class="ed-g">${esc(g)}</h4><div class="ed-specs">${fields.filter((f) => (f.group || "Характеристики") === g).map((f) => `<div class="field"><label for="sp${i}">${esc(f.label || f.k)}${f.unit ? `, ${esc(f.unit)}` : ""}${f.page === false ? ' <span class="muted">(служебное)</span>' : ""}</label>${fieldInput(f, (p.specs || {})[f.k], i++)}</div>`).join("")}</div>`).join("")}
          <h4 class="ed-g">Другие характеристики</h4><div id="pextra">${extra.map((k) => `<div class="ed-kv"><input class="inp" data-xk value="${esc(k)}"><input class="inp" data-xv value="${esc(p.specs[k])}"><button type="button" class="link" data-xdel>✕</button></div>`).join("")}</div>
          <button type="button" class="btn ghost sm" id="xadd">+ Характеристика</button></section>
      </div><aside class="ed-side">
        <section class="ed-box"><h3>Как выглядит</h3><div class="ed-prev">${imgs(p)[0] ? `<img src="${src(imgs(p)[0])}" alt="">` : '<div class="noimg">нет фото</div>'}<b>${esc(fullName(p) || "Без названия")}</b><span>от ${rub(Math.min(...p.variants.map((v) => v.price || 0)))}</span></div></section>
        <section class="ed-box"><h3>Акции</h3>${promos.length ? promos.map((x) => `<div class="ed-pr"><span class="sb ${PR.promoState(x) === "live" ? "s-done" : "s-draft"}">${{ live: "идёт", planned: "скоро", ended: "завершена", off: "выкл." }[PR.promoState(x)]}</span> ${esc(x.title)}</div>`).join("") : '<p class="muted small">Нет акций для этого товара.</p>'}
          <button type="button" class="link small" data-tab="promos">Открыть «Акции»</button></section>
        ${p.price_note ? `<section class="ed-box"><h3>Заметка</h3><p class="small">${esc(p.price_note)}</p></section>` : ""}</aside></div>`;
  }
  function readProductForm() {
    const { p } = st.edit;
    p.name = $("#pname").value.trim(); p.word = $("#pword").value.trim(); p.active = $("#pact").checked; p.example = $("#pex").checked || undefined;
    if (st.edit.isNew) p.id = slug($("#pid").value.trim());
    const reg = $("#preg"); if (reg) p.regular_price = +reg.value || null;
    $$("[data-v]").forEach((el) => { const v = p.variants[+el.dataset.k]; if (v) v[el.dataset.v] = parseInt(String(el.value).replace(/\D/g, ""), 10) || 0; });
    const specs = {}; $$("[data-spec]").forEach((el) => { if (el.value.trim()) specs[el.dataset.spec] = el.value.trim(); });
    $$(".ed-kv").forEach((r) => { const k = $("[data-xk]", r).value.trim(), v = $("[data-xv]", r).value.trim(); if (k && v) specs[k] = v; });
    p.specs = specs;
  }
  async function resizeImage(file) {
    const data = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
    if (file.type === "image/svg+xml") return data;
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = data; });
    const k = Math.min(1, 1400 / Math.max(img.width, img.height)); const cv = document.createElement("canvas");
    cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
    const x = cv.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, cv.width, cv.height); x.drawImage(img, 0, 0, cv.width, cv.height);
    return cv.toDataURL("image/jpeg", 0.84);
  }
  function bindProductEditor() {
    const E = st.edit; const p = E.p;
    const rerender = () => { const y = window.scrollY; readProductForm(); render(); window.scrollTo(0, y); };
    $("#pback").onclick = () => { st.edit = null; render(); };
    $$("[data-tab]", $(".ed-side")).forEach((b) => (b.onclick = () => { st.tab = "promos"; st.edit = null; render(); }));
    $("#pname").oninput = () => { if (E.isNew) $("#pid").placeholder = slug(($("#pword").value ? $("#pword").value + " " : "") + $("#pname").value) || "заполнится по названию"; };
    $("#pcat2").onchange = (e) => { readProductForm(); p.category = e.target.value; const c = catById(p.category); if (E.isNew && c && c.word !== undefined) p.word = c.word; render(); };
    $$("[data-imv]").forEach((b) => (b.onclick = () => { readProductForm(); const k = +b.dataset.imv, d = +b.dataset.d; p.images = imgs(p).slice(); const t = p.images[k]; p.images[k] = p.images[k + d]; p.images[k + d] = t; render(); }));
    $$("[data-imdel]").forEach((b) => (b.onclick = () => { readProductForm(); p.images = imgs(p).filter((_, k) => k !== +b.dataset.imdel); render(); }));
    const pf = $("#pfile"); if (pf) pf.onchange = async () => { readProductForm(); p.images = imgs(p).slice(); for (const f of Array.from(pf.files).slice(0, MAX_IMG - p.images.length)) { try { p.images.push(await resizeImage(f)); } catch (e) { toast("Не удалось прочитать " + f.name); } } render(); };
    const pu = $("#purlAdd"); if (pu) pu.onclick = () => { const v = $("#purl").value.trim(); if (!v) return; readProductForm(); p.images = imgs(p).concat([v]).slice(0, MAX_IMG); render(); };
    $("#vadd").onclick = () => { readProductForm(); const last = p.variants[p.variants.length - 1] || { w: 160, l: 200, price: 10000 }; p.variants.push({ w: last.w, l: last.l, price: last.price }); rerender(); };
    $$("[data-vdel]").forEach((b) => (b.onclick = () => { readProductForm(); if (p.variants.length < 2) return toast("Нужен хотя бы один размер"); p.variants.splice(+b.dataset.vdel, 1); rerender(); }));
    $("#vpctGo").onclick = () => { const k = parseFloat(String($("#vpct").value).replace(",", ".").replace("−", "-")); if (!k) return; readProductForm(); p.variants.forEach((v) => (v.price = Math.round(v.price * (1 + k / 100) / 10) * 10)); rerender(); toast(`Цены изменены на ${k}%`); };
    $("#xadd").onclick = () => { const d = document.createElement("div"); d.className = "ed-kv"; d.innerHTML = '<input class="inp" data-xk placeholder="Название"><input class="inp" data-xv placeholder="Значение"><button type="button" class="link" data-xdel>✕</button>'; $("#pextra").appendChild(d); };
    $("#pextra").onclick = (e) => { if (e.target.closest("[data-xdel]")) e.target.closest(".ed-kv").remove(); };
    $("#psave").onclick = async () => {
      readProductForm(); const err = $("#perr");
      if (!p.name) return (err.textContent = "Укажите название");
      if (E.isNew && !p.id) p.id = slug((p.word ? p.word + " " : "") + p.name);
      if (!p.id) return (err.textContent = "Укажите адрес страницы");
      if (E.isNew && byId(p.id)) return (err.textContent = `Адрес «${p.id}» уже занят — измените название или адрес`);
      if (p.variants.some((v) => !v.w || !v.l || !v.price)) return (err.textContent = "Заполните ширину, длину и цену у всех размеров");
      const keys = p.variants.map((v) => v.w + "x" + v.l); if (new Set(keys).size !== keys.length) return (err.textContent = "Размеры повторяются");
      const c = catById(p.category);
      if (E.isNew) { p.path = (c ? c.url : "katalog/") + p.id + "/"; p.source = "admin"; C.products.push(p); }
      else { const i = C.products.findIndex((x) => x.id === p.id); C.products[i] = p; }
      if (!p.example) delete p.example;
      await saveCatalog(E.isNew ? "Товар добавлен" : "Товар сохранён");
      st.edit = { isNew: false, p: clone(byId(p.id)) }; render();
    };
    const del = $("#pdel"); if (del) del.onclick = async () => { if (!confirmBox(`Удалить «${fullName(p)}»? Можно вместо этого снять галочку «Показывать на сайте».`)) return; C.products = C.products.filter((x) => x.id !== p.id); C.promos.forEach((x) => (x.products = (x.products || []).filter((id) => id !== p.id))); await saveCatalog("Товар удалён"); st.edit = null; render(); };
    const dup = $("#pdup"); if (dup) dup.onclick = () => { readProductForm(); const n = clone(p); n.name = p.name + " (копия)"; n.id = ""; delete n.path; n.source = "admin"; st.edit = { isNew: true, p: n }; render(); };
  }

  /* =============================== РАЗДЕЛЫ =============================== */
  const FTYPES = [["text", "Текст"], ["number", "Число"], ["select", "Список"], ["yesno", "Да / Нет"], ["hard", "Жёсткость (со шкалой)"], ["years", "Срок, лет"]];
  function catsView() {
    if (st.edit && st.edit.kind === "cat") return catEditor();
    return `<div class="adm-head"><h1>Разделы каталога</h1><button class="btn" id="cnew">+ Добавить раздел</button></div>
      <p class="muted">Первый уровень меню — группы. Внутри группы — разделы. У каждого раздела свой набор характеристик и фильтров.</p>
      ${C.groups.map((g) => `<section class="ed-box"><div class="grp-h"><input class="inp grp-name" data-gname="${esc(g.id)}" value="${esc(g.name)}" aria-label="Название группы"><span class="muted small">группа меню · ${C.categories.filter((c) => c.group === g.id).length} разд.</span><button class="btn ghost sm" data-gsave="${esc(g.id)}">Переименовать</button></div>
        <div class="adm-table-wrap"><table class="adm-table"><thead><tr><th>Раздел</th><th>Адрес</th><th>Товаров</th><th>Полей</th><th>Фильтры</th><th>В меню</th><th>Порядок</th></tr></thead><tbody>
        ${C.categories.filter((c) => c.group === g.id).sort((a, b) => (a.sort || 99) - (b.sort || 99)).map((c) => `<tr data-cedit="${esc(c.id)}" tabindex="0"><td><b>${esc(c.name)}</b>${c.source === "admin" ? ' <span class="ex">новый</span>' : ""}</td><td class="muted small">${esc(c.url)}</td><td>${C.products.filter((p) => p.category === c.id).length}</td><td>${(c.fields || []).length}</td><td class="small">${(c.filters || []).map((k) => (k === "hard" ? "жёсткость" : ((c.fields || []).find((f) => f.k === k) || { label: k }).label || k)).join(", ") || "—"}</td><td>${c.menu === false ? "нет" : "да"}</td><td>${c.sort || "—"}</td></tr>`).join("")}</tbody></table></div></section>`).join("")}
      <section class="ed-box"><h3>Новая группа меню</h3><div class="ed-url"><input class="inp" id="gnew" placeholder="Например: Подушки"><button class="btn ghost sm" id="gadd">Добавить группу</button></div></section>`;
  }
  function catEditor() {
    const { c, isNew } = st.edit;
    const filterable = (c.fields || []).filter((f) => ["select", "yesno"].includes(f.type));
    const hasHard = (c.fields || []).some((f) => f.type === "hard");
    return `<div class="adm-head"><div><button class="link" id="cback">← Все разделы</button><h1>${isNew ? "Новый раздел" : esc(c.name)}</h1></div>
      <div class="adm-actions">${isNew ? "" : `<a class="btn ghost sm" href="${catUrl(c)}" target="_blank">Открыть на сайте ↗</a><button class="btn ghost sm danger" id="cdel">Удалить</button>`}<button class="btn" id="csave">Сохранить</button></div></div><div class="err-msg" id="cerr"></div>
      <section class="ed-box"><h3>Основное</h3><div class="ed-row3">
        <div class="field"><label for="cname">Название в меню <span class="req">*</span></label><input class="inp" id="cname" value="${esc(c.name)}"></div>
        <div class="field"><label for="ctitle">Заголовок страницы</label><input class="inp" id="ctitle" value="${esc(c.title || "")}" placeholder="как название"></div>
        <div class="field"><label for="cgroup">Группа меню</label><select class="inp" id="cgroup">${C.groups.map((g) => `<option value="${g.id}" ${g.id === c.group ? "selected" : ""}>${esc(g.name)}</option>`).join("")}</select></div></div>
        <div class="field"><label for="cintro">Описание под заголовком</label><textarea class="inp" id="cintro" rows="2">${esc(c.intro || "")}</textarea></div>
        <div class="ed-row3"><div class="field"><label for="cword">Слово перед названием товара</label><input class="inp" id="cword" value="${esc(c.word || "")}" placeholder="Матрас, Кровать…"></div>
        <div class="field"><label for="csort">Порядок в группе</label><input class="inp" id="csort" inputmode="numeric" value="${esc(c.sort || "")}"></div>
        <div class="field"><label for="cid">Адрес (латиница)</label><input class="inp" id="cid" value="${esc(c.id)}" ${isNew ? "" : "readonly"} placeholder="по названию"></div></div>
        <label class="cbx"><input type="checkbox" id="cmenu" ${c.menu !== false ? "checked" : ""}> Показывать в меню каталога</label></section>
      <section class="ed-box"><h3>Фильтры на странице раздела</h3><p class="muted small">Ширина и цена есть всегда. Отметьте, по каким характеристикам фильтровать (типы «Список» и «Да / Нет»).</p>
        <div class="ed-checks wrap">${hasHard ? `<label class="cbx"><input type="checkbox" data-filter="hard" ${(c.filters || []).includes("hard") ? "checked" : ""}> Жёсткость</label>` : ""}${filterable.map((f) => `<label class="cbx"><input type="checkbox" data-filter="${esc(f.k)}" ${(c.filters || []).includes(f.k) ? "checked" : ""}> ${esc(f.label || f.k)}</label>`).join("") || (hasHard ? "" : '<span class="muted small">Добавьте поля типа «Список» или «Да / Нет».</span>')}</div></section>
      <section class="ed-box"><h3>Характеристики товаров <span class="muted">${(c.fields || []).length}</span></h3><p class="muted small">Эти поля появятся в карточке редактирования каждого товара раздела и в блоке «Характеристики» на сайте. «Ключ» — как поле хранится в базе (для товаров из Excel — заголовок колонки листа «Х_…»); при изменении ключа значения у товаров переносятся.</p>
        <div class="adm-table-wrap"><table class="adm-table ed-fields"><thead><tr><th>Подпись на сайте</th><th>Ключ</th><th>Блок</th><th>Тип</th><th>Варианты (через ;)</th><th>Ед.</th><th title="Чип в карточке">Карт.</th><th title="Показывать на странице товара">Стр.</th><th></th></tr></thead><tbody id="cfields">
        ${(c.fields || []).map((f, k) => `<tr data-fi="${k}" data-orig="${esc(f.k)}"><td><input class="inp" data-ff="label" value="${esc(f.label || "")}"></td><td><input class="inp" data-ff="k" value="${esc(f.k)}"></td><td><input class="inp" data-ff="group" value="${esc(f.group || "")}"></td>
          <td><select class="inp" data-ff="type">${FTYPES.map(([t, n]) => `<option value="${t}" ${f.type === t ? "selected" : ""}>${n}</option>`).join("")}</select></td><td><input class="inp" data-ff="options" value="${esc((f.options || []).join("; "))}"></td><td><input class="inp xs" data-ff="unit" value="${esc(f.unit || "")}"></td>
          <td><input type="checkbox" data-ff="card" ${f.card ? "checked" : ""}></td><td><input type="checkbox" data-ff="page" ${f.page !== false ? "checked" : ""}></td>
          <td class="nowrap"><button type="button" class="link" data-fmv="${k}" data-d="-1" aria-label="Выше">↑</button> <button type="button" class="link" data-fmv="${k}" data-d="1" aria-label="Ниже">↓</button> <button type="button" class="link" data-fdel="${k}" aria-label="Удалить">✕</button></td></tr>`).join("")}</tbody></table></div>
        <button type="button" class="btn ghost sm" id="fadd">+ Поле</button>${isNew ? ` <select class="inp sm" id="fcopy"><option value="">Скопировать поля из раздела…</option>${C.categories.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join("")}</select>` : ""}</section>`;
  }
  function readCatForm() {
    const { c } = st.edit;
    c.name = $("#cname").value.trim(); c.title = $("#ctitle").value.trim() || undefined; c.group = $("#cgroup").value; c.intro = $("#cintro").value.trim();
    c.word = $("#cword").value.trim(); c.sort = +$("#csort").value || undefined; c.menu = $("#cmenu").checked ? undefined : false;
    if (st.edit.isNew) c.id = slug($("#cid").value.trim());
    c.fields = $$("#cfields tr").map((r) => {
      const g = (n) => $(`[data-ff=${n}]`, r); const f = { k: g("k").value.trim(), label: g("label").value.trim(), group: g("group").value.trim(), type: g("type").value };
      const opts = g("options").value.split(";").map((x) => x.trim()).filter(Boolean); if (opts.length) f.options = opts;
      if (g("unit").value.trim()) f.unit = g("unit").value.trim(); if (g("card").checked) f.card = true; if (!g("page").checked) f.page = false;
      const old = (st.edit.origFields || [])[+r.dataset.fi]; if (old && old.prefix) f.prefix = old.prefix;
      f._orig = r.dataset.orig; return f;
    }).filter((f) => f.k);
    c.filters = $$("[data-filter]:checked").map((x) => x.dataset.filter);
  }
  function bindCats() {
    if (st.edit && st.edit.kind === "cat") return bindCatEditor();
    $("#cnew").onclick = () => { st.edit = { kind: "cat", isNew: true, c: { id: "", name: "", group: C.groups[0].id, url: "", fields: [], filters: [], source: "admin" }, origFields: [] }; render(); };
    $$("[data-cedit]").forEach((r) => { const open = () => { const c = clone(catById(r.dataset.cedit)); st.edit = { kind: "cat", isNew: false, c, origFields: clone(c.fields || []) }; render(); window.scrollTo(0, 0); }; r.onclick = open; r.onkeydown = (e) => { if (e.key === "Enter") open(); }; });
    $$("[data-gsave]").forEach((b) => (b.onclick = async () => { const g = C.groups.find((x) => x.id === b.dataset.gsave); const v = $(`[data-gname="${b.dataset.gsave}"]`).value.trim(); if (!v) return; g.name = v; await saveCatalog("Группа переименована"); render(); }));
    $("#gadd").onclick = async () => { const v = $("#gnew").value.trim(); if (!v) return; const id = slug(v); if (C.groups.some((g) => g.id === id)) return toast("Такая группа уже есть"); C.groups.push({ id, name: v, url: "" }); await saveCatalog("Группа добавлена"); render(); };
  }
  function bindCatEditor() {
    const E = st.edit; const c = E.c;
    const rr = () => { const y = window.scrollY; readCatForm(); c.fields.forEach((f) => delete f._orig); render(); window.scrollTo(0, y); };
    $("#cback").onclick = () => { st.edit = null; render(); };
    $("#fadd").onclick = () => { readCatForm(); c.fields.push({ k: "Новое поле " + (c.fields.length + 1), label: "", group: (c.fields[c.fields.length - 1] || {}).group || "Характеристики", type: "text" }); E.origFields.push(null); render(); };
    $$("[data-fdel]").forEach((b) => (b.onclick = () => { readCatForm(); c.fields.splice(+b.dataset.fdel, 1); E.origFields.splice(+b.dataset.fdel, 1); c.fields.forEach((f) => delete f._orig); render(); }));
    $$("[data-fmv]").forEach((b) => (b.onclick = () => { readCatForm(); const k = +b.dataset.fmv, d = +b.dataset.d; if (!c.fields[k + d]) return; [c.fields[k], c.fields[k + d]] = [c.fields[k + d], c.fields[k]]; [E.origFields[k], E.origFields[k + d]] = [E.origFields[k + d], E.origFields[k]]; c.fields.forEach((f) => delete f._orig); render(); }));
    $$("[data-ff=type]").forEach((s) => (s.onchange = rr));
    const fc = $("#fcopy"); if (fc) fc.onchange = () => { const src_ = catById(fc.value); if (!src_) return; readCatForm(); c.fields = clone(src_.fields || []); c.filters = clone(src_.filters || []); E.origFields = c.fields.map(() => null); render(); };
    $("#csave").onclick = async () => {
      readCatForm(); const err = $("#cerr");
      if (!c.name) return (err.textContent = "Укажите название");
      if (E.isNew && !c.id) c.id = slug(c.name);
      if (E.isNew && catById(c.id)) return (err.textContent = `Адрес «${c.id}» уже занят`);
      const ks = c.fields.map((f) => f.k); if (new Set(ks).size !== ks.length) return (err.textContent = "Ключи полей повторяются");
      // перенос значений при переименовании ключа
      c.fields.forEach((f) => { if (f._orig && f._orig !== f.k) C.products.filter((p) => p.category === c.id).forEach((p) => { if (p.specs && f._orig in p.specs) { p.specs[f.k] = p.specs[f._orig]; delete p.specs[f._orig]; } }); delete f._orig; });
      if (E.isNew) { const g = C.groups.find((x) => x.id === c.group); c.url = ((g && g.url) || "katalog/").replace(/\/?$/, "/") + c.id + "/"; c.source = "admin"; C.categories.push(c); }
      else C.categories[C.categories.findIndex((x) => x.id === c.id)] = c;
      Object.keys(c).forEach((k) => c[k] === undefined && delete c[k]);
      await saveCatalog(E.isNew ? "Раздел добавлен" : "Раздел сохранён");
      const cc = clone(catById(c.id)); st.edit = { kind: "cat", isNew: false, c: cc, origFields: clone(cc.fields || []) }; render();
    };
    const del = $("#cdel"); if (del) del.onclick = async () => {
      const n = C.products.filter((p) => p.category === c.id).length;
      if (n) return toast(`В разделе ${n} товаров — сначала перенесите их в другой раздел`);
      if (!confirmBox(`Удалить раздел «${c.name}»?`)) return;
      C.categories = C.categories.filter((x) => x.id !== c.id); C.promos.forEach((x) => (x.categories = (x.categories || []).filter((id) => id !== c.id)));
      await saveCatalog("Раздел удалён"); st.edit = null; render();
    };
  }

  /* =============================== АКЦИИ =============================== */
  const PTYPES = [["percent", "Скидка %", "Цена товаров снижается на процент. Подходят товары из списка и/или целые разделы."], ["gift", "Подарок", "Цена не меняется; к товару добавляется подарок (можно ограничить шириной)."], ["code", "Промокод", "Покупатель вводит код в корзине — скидка на товары без другой скидки."]];
  const COLORS = [["red", "Красный"], ["blue", "Синий"], ["green", "Зелёный"], ["violet", "Фиолетовый"], ["dark", "Тёмный"]];
  const STATE = { live: ["идёт", "s-done"], planned: ["запланирована", "s-new"], ended: ["завершена", "s-draft"], off: ["выключена", "s-canceled"] };
  function promosView() {
    if (st.edit && st.edit.kind === "promo") return promoEditor();
    return `<div class="adm-head"><h1>Акции</h1><button class="btn" id="anew">+ Добавить акцию</button></div>
      <div class="how-promo adm-how">${PTYPES.map(([, t, d]) => `<div><b>${t}</b><span>${d}</span></div>`).join("")}<div><b>Правила</b><span>Скидки не суммируются — действует бо́льшая. К разделу «Распродажа» акции не применяются. Даты: с — по включительно.</span></div></div>
      <div class="adm-table-wrap"><table class="adm-table"><thead><tr><th>Акция</th><th>Вид</th><th>Размер</th><th>Период</th><th>Статус</th><th>Товаров</th><th>На сайте</th></tr></thead><tbody>
      ${C.promos.map((x) => { const s = PR.promoState(x); const n = withCatalog(() => C.products.filter((p) => (x.type === "gift" ? PR.giftsFor(p).some((g) => g.id === x.id) : PR.applies(x, p))).length);
        return `<tr data-aedit="${esc(x.id)}" tabindex="0"><td><span class="dot pc-${esc(x.color || "red")}"></span><b>${esc(x.title)}</b><br><span class="muted small">${esc(x.text || "")}</span></td><td>${(PTYPES.find((t) => t[0] === x.type) || [, x.type])[1]}</td>
        <td>${x.type === "gift" ? esc(x.gift || "") : `−${x.pct}%`}${x.type === "code" ? `<br><code>${esc(x.code)}</code>` : ""}</td><td class="nowrap">${dd(x.from)} — ${dd(addDays(x.to, -1))}</td><td><span class="sb ${STATE[s][1]}">${STATE[s][0]}</span></td><td>${x.type === "code" && !n ? "все без скидки" : n}</td><td>${x.home !== false ? "главная, «Акции»" : "только в цене"}</td></tr>`; }).join("") || '<tr><td colspan="7" class="muted">Акций нет</td></tr>'}
      </tbody></table></div>`;
  }
  function promoEditor() {
    const { x, isNew } = st.edit; const q = (st.edit.q || "").toLowerCase();
    const prods = C.products.filter((p) => p.category !== "sale" && (!q || fullName(p).toLowerCase().includes(q) || (catById(p.category) || {}).name.toLowerCase().includes(q)));
    return `<div class="adm-head"><div><button class="link" id="aback">← Все акции</button><h1>${isNew ? "Новая акция" : esc(x.title)}</h1></div>
      <div class="adm-actions">${isNew ? "" : `<a class="btn ghost sm" href="${ROOT}akcii/index.html#${encodeURIComponent(x.id)}" target="_blank">Открыть на сайте ↗</a><button class="btn ghost sm danger" id="adel">Удалить</button>`}<button class="btn" id="asave">Сохранить</button></div></div><div class="err-msg" id="aerr"></div>
      <div class="ed-grid"><div class="ed-main"><section class="ed-box"><h3>Вид акции</h3><div class="seg-choice">${PTYPES.map(([t, n, d]) => `<label class="choice"><input type="radio" name="atype" value="${t}" ${x.type === t ? "checked" : ""}><b>${n}</b><small>${d}</small></label>`).join("")}</div></section>
        <section class="ed-box"><h3>Условия</h3><div class="ed-row3">
          <div class="field"><label for="atitle">Название <span class="req">*</span></label><input class="inp" id="atitle" value="${esc(x.title || "")}" placeholder="Осенняя распродажа"></div>
          ${x.type !== "gift" ? `<div class="field"><label for="apct">Скидка, %</label><input class="inp" id="apct" inputmode="numeric" value="${esc(x.pct || "")}"></div>` : `<div class="field"><label for="agift">Подарок</label><input class="inp" id="agift" value="${esc(x.gift || "")}" placeholder="Наматрасник «Аква» в размер матраса"></div>`}
          ${x.type === "code" ? `<div class="field"><label for="acode">Промокод</label><input class="inp" id="acode" value="${esc(x.code || "")}" placeholder="ТОРБЕЕВО"><small class="muted">Регистр и раскладка не важны: «торбеево» = «TORBEEVO».</small></div>` : x.type === "gift" ? `<div class="field"><label for="aminw">Только при ширине от, см</label><input class="inp" id="aminw" inputmode="numeric" value="${esc(x.min_width || "")}" placeholder="не важно"></div>` : "<div></div>"}</div>
          <div class="field"><label for="atext">Описание для покупателя</label><textarea class="inp" id="atext" rows="2">${esc(x.text || "")}</textarea></div>
          <div class="ed-row3"><div class="field"><label for="afrom">Начало</label><input class="inp" type="date" id="afrom" value="${esc(x.from || "")}"></div>
          <div class="field"><label for="ato">Последний день (включительно)</label><input class="inp" type="date" id="ato" value="${esc(x.to ? addDays(x.to, -1) : "")}"></div>
          <div class="field"><label for="acolor">Цвет баннера</label><select class="inp" id="acolor">${COLORS.map(([k, n]) => `<option value="${k}" ${(x.color || "red") === k ? "selected" : ""}>${n}</option>`).join("")}</select></div></div>
          <div class="ed-checks wrap"><label class="cbx"><input type="checkbox" id="aon" ${x.active !== false ? "checked" : ""}> Включена</label><label class="cbx"><input type="checkbox" id="ahome" ${x.home !== false ? "checked" : ""}> Показывать баннер на главной и на странице «Акции»</label></div></section>
        <section class="ed-box"><h3>На что действует</h3><p class="muted small">${x.type === "code" ? "Ничего не отмечено — промокод действует на все товары без другой скидки." : "Отметьте разделы целиком и/или отдельные товары."}</p>
          <h4 class="ed-g">Разделы</h4><div class="ed-checks wrap">${C.categories.filter((c) => c.id !== "sale").map((c) => `<label class="cbx"><input type="checkbox" data-acat="${c.id}" ${(x.categories || []).includes(c.id) ? "checked" : ""}> ${esc(c.name)}</label>`).join("")}</div>
          <h4 class="ed-g">Товары <span class="muted" id="acnt">${(x.products || []).length} выбрано</span></h4><input class="inp" id="aq" type="search" placeholder="Найти товар" value="${esc(st.edit.q || "")}">
          <div class="ed-plist">${prods.map((p) => `<label class="cbx"><input type="checkbox" data-aprod="${esc(p.id)}" ${(x.products || []).includes(p.id) ? "checked" : ""}> ${esc(fullName(p))} <span class="muted small">${esc((catById(p.category) || {}).name || "")}</span></label>`).join("")}</div></section></div>
      <aside class="ed-side"><section class="ed-box"><h3>Предпросмотр</h3><div class="pcard pc-${esc(x.color || "red")} adm-pcard"><span class="pc-type">${(PTYPES.find((t) => t[0] === x.type) || [, ""])[1]}</span>${x.type !== "gift" ? `<span class="pc-big">−${esc(x.pct || 0)}%</span>` : ""}<b class="pc-title">${esc(x.title || "Название")}</b><span class="pc-text">${esc(x.text || "")}</span></div>
        <p class="muted small">Статус: <b>${STATE[PR.promoState(x)] ? STATE[PR.promoState(x)][0] : "—"}</b></p></section></aside></div>`;
  }
  function readPromoForm() {
    const { x } = st.edit; const v = (id) => ($("#" + id) ? $("#" + id).value.trim() : undefined);
    x.title = v("atitle"); x.text = v("atext"); x.color = v("acolor"); x.active = $("#aon").checked ? undefined : false; x.home = $("#ahome").checked ? undefined : false;
    if ($("#apct")) x.pct = parseInt(v("apct"), 10) || 0; if ($("#agift")) x.gift = v("agift"); if ($("#acode")) x.code = v("acode").toUpperCase(); if ($("#aminw")) x.min_width = parseInt(v("aminw"), 10) || undefined;
    x.from = v("afrom"); const to = v("ato"); x.to = to ? addDays(to, 1) : "";
    x.categories = $$("[data-acat]:checked").map((i) => i.dataset.acat);
    const shown = new Set($$("[data-aprod]").map((i) => i.dataset.aprod));
    x.products = (x.products || []).filter((id) => !shown.has(id)).concat($$("[data-aprod]:checked").map((i) => i.dataset.aprod));
  }
  function bindPromos() {
    if (st.edit && st.edit.kind === "promo") return bindPromoEditor();
    const t = PR.today();
    $("#anew").onclick = () => { st.edit = { kind: "promo", isNew: true, x: { id: "", type: "percent", title: "", pct: 10, products: [], categories: [], from: t, to: addDays(t, 14), color: "red" } }; render(); };
    $$("[data-aedit]").forEach((r) => { const open = () => { st.edit = { kind: "promo", isNew: false, x: clone(C.promos.find((x) => x.id === r.dataset.aedit)) }; render(); window.scrollTo(0, 0); }; r.onclick = open; r.onkeydown = (e) => { if (e.key === "Enter") open(); }; });
  }
  function bindPromoEditor() {
    const E = st.edit; const x = E.x;
    $("#aback").onclick = () => { st.edit = null; render(); };
    $$("input[name=atype]").forEach((r) => (r.onchange = () => { readPromoForm(); x.type = r.value; if (x.type === "code" && !x.code) x.code = "КОД" + (x.pct || 5); render(); }));
    const prev = () => { const pc = $(".adm-pcard"); if (!pc) return; pc.className = "pcard adm-pcard pc-" + $("#acolor").value; $(".pc-title", pc).textContent = $("#atitle").value || "Название"; $(".pc-text", pc).textContent = $("#atext").value; const b = $(".pc-big", pc); if (b && $("#apct")) b.textContent = "−" + ($("#apct").value || 0) + "%"; };
    ["atitle", "apct", "atext", "acolor"].forEach((id) => { const el = $("#" + id); if (el) el.oninput = el.onchange = prev; });
    $("#aq").oninput = (e) => { readPromoForm(); E.q = e.target.value; const pos = e.target.selectionStart; render(); const n = $("#aq"); n.focus(); n.setSelectionRange(pos, pos); };
    $$("[data-aprod]").forEach((i) => (i.onchange = () => { readPromoForm(); $("#acnt").textContent = x.products.length + " выбрано"; }));
    $("#asave").onclick = async () => {
      readPromoForm(); const err = $("#aerr");
      if (!x.title) return (err.textContent = "Укажите название");
      if (x.type !== "gift" && !(x.pct > 0 && x.pct < 91)) return (err.textContent = "Скидка — от 1 до 90%");
      if (x.type === "gift" && !x.gift) return (err.textContent = "Укажите подарок");
      if (x.type === "code" && !x.code) return (err.textContent = "Укажите промокод");
      if (!x.from || !x.to || x.to <= x.from) return (err.textContent = "Проверьте даты");
      if (x.type !== "code" && !x.products.length && !x.categories.length) return (err.textContent = "Выберите разделы или товары");
      if (x.type !== "percent") delete x.pct; if (x.type !== "gift") { delete x.gift; delete x.min_width; } if (x.type !== "code") delete x.code;
      Object.keys(x).forEach((k) => x[k] === undefined && delete x[k]);
      if (E.isNew) { x.id = slug(x.title) || "promo"; let n = 2; while (C.promos.some((y) => y.id === x.id)) x.id = slug(x.title) + "-" + n++; C.promos.push(x); }
      else C.promos[C.promos.findIndex((y) => y.id === x.id)] = x;
      await saveCatalog(E.isNew ? "Акция добавлена" : "Акция сохранена"); st.edit = { kind: "promo", isNew: false, x: clone(x) }; render();
    };
    const del = $("#adel"); if (del) del.onclick = async () => { if (!confirmBox(`Удалить акцию «${x.title}»? Можно вместо этого снять галочку «Включена».`)) return; C.promos = C.promos.filter((y) => y.id !== x.id); await saveCatalog("Акция удалена"); st.edit = null; render(); };
  }

  /* =============================== ДАННЫЕ =============================== */
  const GH_KEY = "tmvo_gh";
  function diff() {
    const B = DATA.base || { products: [], categories: [], promos: [] };
    const cmp = (a, b, key) => { const m = new Map((b || []).map((x) => [x[key], JSON.stringify(x)])); const ids = new Set((a || []).map((x) => x[key]));
      return { added: (a || []).filter((x) => !m.has(x[key])).length, changed: (a || []).filter((x) => m.has(x[key]) && m.get(x[key]) !== JSON.stringify(x)).length, removed: (b || []).filter((x) => !ids.has(x[key])).length }; };
    const norm = (list) => (list || []).map((p) => { const c = Object.assign({}, p); delete c.image; return c; });
    return { products: cmp(norm(C.products), norm(B.products), "id"), categories: cmp(C.categories, B.categories, "id"), promos: cmp(C.promos, B.promos || [], "id") };
  }
  function dataView() {
    const d = diff(); const g = ls.get(GH_KEY, { owner: "", repo: "", branch: "main", base: "", token: "" });
    const line = (t, x) => `<tr><td>${t}</td><td>${x.added}</td><td>${x.changed}</td><td>${x.removed}</td></tr>`;
    const inline = C.products.reduce((s, p) => s + imgs(p).filter((x) => x.startsWith("data:")).length, 0);
    return `<div class="adm-head"><h1>Данные каталога</h1></div>
      <div class="ed-grid"><div class="ed-main">
      <section class="ed-box"><h3>Как это устроено (без сервера и базы)</h3>
        <ol class="ed-steps"><li><b>База = один файл</b> <code>data/catalog.json</code> (и его копия <code>data/catalog.js</code> для сайта). В нём разделы, поля, товары, цены, фото и акции.</li>
        <li><b>Правки в админке</b> сохраняются в черновик этого браузера и сразу видны на сайте <i>только у вас</i> (внизу сайта плашка «Черновик из админки»).</li>
        <li><b>Публикация</b> — кнопкой «Опубликовать на GitHub» (коммит в репозиторий, через 1–2 минуты сайт обновится у всех) или вручную: «Скачать catalog.json» → положить файл в репозиторий и запустить <code>python tools/apply_admin_export.py catalog.json</code>.</li>
        <li><b>Заказы и телефоны</b> в этот файл не попадают и в GitHub не публикуются: до сервера они уходят менеджерам в Telegram (режим «lite», ROADMAP.md).</li></ol></section>
      <section class="ed-box"><h3>Состояние</h3><p>${isDraft() ? `<span class="sb s-awaiting_payment">Есть неопубликованный черновик</span> сохранён ${dt(C.updated)}` : '<span class="sb s-done">Черновика нет</span> — показан опубликованный каталог'} · опубликован: ${esc((DATA.base || {}).built || "—")}</p>
        <table class="adm-table mini-t"><thead><tr><th>Отличия от опубликованного</th><th>добавлено</th><th>изменено</th><th>удалено</th></tr></thead><tbody>${line("Товары", d.products)}${line("Разделы", d.categories)}${line("Акции", d.promos)}</tbody></table>
        ${inline ? `<p class="muted small">Новых фото в черновике: ${inline} — будут загружены при публикации.</p>` : ""}
        <label class="cbx"><input type="checkbox" id="draftOn" ${DATA.draftOn() ? "checked" : ""}> Показывать черновик на сайте в этом браузере</label>
        <div class="adm-actions wrap"><button class="btn ghost sm" id="dl">Скачать catalog.json</button><label class="btn ghost sm"><input type="file" id="ul" accept=".json,application/json" hidden>Загрузить catalog.json</label><button class="btn ghost sm danger" id="drop" ${isDraft() ? "" : "disabled"}>Отменить все правки</button></div></section>
      <section class="ed-box"><h3>Опубликовать на GitHub</h3><p class="muted small">Нужен токен GitHub с доступом только к репозиторию сайта: Settings → Developer settings → Fine-grained tokens → репозиторий сайта → Contents: Read and write. Токен хранится только в этом браузере.</p>
        <div class="ed-row3"><div class="field"><label for="gho">Владелец (логин или организация)</label><input class="inp" id="gho" value="${esc(g.owner)}"></div><div class="field"><label for="ghr">Репозиторий</label><input class="inp" id="ghr" value="${esc(g.repo)}"></div><div class="field"><label for="ghb">Ветка</label><input class="inp" id="ghb" value="${esc(g.branch || "main")}"></div></div>
        <div class="ed-row3"><div class="field"><label for="ghp">Папка сайта в репозитории</label><input class="inp" id="ghp" value="${esc(g.base || "")}" placeholder="пусто — корень"></div><div class="field"><label for="ght">Токен</label><input class="inp" id="ght" type="password" value="${esc(g.token)}" autocomplete="off"></div><div class="field"><label>&nbsp;</label><button class="btn" id="ghgo">Опубликовать</button></div></div>
        <pre class="ed-log" id="ghlog" hidden></pre></section></div>
      <aside class="ed-side"><section class="ed-box"><h3>Дальше — сервер</h3><p class="small">Когда появится сервер, тот же JSON загружается в PostgreSQL (<code>db/schema.sql</code>, <code>tools/catalog_to_sql.py</code>), а админка переключается на <code>/api/admin/catalog</code> — ставится <code>apiMode: "api"</code> в config.js. Интерфейс админки не меняется.</p></section>
        <section class="ed-box"><h3>Excel-каталог</h3><p class="small">Обновить цены и характеристики из нового Catalog_XX.xlsx без потери правок админки: <code>python tools/build_data.py … --merge data/catalog.json</code>.</p></section></aside></div>`;
  }
  const b64 = (str) => { const bytes = new TextEncoder().encode(str); let s = ""; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); };
  function exportJson(cat) { return JSON.stringify(cat, null, 1); }
  function bindData() {
    $("#draftOn").onchange = (e) => { DATA.setDraftOn(e.target.checked); toast(e.target.checked ? "Сайт в этом браузере показывает черновик" : "Сайт показывает опубликованный каталог"); };
    $("#dl").onclick = () => { const blob = new Blob([exportJson(C)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "catalog.json"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); };
    $("#ul").onchange = async (e) => { const f = e.target.files[0]; if (!f) return; try { const j = JSON.parse(await f.text()); if (!j.products || !j.categories) throw new Error("Это не каталог"); if (!j.version) j.version = 4; C = j; await saveCatalog("Каталог загружен в черновик"); render(); } catch (er) { toast("Ошибка: " + er.message); } };
    $("#drop").onclick = async () => { if (!confirmBox("Отменить все неопубликованные правки каталога?")) return; await DATA.dropDraft(); C = clone(DATA.base); render(); toast("Черновик удалён"); };
    $("#ghgo").onclick = async () => {
      const g = { owner: $("#gho").value.trim(), repo: $("#ghr").value.trim(), branch: $("#ghb").value.trim() || "main", base: $("#ghp").value.trim().replace(/^\/|\/$/g, ""), token: $("#ght").value.trim() };
      ls.set(GH_KEY, g); const log = $("#ghlog"); log.hidden = false; log.textContent = ""; const say = (t) => (log.textContent += t + "\n");
      if (!g.owner || !g.repo || !g.token) return say("Заполните владельца, репозиторий и токен.");
      const api = async (method, path, body) => {
        const u = `https://api.github.com/repos/${encodeURIComponent(g.owner)}/${encodeURIComponent(g.repo)}/contents/${(g.base ? g.base + "/" : "") + path}` + (method === "GET" ? `?ref=${encodeURIComponent(g.branch)}` : "");
        const r = await fetch(u, { method, headers: { Authorization: "Bearer " + g.token, Accept: "application/vnd.github+json" }, body: body ? JSON.stringify(body) : undefined });
        if (method === "GET" && r.status === 404) return null;
        const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error((d.message || "ошибка") + " (" + r.status + ")"); return d;
      };
      const put = async (path, content64, msg) => { const ex = await api("GET", path); return api("PUT", path, { message: msg, content: content64, branch: g.branch, sha: ex ? ex.sha : undefined }); };
      const btn = $("#ghgo"); btn.disabled = true;
      try {
        const out = clone(C);
        for (const p of out.products) {
          const list = imgs(p); let changed = false;
          for (let k = 0; k < list.length; k++) if (list[k].startsWith("data:")) {
            const m = /^data:image\/(\w+)(?:\+xml)?;base64,(.*)$/.exec(list[k]); if (!m) continue;
            const ext = m[1] === "jpeg" ? "jpg" : m[1] === "svg" ? "svg" : m[1]; const path = `img/products/${p.id}-${Date.now().toString(36)}${k}.${ext}`;
            say("Фото: " + path); await put(path, m[2], `Фото товара ${p.name}`); list[k] = path; changed = true;
          }
          if (changed) p.images = list;
        }
        out.updated = new Date().toISOString(); out.built = PR.today();
        const json = JSON.stringify(out, null, 1);
        say("data/catalog.json"); await put("data/catalog.json", b64(json), "Каталог: правки из админки");
        say("data/catalog.js"); await put("data/catalog.js", b64("window.CATALOG=" + JSON.stringify(out) + ";\n"), "Каталог: правки из админки");
        C = out; await DATA.saveDraft(C, true);
        say("Готово. GitHub Pages обновит сайт через 1–2 минуты. Новые товары и разделы получат свои страницы после пересборки (workflow .github/workflows/build.yml).");
        toast("Опубликовано");
      } catch (er) { say("Ошибка: " + er.message); }
      btn.disabled = false;
    };
  }

  if (ss.get("tmvo_admin")) main(); else loginView();
})();
