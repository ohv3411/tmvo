/*
 * Источник каталога для сайта и админки.
 *
 * Опубликованный каталог — data/catalog.js (window.CATALOG), это та же база в виде JSON-файла.
 * Админка хранит ЧЕРНОВИК правок в IndexedDB этого браузера (ключ "catalog"). Пока черновик есть
 * и не выключен, сайт в этом браузере показывает его — так менеджер видит изменения до публикации.
 * Остальные посетители видят опубликованный data/catalog.js.
 *
 * TMVO_DATA.ready — Promise с каталогом; site.js и admin.js ждут его перед отрисовкой.
 */
(function () {
  const DB = "tmvo_admin", STORE = "kv";
  let dbp = null;
  function open() {
    if (dbp) return dbp;
    dbp = new Promise((res, rej) => {
      try {
        const r = indexedDB.open(DB, 1);
        r.onupgradeneeded = () => r.result.createObjectStore(STORE);
        r.onsuccess = () => res(r.result);
        r.onerror = () => rej(r.error);
      } catch (e) { rej(e); }
    });
    return dbp;
  }
  function tx(mode, fn) {
    return open().then((db) => new Promise((res, rej) => {
      const t = db.transaction(STORE, mode); const s = t.objectStore(STORE); const r = fn(s);
      t.oncomplete = () => res(r && "result" in r ? r.result : undefined); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
    }));
  }
  const get = (k) => tx("readonly", (s) => s.get(k));
  const set = (k, v) => tx("readwrite", (s) => s.put(v, k));
  const del = (k) => tx("readwrite", (s) => s.delete(k));

  const lsGet = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { /* недоступно */ } };

  const base = window.CATALOG;
  const draftOn = () => lsGet("tmvo_draft_on") !== "0";
  const ready = (async () => {
    try {
      if (!draftOn() || !lsGet("tmvo_has_draft")) return base;      // быстрый путь: черновика нет
      const d = await get("catalog");
      if (d && d.version >= 4) return Object.assign(d, { _draft: true });
    } catch (e) { /* IndexedDB недоступна — показываем опубликованный каталог */ }
    return base;
  })().then((c) => { window.CATALOG = c; return c; });

  window.TMVO_DATA = {
    ready, base, get, set, del, draftOn,
    setDraftOn(on) { lsSet("tmvo_draft_on", on ? null : "0"); },
    async saveDraft(cat, keepTime) { const c = Object.assign({}, cat); delete c._draft; if (!keepTime || !c.updated) c.updated = new Date().toISOString(); await set("catalog", c); lsSet("tmvo_has_draft", "1"); return c; },
    async dropDraft() { await del("catalog"); lsSet("tmvo_has_draft", null); },
    hasDraft: () => !!lsGet("tmvo_has_draft")
  };
})();
